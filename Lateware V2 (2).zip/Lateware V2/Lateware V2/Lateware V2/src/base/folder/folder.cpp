#include "folder.h"

#include <windows.h>
#include <filesystem>
#include <shlobj.h>
#include <vector>

bool FolderManager::EnsureDirectoryExists(const std::string& path)
{
	if (!std::filesystem::exists(path))
	{
		if (!CreateDirectoryA(path.c_str(), NULL) && GetLastError() != ERROR_ALREADY_EXISTS)
			return false;
	}
	return true;
}

std::string FolderManager::GetDocumentsPath(const std::string& subFolder)
{
	char path[MAX_PATH];
	if (SHGetFolderPathA(NULL, CSIDL_PERSONAL, NULL, 0, path) != S_OK)
		return "";

	std::string fullPath = std::string(path) + "\\" + subFolder;
	if (!subFolder.empty() && !FolderManager::EnsureDirectoryExists(fullPath))
		return "";

	return fullPath;
}

std::string FolderManager::GetFusionFolder()
{
	return FolderManager::GetDocumentsPath("Lateware V2");
}

std::string FolderManager::GetConfigsFolder()
{
	return GetFusionFolder() + "\\configs";
}

std::string FolderManager::GetCurrentDir()
{
	char buffer[MAX_PATH]{};
	GetModuleFileNameA(nullptr, buffer, MAX_PATH);
	std::filesystem::path exePath(buffer);
	return exePath.parent_path().string();
}

static bool FileExists(const std::string& path)
{
	return !path.empty() && std::filesystem::exists(path) && std::filesystem::is_regular_file(path);
}

std::string FolderManager::GetDllPath()
{
	// Prefer Lateware V2.dll beside the injector, then common build/output locations.
	const std::string exeDir = GetCurrentDir();
	const std::vector<std::string> candidates = {
		exeDir + "\\Lateware V2.dll",
		exeDir + "\\fusion-plus\\build\\Lateware V2.dll",
		exeDir + "\\..\\fusion-plus\\build\\Lateware V2.dll",
		exeDir + "\\..\\..\\fusion-plus\\build\\Lateware V2.dll",
		GetFusionFolder() + "\\Lateware V2.dll",
		exeDir + "\\Latebot.dll",
		exeDir + "\\latebot.dll",
		exeDir + "\\fusion-plus\\build\\Latebot.dll",
		exeDir + "\\..\\fusion-plus\\build\\Latebot.dll",
		exeDir + "\\..\\..\\fusion-plus\\build\\Latebot.dll",
		GetFusionFolder() + "\\Latebot.dll",
		exeDir + "\\Lateware.dll",
		GetFusionFolder() + "\\Lateware.dll",
	};

	for (const auto& path : candidates)
	{
		try
		{
			std::filesystem::path p = std::filesystem::weakly_canonical(path);
			if (FileExists(p.string()))
				return p.string();
		}
		catch (...)
		{
			if (FileExists(path))
				return path;
		}
	}

	// Legacy naming still supported if present.
	try
	{
		const std::string folder = GetFusionFolder();
		if (!folder.empty() && std::filesystem::exists(folder))
		{
			for (const auto& entry : std::filesystem::directory_iterator(folder))
			{
				const auto name = entry.path().filename().string();
				if (entry.path().extension() == ".dll" &&
					(name.rfind("fusion-plus", 0) == 0 || name.rfind("Latebot", 0) == 0 || name.rfind("latebot", 0) == 0
						|| name.rfind("Lateware", 0) == 0 || name.rfind("lateware", 0) == 0
						|| name.rfind("Lateware V2", 0) == 0))
				{
					return entry.path().string();
				}
			}
		}
	}
	catch (...)
	{
	}

	return exeDir + "\\Lateware V2.dll";
}

std::string FolderManager::GetVersionStringDll()
{
	const std::string path = GetDllPath();
	if (!FileExists(path))
		return "missing";

	// No embedded version string required — show filename stem.
	return std::filesystem::path(path).stem().string();
}
