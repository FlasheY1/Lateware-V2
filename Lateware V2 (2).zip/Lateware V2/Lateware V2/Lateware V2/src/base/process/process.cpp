#include "process.h"

#include <Psapi.h>
#include <TlHelp32.h>
#include <algorithm>
#include <cctype>
#include <filesystem>

#pragma comment(lib, "Psapi.lib")

static std::string ToLower(std::string s)
{
	std::transform(s.begin(), s.end(), s.begin(),
		[](unsigned char c) { return static_cast<char>(std::tolower(c)); });
	return s;
}

static bool ProcessHasJvm(DWORD processId)
{
	HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processId);
	if (snap == INVALID_HANDLE_VALUE)
		return false;

	MODULEENTRY32W me32{};
	me32.dwSize = sizeof(me32);
	bool found = false;
	if (Module32FirstW(snap, &me32))
	{
		do
		{
			if (_wcsicmp(me32.szModule, L"jvm.dll") == 0)
			{
				found = true;
				break;
			}
		} while (Module32NextW(snap, &me32));
	}
	CloseHandle(snap);
	return found;
}

static bool GetProcessExeName(DWORD processId, std::string& outName)
{
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ, FALSE, processId);
	if (!hProcess)
		hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processId);
	if (!hProcess)
		return false;

	char path[MAX_PATH]{};
	DWORD size = MAX_PATH;
	bool ok = false;
	if (QueryFullProcessImageNameA(hProcess, 0, path, &size))
	{
		outName = std::filesystem::path(path).filename().string();
		ok = true;
	}
	CloseHandle(hProcess);
	return ok;
}

static bool LooksLikeMinecraftWindow(const std::string& title)
{
	const std::string t = ToLower(title);
	return t.find("minecraft") != std::string::npos
		|| t.find("lunar") != std::string::npos
		|| t.find("badlion") != std::string::npos
		|| t.find("forge") != std::string::npos
		|| t.find("feather") != std::string::npos
		|| t.find("labymod") != std::string::npos;
}

static bool IsMinecraftProcess(DWORD processId, const std::string& windowTitle)
{
	if (ProcessHasJvm(processId))
		return true;

	std::string exe;
	if (!GetProcessExeName(processId, exe))
		return false;

	const std::string lower = ToLower(exe);
	if (lower != "javaw.exe" && lower != "java.exe")
		return false;

	return LooksLikeMinecraftWindow(windowTitle);
}

static bool ProcessHasModule(DWORD processId, const char* moduleFileName)
{
	HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processId);
	if (snap == INVALID_HANDLE_VALUE)
		return false;

	const std::filesystem::path want(moduleFileName);
	const std::string wantName = ToLower(want.filename().string());

	MODULEENTRY32W me32{};
	me32.dwSize = sizeof(me32);
	bool found = false;
	if (Module32FirstW(snap, &me32))
	{
		do
		{
			char narrow[MAX_PATH]{};
			WideCharToMultiByte(CP_UTF8, 0, me32.szModule, -1, narrow, MAX_PATH, nullptr, nullptr);
			if (ToLower(std::string(narrow)) == wantName)
			{
				found = true;
				break;
			}
		} while (Module32NextW(snap, &me32));
	}
	CloseHandle(snap);
	return found;
}

bool ProcessManager::GetMinecraftProcesses(std::vector<WindowInfo>& processes)
{
	ProcessManager::_processes.clear();
	processes.clear();

	EnumWindows([](HWND hwnd, LPARAM) -> BOOL {
		if (!IsWindowVisible(hwnd))
			return TRUE;

		const int len = GetWindowTextLengthA(hwnd);
		if (len <= 0)
			return TRUE;

		char titleBuf[1024]{};
		GetWindowTextA(hwnd, titleBuf, sizeof(titleBuf));
		std::string title(titleBuf);

		DWORD pid = 0;
		GetWindowThreadProcessId(hwnd, &pid);
		if (pid == 0)
			return TRUE;

		if (!IsMinecraftProcess(pid, title))
			return TRUE;

		// Deduplicate by PID (keep first visible window)
		for (const auto& existing : ProcessManager::_processes)
		{
			if (existing.processId == pid)
				return TRUE;
		}

		ProcessManager::_processes.emplace_back(pid, title, hwnd);
		return TRUE;
	}, NULL);

	std::sort(ProcessManager::_processes.begin(), ProcessManager::_processes.end(),
		[](const WindowInfo& a, const WindowInfo& b) { return a.processName < b.processName; });

	processes = ProcessManager::_processes;
	return true;
}

std::string ProcessManager::InjectDLL(DWORD processId, const char* dllPath)
{
	if (!dllPath || dllPath[0] == '\0')
		return "DLL path is empty.";

	if (!std::filesystem::exists(dllPath))
		return std::string("DLL not found:\n") + dllPath;

	std::string absolute = std::filesystem::absolute(dllPath).string();

	HANDLE hProcess = OpenProcess(
		PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION |
		PROCESS_VM_WRITE | PROCESS_VM_READ,
		FALSE, processId);

	if (!hProcess)
	{
		const DWORD err = GetLastError();
		if (err == ERROR_ACCESS_DENIED)
			return "Access denied. Run the injector as Administrator.";
		return "Could not open Minecraft process (error " + std::to_string(err) + ").";
	}

	const size_t pathBytes = absolute.size() + 1;
	LPVOID remote = VirtualAllocEx(hProcess, nullptr, pathBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!remote)
	{
		CloseHandle(hProcess);
		return "VirtualAllocEx failed.";
	}

	if (!WriteProcessMemory(hProcess, remote, absolute.c_str(), pathBytes, nullptr))
	{
		VirtualFreeEx(hProcess, remote, 0, MEM_RELEASE);
		CloseHandle(hProcess);
		return "WriteProcessMemory failed.";
	}

	HMODULE k32 = GetModuleHandleA("kernel32.dll");
	auto loadLibrary = (LPTHREAD_START_ROUTINE)GetProcAddress(k32, "LoadLibraryA");
	if (!loadLibrary)
	{
		VirtualFreeEx(hProcess, remote, 0, MEM_RELEASE);
		CloseHandle(hProcess);
		return "Could not resolve LoadLibraryA.";
	}

	HANDLE hThread = CreateRemoteThread(hProcess, nullptr, 0, loadLibrary, remote, 0, nullptr);
	if (!hThread)
	{
		const DWORD err = GetLastError();
		VirtualFreeEx(hProcess, remote, 0, MEM_RELEASE);
		CloseHandle(hProcess);
		if (err == ERROR_ACCESS_DENIED)
			return "CreateRemoteThread denied. Run as Administrator / disable anti-cheat overlays.";
		return "CreateRemoteThread failed (error " + std::to_string(err) + ").";
	}

	const DWORD wait = WaitForSingleObject(hThread, 15000);
	DWORD exitCode = 0;
	GetExitCodeThread(hThread, &exitCode);
	CloseHandle(hThread);
	VirtualFreeEx(hProcess, remote, 0, MEM_RELEASE);
	CloseHandle(hProcess);

	if (wait == WAIT_TIMEOUT)
		return "Injection timed out waiting for LoadLibrary.";

	// On x64, GetExitCodeThread only returns the low 32 bits of HMODULE.
	// A successful load can look like 0 (e.g. base ...00000000). Prefer a
	// module snapshot to decide success.
	if (ProcessHasModule(processId, absolute.c_str()))
		return {};

	if (exitCode == 0)
	{
		return "LoadLibrary failed inside the game.\n"
			"Rebuild Lateware V2.dll (x64), run the injector as Admin,\n"
			"and make sure you inject into the Lunar/Minecraft javaw process.";
	}

	// Non-zero exit but module not visible yet — still treat as failure.
	return "DLL thread returned but Lateware V2.dll was not found in the process.";
}
