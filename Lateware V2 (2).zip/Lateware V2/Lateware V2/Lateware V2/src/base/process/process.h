#pragma once

#include <string>
#include <vector>
#include <Windows.h>

namespace ProcessManager
{
	struct WindowInfo
	{
		DWORD processId;
		std::string processName;
		HWND hwnd;

		WindowInfo(DWORD pid, const std::string& name, HWND window)
			: processId(pid), processName(name), hwnd(window) {}
	};

	inline std::vector<WindowInfo> _processes;

	bool GetMinecraftProcesses(std::vector<WindowInfo>& processes);

	// Returns empty string on success, or an error message.
	std::string InjectDLL(DWORD processId, const char* dllPath);
}
