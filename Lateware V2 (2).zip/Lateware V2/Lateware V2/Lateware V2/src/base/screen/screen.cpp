#include "screen.h"

#include <string>
#include <windows.h>
#include <vector>
#include <regex>
#include <cmath>

#include "process/process.h"
#include "payload/payload.h"
#include "base.h"

namespace
{
	ImU32 Col(int r, int g, int b, float a)
	{
		if (a < 0.0f) a = 0.0f;
		if (a > 1.0f) a = 1.0f;
		return IM_COL32(r, g, b, static_cast<int>(a * 255.0f));
	}

	// Draw text horizontally centered on cx, with its top edge at y.
	void CenterText(ImDrawList* dl, ImFont* font, float cx, float y, ImU32 col, const char* text)
	{
		if (!font) font = ImGui::GetFont();
		const float sz = font->FontSize;
		const ImVec2 ts = font->CalcTextSizeA(sz, FLT_MAX, 0.0f, text);
		dl->AddText(font, sz, ImVec2(cx - ts.x * 0.5f, y), col, text);
	}

	// Pull a "1.8.9" style version out of the window title.
	std::string ExtractVersion(const std::string& title)
	{
		static const std::regex re(R"((\d+\.\d+(?:\.\d+)?))");
		std::smatch m;
		if (std::regex_search(title, m, re))
			return m[1].str();
		return title;
	}

	float Approach(float current, float target, float dt, float speed)
	{
		float step = dt * speed;
		if (step > 1.0f) step = 1.0f;
		return current + (target - current) * step;
	}
}

void Screen::SetupStyle()
{
	ImGuiStyle& style = ImGui::GetStyle();

	style.Alpha = 1.0f;
	style.DisabledAlpha = 0.6f;
	style.WindowPadding = ImVec2(0.0f, 0.0f);
	style.WindowRounding = 0.0f;
	style.WindowBorderSize = 0.0f;
	style.FrameRounding = 10.0f;
	style.FrameBorderSize = 0.0f;
	style.ScrollbarSize = 12.0f;
	style.ScrollbarRounding = 8.0f;

	const ImVec4 bg(0.055f, 0.055f, 0.065f, 1.0f);
	style.Colors[ImGuiCol_WindowBg] = bg;
	style.Colors[ImGuiCol_ChildBg] = bg;
	style.Colors[ImGuiCol_TitleBg] = bg;
	style.Colors[ImGuiCol_TitleBgActive] = bg;
}

bool Screen::Render()
{
	static std::vector<ProcessManager::WindowInfo> processes;
	static int selectedProcess = 0;
	static std::string status;
	static bool statusError = false;
	static int refreshCounter = 0;

	// Animation state (persist across frames).
	static float appear = 0.0f;
	static float injectHover = 0.0f;
	static float injectPress = 0.0f;
	static float switchHover = 0.0f;

	ImGuiIO& io = ImGui::GetIO();
	const float dt = io.DeltaTime > 0.0f ? io.DeltaTime : 1.0f / 60.0f;
	const float t = static_cast<float>(ImGui::GetTime());

	refreshCounter++;
	if (refreshCounter == 1 || refreshCounter % 45 == 0)
	{
		ProcessManager::GetMinecraftProcesses(processes);
		if (selectedProcess >= static_cast<int>(processes.size()))
			selectedProcess = 0;
	}

	const bool payloadReady = Payload::HasEmbeddedDll();
	const bool minecraftRunning = !processes.empty();
	const bool multipleInstances = processes.size() > 1;

	ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
	ImGui::SetNextWindowSize(io.DisplaySize, ImGuiCond_Always);

	ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
	ImGui::Begin("Lateware V2", nullptr,
		ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
		ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus |
		ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav |
		ImGuiWindowFlags_NoScrollbar);
	ImGui::PopStyleVar();

	ImDrawList* dl = ImGui::GetWindowDrawList();
	const ImVec2 sz = io.DisplaySize;
	const float cx = sz.x * 0.5f;
	const float cy = sz.y * 0.5f;

	// Smooth entrance: fade + slight upward slide.
	appear = Approach(appear, 1.0f, dt, 6.0f);
	const float a = appear;
	const float rise = (1.0f - a) * 22.0f;

	// Soft ambient background glows.
	dl->AddCircleFilled(ImVec2(sz.x * 0.08f, sz.y * 0.12f), 260.0f, Col(255, 75, 120, 0.05f * a));
	dl->AddCircleFilled(ImVec2(sz.x * 0.95f, sz.y * 0.92f), 300.0f, Col(90, 120, 255, 0.045f * a));
	dl->AddCircleFilled(ImVec2(cx, cy - 120.0f + rise), 190.0f, Col(255, 75, 120, 0.04f * a));

	const ImU32 pink = Col(255, 75, 120, a);
	const ImU32 white = Col(240, 240, 245, a);
	const ImU32 muted = Col(150, 150, 160, a);

	// Logo, gently floating.
	const float logoFloat = std::sin(t * 1.6f) * 3.0f;
	const float logoY = cy - 118.0f + rise + logoFloat;
	CenterText(dl, g_FontLogo, cx, logoY, pink, "Lateware");
	CenterText(dl, g_FontSmall, cx, logoY + 52.0f, muted, "V 2");

	if (!payloadReady)
	{
		CenterText(dl, g_FontLarge, cx, cy + 6.0f + rise, Col(255, 90, 90, a), "Payload missing");
		CenterText(dl, nullptr, cx, cy + 44.0f + rise, muted, "Rebuild the loader to embed the client.");
	}
	else if (!minecraftRunning)
	{
		CenterText(dl, g_FontLarge, cx, cy + 4.0f + rise, white, "No Minecraft found");
		CenterText(dl, nullptr, cx, cy + 42.0f + rise, muted, "Open Minecraft to continue");

		// Animated scanning dots.
		const float dotsY = cy + 82.0f + rise;
		const float gap = 16.0f;
		for (int i = 0; i < 3; i++)
		{
			const float ph = t * 3.0f - i * 0.55f;
			const float s = 0.5f + 0.5f * std::sin(ph);
			dl->AddCircleFilled(ImVec2(cx - gap + i * gap, dotsY), 3.0f + 2.0f * s,
				Col(255, 75, 120, (0.25f + 0.7f * s) * a));
		}
	}
	else
	{
		const std::string& title = processes[selectedProcess].processName;
		const std::string version = ExtractVersion(title);

		// ---- Custom two-line Inject button (centered) ----
		const ImVec2 btnSize(340.0f, 92.0f);
		const float btnTop = cy - 4.0f + rise;
		const ImVec2 bpos(cx - btnSize.x * 0.5f, btnTop);

		ImGui::SetCursorScreenPos(bpos);
		ImGui::InvisibleButton("##inject", btnSize);
		const bool hovered = ImGui::IsItemHovered();
		const bool active = ImGui::IsItemActive();
		const bool clicked = ImGui::IsItemClicked();

		injectHover = Approach(injectHover, hovered ? 1.0f : 0.0f, dt, 12.0f);
		injectPress = Approach(injectPress, active ? 1.0f : 0.0f, dt, 18.0f);

		// Hover grows slightly, press shrinks slightly.
		const float scale = 1.0f + injectHover * 0.025f - injectPress * 0.04f;
		const ImVec2 center(bpos.x + btnSize.x * 0.5f, bpos.y + btnSize.y * 0.5f);
		const ImVec2 half(btnSize.x * 0.5f * scale, btnSize.y * 0.5f * scale);
		const ImVec2 p0(center.x - half.x, center.y - half.y);
		const ImVec2 p1(center.x + half.x, center.y + half.y);

		const float pulse = 0.5f + 0.5f * std::sin(t * 2.4f);
		const float rounding = 16.0f;

		// Breathing glow behind the button, stronger on hover.
		const float glow = (0.18f + 0.22f * pulse) * (0.35f + 0.65f * injectHover) * a;
		const float e = 10.0f + injectHover * 6.0f;
		dl->AddRectFilled(ImVec2(p0.x - e, p0.y - e), ImVec2(p1.x + e, p1.y + e),
			Col(255, 75, 120, glow), rounding + e);

		// Button body (brightens on hover).
		const int br = static_cast<int>(255);
		const int bg = static_cast<int>(75 + 35 * injectHover);
		const int bb = static_cast<int>(120 + 30 * injectHover);
		dl->AddRectFilled(p0, p1, Col(br, bg, bb, a), rounding);
		dl->AddRect(p0, p1, Col(255, 255, 255, 0.10f * a), rounding, 0, 1.5f);

		// Two lines of text: "Inject" then the detected version.
		CenterText(dl, g_FontLarge, cx, center.y - 30.0f, Col(255, 255, 255, a), "Inject");
		CenterText(dl, g_FontSmall, cx, center.y + 8.0f, Col(255, 255, 255, 0.85f * a), version.c_str());

		if (clicked)
		{
			const std::string dllPath = Payload::GetInjectDllPath();
			if (dllPath.empty())
			{
				status = "Failed to unpack the embedded client DLL.";
				statusError = true;
				MessageBoxA(nullptr, status.c_str(), "Lateware V2", MB_OK | MB_ICONERROR);
			}
			else
			{
				const std::string err = ProcessManager::InjectDLL(
					processes[selectedProcess].processId, dllPath.c_str());

				if (err.empty())
				{
					status = "Injected successfully. You can close this loader.";
					statusError = false;
				}
				else
				{
					status = err;
					statusError = true;
					MessageBoxA(nullptr, err.c_str(), "Lateware V2", MB_OK | MB_ICONERROR);
				}
			}
		}

		// ---- Optional "switch instance" link (centered) ----
		if (multipleInstances)
		{
			char label[64];
			snprintf(label, sizeof(label), "Switch instance  (%d / %d)",
				selectedProcess + 1, static_cast<int>(processes.size()));

			ImFont* f = g_FontSmall ? g_FontSmall : ImGui::GetFont();
			const float fs = f->FontSize;
			const ImVec2 ts = f->CalcTextSizeA(fs, FLT_MAX, 0.0f, label);
			const float linkY = btnTop + btnSize.y + 20.0f;
			ImGui::SetCursorScreenPos(ImVec2(cx - ts.x * 0.5f, linkY));
			ImGui::InvisibleButton("##switch", ts);
			const bool sw = ImGui::IsItemHovered();
			switchHover = Approach(switchHover, sw ? 1.0f : 0.0f, dt, 12.0f);
			if (ImGui::IsItemClicked())
				selectedProcess = (selectedProcess + 1) % static_cast<int>(processes.size());

			const int lg = static_cast<int>(150 + 90 * switchHover);
			CenterText(dl, f, cx, linkY, Col(lg, lg, lg + 5, a), label);
		}
	}

	// Status message, centered near the bottom.
	if (!status.empty())
	{
		const ImU32 sc = statusError ? Col(255, 90, 90, a) : Col(110, 220, 140, a);
		CenterText(dl, g_FontSmall, cx, sz.y - 54.0f, sc, status.c_str());
	}

	// Footer version, faint and centered.
	const std::string footer = std::string("Injector v") + INJECTOR_VERSION;
	CenterText(dl, g_FontSmall, cx, sz.y - 26.0f, Col(110, 110, 120, a), footer.c_str());

	ImGui::End();
	return true;
}
