#pragma once

#include "ImGui/imgui.h"

// Fonts loaded in window.cpp, used by the injector screen.
extern ImFont* g_FontLogo;
extern ImFont* g_FontLarge;
extern ImFont* g_FontSmall;

class Screen
{
public:
	void SetupStyle();
	bool Render();

private:

};