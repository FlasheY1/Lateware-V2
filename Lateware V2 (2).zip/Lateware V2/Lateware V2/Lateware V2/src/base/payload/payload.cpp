#include "payload.h"

#include "../../../resource.h"

#include <windows.h>
#include <filesystem>

namespace
{
	std::string GetTempPayloadDir()
	{
		char temp[MAX_PATH]{};
		DWORD n = GetTempPathA(MAX_PATH, temp);
		if (n == 0 || n >= MAX_PATH)
			return {};

		std::string dir = std::string(temp) + "LatewareV2";
		std::error_code ec;
		std::filesystem::create_directories(dir, ec);
		if (ec)
			return {};
		return dir;
	}

	bool WriteFileBytes(const std::string& path, const void* data, DWORD size)
	{
		HANDLE hFile = CreateFileA(
			path.c_str(),
			GENERIC_WRITE,
			0,
			nullptr,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			nullptr);

		if (hFile == INVALID_HANDLE_VALUE)
			return false;

		DWORD written = 0;
		const BOOL ok = WriteFile(hFile, data, size, &written, nullptr);
		CloseHandle(hFile);
		return ok && written == size;
	}
}

bool Payload::HasEmbeddedDll()
{
	return FindResourceW(nullptr, MAKEINTRESOURCEW(IDR_LATEWARE_DLL), RT_RCDATA) != nullptr;
}

std::string Payload::GetInjectDllPath()
{
	static std::string cachedPath;

	HRSRC hRes = FindResourceW(nullptr, MAKEINTRESOURCEW(IDR_LATEWARE_DLL), RT_RCDATA);
	if (!hRes)
		return {};

	const DWORD size = SizeofResource(nullptr, hRes);
	if (size == 0)
		return {};

	HGLOBAL hData = LoadResource(nullptr, hRes);
	if (!hData)
		return {};

	const void* data = LockResource(hData);
	if (!data)
		return {};

	const std::string dir = GetTempPayloadDir();
	if (dir.empty())
		return {};

	// Unique name per resource size so stale temp DLLs cannot be reused after rebuilds.
	const std::string path = dir + "\\LatewareV2_" + std::to_string(size) + ".dll";

	if (!cachedPath.empty() && cachedPath == path)
	{
		std::error_code ec;
		if (std::filesystem::exists(cachedPath, ec) &&
			std::filesystem::file_size(cachedPath, ec) == size && !ec)
		{
			return cachedPath;
		}
	}

	// Best-effort delete of older extracts.
	std::error_code ec;
	for (const auto& entry : std::filesystem::directory_iterator(dir, ec))
	{
		if (!entry.is_regular_file(ec))
			continue;
		const auto name = entry.path().filename().string();
		if ((name.rfind("LatewareV2", 0) == 0 || name.rfind("Latebot", 0) == 0)
			&& entry.path().extension() == ".dll" && entry.path() != path)
			std::filesystem::remove(entry.path(), ec);
	}

	if (!WriteFileBytes(path, data, size))
		return {};

	cachedPath = path;
	return cachedPath;
}
