#pragma once

#include <string>

namespace Payload
{
	// True if the EXE contains the embedded Lateware V2.dll resource.
	bool HasEmbeddedDll();

	// Extract embedded DLL to a temp path (idempotent). Empty string on failure.
	// LoadLibrary requires a real file path; the file is left on disk for the game to use.
	std::string GetInjectDllPath();
}
