@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo Cleaning old outputs...
del /f /q "build\*.pdb" 2>nul
del /f /q "build\*.ilk" 2>nul
del /f /q "build\Lateware.dll" 2>nul
del /f /q "build\fusion-plus.dll" 2>nul
del /f /q "build\etc\*.pdb" 2>nul
del /f /q "build\etc\vc*.pdb" 2>nul

set "MSBUILD="
if exist "%ProgramFiles%\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe" set "MSBUILD=%ProgramFiles%\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe"
if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe" set "MSBUILD=%ProgramFiles%\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"
if "%MSBUILD%"=="" (
  echo MSBuild not found.
  exit /b 1
)

echo Building Lateware.dll (Release x64)...
"%MSBUILD%" "%~dp0fusion-plus.vcxproj" /t:Rebuild /p:Configuration=Release /p:Platform=x64 /p:PlatformToolset=v145 /m /v:minimal
if errorlevel 1 (
  echo Retrying without toolset pin...
  "%MSBUILD%" "%~dp0fusion-plus.vcxproj" /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m /v:minimal
)
if errorlevel 1 (
  echo BUILD FAILED
  exit /b 1
)

if not exist "%~dp0build\Lateware.dll" if exist "%~dp0build\fusion-plus.dll" copy /Y "%~dp0build\fusion-plus.dll" "%~dp0build\Lateware.dll" >nul
if not exist "%~dp0build\Lateware.dll" (
  echo Lateware.dll missing after build
  dir /b "%~dp0build"
  exit /b 1
)

set "FUSION=%USERPROFILE%\Documents\Fusion+"
if not exist "%FUSION%" mkdir "%FUSION%"
copy /Y "%~dp0build\Lateware.dll" "%FUSION%\Lateware.dll" >nul
copy /Y "%~dp0build\Lateware.dll" "%FUSION%\fusion-plus_v0.0.4.dll" >nul

echo.
echo BUILD OK
echo   %~dp0build\Lateware.dll
echo   %FUSION%\Lateware.dll
exit /b 0
