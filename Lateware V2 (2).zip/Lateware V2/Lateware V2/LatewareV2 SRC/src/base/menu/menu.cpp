#include "menu.h"

#include <cmath>
#include <type_traits>
#include <unordered_map>

#include <imgui/imgui_internal.h>

#include "util/logger.h"
#include "util/keys.h"
#include "util/string.h"
#include "configManager/settings.h"
#include "base.h"

// Salts for extra animation channels on a single widget id
namespace
{
	constexpr unsigned int kAnimHover = 0x9E3779B9u;
	constexpr unsigned int kAnimPress = 0x7F4A7C15u;
	constexpr unsigned int kAnimValue = 0x51ED270Bu;
}

float Menu::Lerp(float a, float b, float t)
{
	if (t < 0.f) t = 0.f;
	if (t > 1.f) t = 1.f;
	return a + (b - a) * t;
}

float Menu::Approach(float current, float target, float speed, float dt)
{
	const float t = 1.f - expf(-speed * dt);
	return Lerp(current, target, t);
}

ImVec4 Menu::AccentVec(float a)
{
	return ImVec4(
		settings::Menu_PrimaryColor[0],
		settings::Menu_PrimaryColor[1],
		settings::Menu_PrimaryColor[2],
		settings::Menu_PrimaryColor[3] * a);
}

void Menu::UpdateOpenAnim(float dt)
{
	const float target = Menu::open ? 1.f : 0.f;
	// Fast enough to feel responsive, slow enough to read as a smooth glide.
	Menu::openAnim = Approach(Menu::openAnim, target, 9.f, dt);
	if (Menu::openAnim < 0.001f) Menu::openAnim = 0.f;
	if (Menu::openAnim > 0.999f) Menu::openAnim = 1.f;
}

float& Menu::AnimSlot(unsigned int key)
{
	static std::unordered_map<unsigned int, float> s_slots;
	return s_slots[key];
}

float Menu::Anim01(unsigned int key, float target, float speed)
{
	float& v = AnimSlot(key);
	v = Approach(v, target, speed, ImGui::GetIO().DeltaTime);
	if (v < 0.0005f && target <= 0.f) v = 0.f;
	if (v > 0.9995f && target >= 1.f) v = 1.f;
	return v;
}

ImVec4 Menu::LerpVec4(const ImVec4& a, const ImVec4& b, float t)
{
	if (t < 0.f) t = 0.f;
	if (t > 1.f) t = 1.f;
	return ImVec4(
		a.x + (b.x - a.x) * t,
		a.y + (b.y - a.y) * t,
		a.z + (b.z - a.z) * t,
		a.w + (b.w - a.w) * t);
}

void Menu::Init()
{
	Menu::title = Base::m_name;
	Menu::initialized = false;
	Menu::open = false;
	Menu::openAnim = 0.f;
	Menu::openHudEditor = false;

	Menu::PlaceHooks();
	LOG_INFO("Menu initialized");
}

bool Menu::ConfigItem(const char* name, bool* deleted, bool scrollbar)
{
	ImVec2 size = ImGui::GetWindowSize();
	ImVec2 deleteBtnSize = Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Delete");
	deleteBtnSize.x += ImGui::GetStyle().FramePadding.x * 8;

	bool selected = ImGui::Button(name, ImVec2(size.x - deleteBtnSize.x - 18.f - (scrollbar ? ImGui::GetStyle().ScrollbarSize : 0.f), 0));

	ImGui::SameLine();

	if (ImGui::Button(("Delete###" + std::string(name)).c_str(), ImVec2(deleteBtnSize.x, 0.f)))
	{
		*deleted = true;
	}

	return selected;
}

void Menu::Text(const char* text, FontSize size)
{
	if (size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	const ImVec2 pos = ImGui::GetCursorScreenPos();
	const ImVec2 sz = ImGui::CalcTextSize(text);
	const bool hovered = ImGui::IsMouseHoveringRect(pos, ImVec2(pos.x + sz.x, pos.y + sz.y));
	const float hoverAnim = Anim01((unsigned int)ImGui::GetID(text) ^ kAnimHover, hovered ? 1.f : 0.f, 12.f);
	ImGui::TextColored(LerpVec4(ImGui::GetStyleColorVec4(ImGuiCol_Text), AccentVec(1.f), hoverAnim), "%s", text);

	ImGui::PopFont();
}

void Menu::BoldText(const char* text, FontSize size)
{
	if (size == FontSize::SIZE_28) ImGui::PushFont(Menu::boldFont28);
	else if (size == FontSize::SIZE_26) ImGui::PushFont(Menu::boldFont26);
	else if (size == FontSize::SIZE_24) ImGui::PushFont(Menu::boldFont24);
	else if (size == FontSize::SIZE_22) ImGui::PushFont(Menu::boldFont22);
	else if (size == FontSize::SIZE_20) ImGui::PushFont(Menu::boldFont20);
	else if (size == FontSize::SIZE_18) ImGui::PushFont(Menu::boldFont18);
	else if (size == FontSize::SIZE_16) ImGui::PushFont(Menu::boldFont16);
	else if (size == FontSize::SIZE_14) ImGui::PushFont(Menu::boldFont14);

	const ImVec2 pos = ImGui::GetCursorScreenPos();
	const ImVec2 sz = ImGui::CalcTextSize(text);
	const bool hovered = ImGui::IsMouseHoveringRect(pos, ImVec2(pos.x + sz.x, pos.y + sz.y));
	const float hoverAnim = Anim01((unsigned int)ImGui::GetID(text) ^ kAnimHover ^ 0x1u, hovered ? 1.f : 0.f, 12.f);
	ImGui::TextColored(LerpVec4(ImGui::GetStyleColorVec4(ImGuiCol_Text), AccentVec(1.f), hoverAnim), "%s", text);

	ImGui::PopFont();
}

void Menu::TextColored(const char* text, ImVec4 color, FontSize size)
{
	if (size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	ImGui::TextColored(color, text);

	ImGui::PopFont();
}

void Menu::BoldTextColored(const char* text, ImVec4 color, FontSize size)
{
	if (size == FontSize::SIZE_28) ImGui::PushFont(Menu::boldFont28);
	else if (size == FontSize::SIZE_26) ImGui::PushFont(Menu::boldFont26);
	else if (size == FontSize::SIZE_24) ImGui::PushFont(Menu::boldFont24);
	else if (size == FontSize::SIZE_22) ImGui::PushFont(Menu::boldFont22);
	else if (size == FontSize::SIZE_20) ImGui::PushFont(Menu::boldFont20);
	else if (size == FontSize::SIZE_18) ImGui::PushFont(Menu::boldFont18);
	else if (size == FontSize::SIZE_16) ImGui::PushFont(Menu::boldFont16);
	else if (size == FontSize::SIZE_14) ImGui::PushFont(Menu::boldFont14);

	ImGui::TextColored(color, text);

	ImGui::PopFont();
}

void Menu::GlitchText(const char* text, FontSize size)
{
	ImVec2 cursorPos = ImGui::GetCursorPos();  // Get the current cursor position in screen space
	ImDrawList* drawList = ImGui::GetWindowDrawList();

	// Push the custom font with the given size
	if (size == FontSize::SIZE_28) ImGui::PushFont(Menu::boldFont28);
	else if (size == FontSize::SIZE_26) ImGui::PushFont(Menu::boldFont26);
	else if (size == FontSize::SIZE_24) ImGui::PushFont(Menu::boldFont24);
	else if (size == FontSize::SIZE_22) ImGui::PushFont(Menu::boldFont22);
	else if (size == FontSize::SIZE_20) ImGui::PushFont(Menu::boldFont20);
	else if (size == FontSize::SIZE_18) ImGui::PushFont(Menu::boldFont18);
	else if (size == FontSize::SIZE_16) ImGui::PushFont(Menu::boldFont16);
	else if (size == FontSize::SIZE_14) ImGui::PushFont(Menu::boldFont14);

	// Red Glitch Offset (slightly displaced)
	ImVec2 pos_red = ImVec2(cursorPos.x - (1 + (rand() % 3)), cursorPos.y - (rand() % 2));
	ImGui::SetCursorPos(pos_red);  // Set the cursor to the new position
	ImGui::TextColored(ImColor(235, 5, 90, 100 + (rand() % 60)), "%s", text);  // Red text

	// Cyan Glitch Offset (slightly displaced)
	ImVec2 pos_cyan = ImVec2(cursorPos.x + (1 + (rand() % 3)), cursorPos.y + (rand() % 2));
	ImGui::SetCursorPos(pos_cyan);  // Set the cursor to the new position
	ImGui::TextColored(ImColor(32, 217, 217, 100 + (rand() % 60)), "%s", text);  // Cyan text

	// Main Text (centered)
	ImGui::SetCursorPos(cursorPos);  // Reset cursor to original position
	ImGui::TextColored(ImColor(255, 255, 255), "%s", text);  // Main white text

	// Pop the custom font to restore the default
	ImGui::PopFont();
}

void Menu::GlitchText(const char* text, ImVec2 pos, int size)
{
	// Red Text
	ImVec2 pos_one = ImVec2(pos.x - (1 + (rand() % 3)), pos.y - (rand() % 2));
	ImGui::GetWindowDrawList()->AddText(Menu::fontBold, size, pos_one, ImColor(235, 5, 90, 100 + (rand() % 60)), text);

	// Cyan Text;
	ImVec2 pos_two = ImVec2(pos.x + (1 + (rand() % 3)), pos.y + (rand() % 2));
	ImGui::GetWindowDrawList()->AddText(Menu::fontBold, size, pos_two, ImColor(32, 217, 217, 100 + (rand() % 60)), text);

	// Real Text
	ImGui::GetWindowDrawList()->AddText(Menu::fontBold, size, pos, ImColor(255, 255, 255), text);
}

void Menu::VerticalSeparator(const char* str_id, float size, float thickness)
{
	// Get the current cursor position
	ImVec2 p1 = ImGui::GetCursorScreenPos();

	// Define the position for the separator (just use thickness for the vertical separator)
	ImVec2 p2 = ImVec2(p1.x + thickness, p1.y + size);

	// Define the color for the separator
	ImColor color = ImColor(settings::Menu_SeperatorColor[0], settings::Menu_SeperatorColor[1], settings::Menu_SeperatorColor[2], settings::Menu_SeperatorColor[3]);

	// Draw the vertical separator using ImGui's window draw list
	ImGui::GetWindowDrawList()->AddRectFilled(p1, p2, color);

	// Use an invisible button to reserve space, with no visible UI change
	ImGui::InvisibleButton(("###VerticalSeparator" + std::string(str_id)).c_str(), ImVec2(thickness, size));
}

void Menu::HorizontalSeparator(const char* str_id, float size, float thickness)
{
	if (size == 0)
	{
		size = ImGui::GetWindowSize().x - 40.f;
	}

	// Get the current cursor position
	ImVec2 p1 = ImGui::GetCursorScreenPos();

	// Define the position for the separator (just use thickness for the horizontal separator)
	ImVec2 p2 = ImVec2(p1.x + size, p1.y + thickness);

	// Define the color for the separator
	ImColor color = ImColor(settings::Menu_SeperatorColor[0], settings::Menu_SeperatorColor[1], settings::Menu_SeperatorColor[2], settings::Menu_SeperatorColor[3]);

	// Draw the horizontal separator using ImGui's window draw list
	ImGui::GetWindowDrawList()->AddRectFilled(p1, p2, color);

	// Now, use an invisible button to move the cursor by just the thickness
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + thickness);

	// Use an invisible button to reserve space, with no visible UI change
	ImGui::InvisibleButton(("###HorizontalSeparator_" + std::string(str_id)).c_str(), ImVec2(size, thickness));
}

void Menu::HorizontalSeparatorText(const char* text, FontSize font_size, float size)
{
	if (size == 0)
	{
		size = ImGui::GetWindowSize().x - 40.f;
	}

	if (font_size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (font_size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (font_size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (font_size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (font_size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (font_size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (font_size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (font_size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	ImVec2 textSize = ImGui::CalcTextSize(text);
	float textWidth = textSize.x;

	float separatorWidth = (size - textWidth - 20.f) / 2;

	Menu::HorizontalSeparator(("1TextSeparator_" + std::string(text)).c_str(), separatorWidth);
	ImGui::SameLine();
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - (textSize.y / 2));
	ImGui::Text(text);
	ImGui::SameLine();
	Menu::HorizontalSeparator(("2TextSeparator_" + std::string(text)).c_str(), separatorWidth);

	ImGui::PopFont();
}

// Draws an ImGui button whose colors ease between idle/hover/active instead of snapping.
// Reads last frame's animation state, then updates targets from this frame's item state.
static bool AnimatedButton(const char* label, ImVec2 size)
{
	const ImGuiID id = ImGui::GetID(label);
	const float hoverAnim = Menu::AnimSlot((unsigned int)id ^ 0x9E3779B9u);
	const float pressAnim = Menu::AnimSlot((unsigned int)id ^ 0x7F4A7C15u);

	const ImVec4 base = ImGui::GetStyleColorVec4(ImGuiCol_Button);
	const ImVec4 hovered = ImGui::GetStyleColorVec4(ImGuiCol_ButtonHovered);
	const ImVec4 active = ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive);
	ImVec4 col = Menu::LerpVec4(base, hovered, hoverAnim);
	col = Menu::LerpVec4(col, active, pressAnim);

	ImGui::PushStyleColor(ImGuiCol_Button, col);
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, col);
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, col);

	const bool result = ImGui::Button(label, size);

	Menu::Anim01((unsigned int)id ^ 0x9E3779B9u, ImGui::IsItemHovered() ? 1.f : 0.f, 14.f);
	Menu::Anim01((unsigned int)id ^ 0x7F4A7C15u, ImGui::IsItemActive() ? 1.f : 0.f, 24.f);

	if (ImGui::IsItemHovered())
		ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);

	ImGui::PopStyleColor(3);
	return result;
}

bool Menu::Button(const char* label, ImVec2 size, FontSize font_size)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	if (font_size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (font_size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (font_size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (font_size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (font_size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (font_size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (font_size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (font_size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	bool result = AnimatedButton(label, size);

	ImGui::PopFont();

	return result;
}

static bool IsMouseButton(int button)
{
	return button == 1 || button == 2 || button == 4 || button == 5 || button == 6;
}

static bool IsKeyboardKey(int key)
{
	return !IsMouseButton(key);
}

void Menu::KeybindButton(const char* text, int& keybind, bool allowMouse, bool allowKeyboard, ImVec2 size, FontSize font_size)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5.f);
	Menu::Text(text, font_size);
	ImGui::SameLine();

	const float w = 120.f; // Width of checkbox and keybind button
	const float space = size.x - font18->CalcTextSizeA(18, FLT_MAX, 0.0f, text).x - w;

	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space - 10);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.f);

	int keys_size = IM_ARRAYSIZE(keys);
	char name[18];
	strncpy_s(name, keys[std::clamp(keybind, 0, keys_size)], 18);
	static std::map<const char*, bool> bindings;
	if (bindings[text])
	{
		ImGui::Button("[...]", ImVec2(120, 0));

		for (int i = 0; i < keys_size; i++)
		{
			int key = i;
			if (!Keys::IsKeyPressedOnce(i) || (!allowMouse && IsMouseButton(i)) || (!allowKeyboard && IsKeyboardKey(i))) continue;

			if (i == VK_ESCAPE) keybind = 0;
			else keybind = i;

			strncpy_s(name, keys[std::clamp(keybind, 0, keys_size)], 18);
			bindings[text] = false;
			isBindingKey = false;
			break;
		}
	}
	else
	{
		if (AnimatedButton(Keys::GetKeyName(keybind), ImVec2(120, 0)))
		{
			bindings[text] = true;
			isBindingKey = true;
		}
	}
}

bool Menu::TransparentButton(const char* text, ImVec2 btn_size, FontSize font_size)
{
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 0, 0, 0));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0, 0, 0, 0));
	
	if (font_size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (font_size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (font_size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (font_size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (font_size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (font_size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (font_size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (font_size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	bool result = ImGui::Button(text, btn_size);
	if (ImGui::IsItemHovered())
	{
		ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
	}

	ImGui::PopFont();

	ImGui::PopStyleColor(3);

	return result;
}

bool Menu::MenuButton(const char* text, ImVec2 btn_size, FontSize font_size)
{
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(settings::Menu_ChildBackgroundColor[0], settings::Menu_ChildBackgroundColor[1], settings::Menu_ChildBackgroundColor[2], settings::Menu_ChildBackgroundColor[3]));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImClamp<float>(settings::Menu_ChildBackgroundColor[0] * 0.8f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_ChildBackgroundColor[1] * 0.8f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_ChildBackgroundColor[2] * 0.8f, 0.0f, 1.0f), settings::Menu_ChildBackgroundColor[3]));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImClamp<float>(settings::Menu_ChildBackgroundColor[0] * 0.6f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_ChildBackgroundColor[1] * 0.6f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_ChildBackgroundColor[2] * 0.6f, 0.0f, 1.0f), settings::Menu_ChildBackgroundColor[3]));
	ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(settings::Menu_OutlineColor[0], settings::Menu_OutlineColor[1], settings::Menu_OutlineColor[2], settings::Menu_OutlineColor[3]));
	ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
	ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, settings::Menu_WindowRounding);

	if (font_size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (font_size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (font_size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (font_size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (font_size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (font_size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (font_size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (font_size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	bool result = AnimatedButton(text, btn_size);

	ImGui::PopFont();

	ImGui::PopStyleVar(2);
	ImGui::PopStyleColor(4);

	return result;
}

bool Menu::DetachButton(const char* text, ImVec2 btn_size, FontSize font_size)
{
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(settings::Menu_DetachButtonColor[0], settings::Menu_DetachButtonColor[1], settings::Menu_DetachButtonColor[2], settings::Menu_DetachButtonColor[3]));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(ImClamp<float>(settings::Menu_DetachButtonColor[0] * 0.8f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_DetachButtonColor[1] * 0.8f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_DetachButtonColor[2] * 0.8f, 0.0f, 1.0f), settings::Menu_DetachButtonColor[3]));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(ImClamp<float>(settings::Menu_DetachButtonColor[0] * 0.6f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_DetachButtonColor[1] * 0.6f, 0.0f, 1.0f), ImClamp<float>(settings::Menu_DetachButtonColor[2] * 0.6f, 0.0f, 1.0f), settings::Menu_DetachButtonColor[3]));
	ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(settings::Menu_OutlineColor[0], settings::Menu_OutlineColor[1], settings::Menu_OutlineColor[2], settings::Menu_OutlineColor[3]));
	ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
	ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, settings::Menu_WindowRounding);

	if (font_size == FontSize::SIZE_28) ImGui::PushFont(Menu::font28);
	else if (font_size == FontSize::SIZE_26) ImGui::PushFont(Menu::font26);
	else if (font_size == FontSize::SIZE_24) ImGui::PushFont(Menu::font24);
	else if (font_size == FontSize::SIZE_22) ImGui::PushFont(Menu::font22);
	else if (font_size == FontSize::SIZE_20) ImGui::PushFont(Menu::font20);
	else if (font_size == FontSize::SIZE_18) ImGui::PushFont(Menu::font18);
	else if (font_size == FontSize::SIZE_16) ImGui::PushFont(Menu::font16);
	else if (font_size == FontSize::SIZE_14) ImGui::PushFont(Menu::font14);

	bool result = AnimatedButton(text, btn_size);

	ImGui::PopFont();

	ImGui::PopStyleVar(2);
	ImGui::PopStyleColor(4);

	return result;
}

void Menu::ToggleWithKeybind(bool* enabled, int& keybind, ImVec2 size)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	const float keybindW = 64.f;
	const float toggleW = 40.f;
	const float gap = 10.f;
	const float controlsW = keybindW + gap + toggleW;

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.f);
	Menu::Text("Enabled", FontSize::SIZE_18);
	ImGui::SameLine();

	const float space = size.x - font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Enabled").x - controlsW;
	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space - 10.f);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.f);

	// Compact keybind chip (e.g. "NONE") then pill toggle — matches reference header.
	int keys_size = IM_ARRAYSIZE(keys);
	static bool binding = false;
	const char* keyLabel = binding ? "..." : (keybind == 0 ? "NONE" : Keys::GetKeyName(keybind));

	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1.f, 1.f, 1.f, 0.06f));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.f, 1.f, 1.f, 0.10f));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1.f, 1.f, 1.f, 0.14f));
	ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.f);

	if (AnimatedButton(keyLabel, ImVec2(keybindW, 26.f)))
	{
		binding = true;
		isBindingKey = true;
	}

	ImGui::PopStyleVar();
	ImGui::PopStyleColor(3);

	if (binding)
	{
		for (int i = 0; i < keys_size; i++)
		{
			if (!Keys::IsKeyPressedOnce(i)) continue;

			if (i == VK_ESCAPE) keybind = 0;
			else keybind = i;

			binding = false;
			isBindingKey = false;
			break;
		}
	}

	ImGui::SameLine(0.f, gap);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 2.f);
	// Unique id per setting so animation state never bleeds between modules
	char toggleId[32];
	snprintf(toggleId, sizeof(toggleId), "##Toggle%p", (void*)enabled);
	CheckboxBehavior(toggleId, enabled);
}

// Reference-style slider: label + value on top row, track with − / + underneath.
template <typename T>
static bool SliderStacked(const char* label, T* value, T min, T max, ImVec2 size, const char* format, ImGuiSliderFlags flags, ImGuiDataType data_type)
{
	if (size.x == 0)
		size.x = ImGui::GetWindowSize().x - 40.f;

	if (format == nullptr)
		format = ImGui::DataTypeGetInfo(data_type)->PrintFmt;

	const char* displayLabel = StringUtils::ExtractBeforeDoubleHash(label);

	char value_buf[64];
	ImGui::DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, value, format);

	const float rowGap = 6.f;
	const float trackH = 22.f;
	const float btnW = 22.f;
	const float trackGap = 8.f;

	ImGui::Dummy(ImVec2(0.f, 2.f));

	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems)
		return false;

	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(label);
	const ImGuiID value_id = window->GetID((std::string(label) + "##value_input").c_str());
	const bool temp_input_allowed = (flags & ImGuiSliderFlags_NoInput) == 0;
	bool value_changed = false;

	// Top row: label (left) + clickable value (right) for exact typing
	ImGui::BeginGroup();
	Menu::Text(displayLabel, FontSize::SIZE_18);
	ImGui::SameLine();
	{
		const float valueW = ImMax(56.f, Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.f, value_buf).x + 12.f);
		const float avail = size.x - Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.f, displayLabel).x;
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + avail - valueW - 10.f);

		const ImVec2 valuePos = window->DC.CursorPos;
		const ImRect value_bb(valuePos, ImVec2(valuePos.x + valueW, valuePos.y + 20.f));
		ImGui::ItemSize(value_bb);
		ImGui::ItemAdd(value_bb, value_id);

		bool value_temp_input = temp_input_allowed && ImGui::TempInputIsActive(value_id);
		const bool valueHovered = ImGui::ItemHoverable(value_bb, value_id);
		if (!value_temp_input && valueHovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && temp_input_allowed)
			value_temp_input = true;

		if (value_temp_input)
		{
			value_changed |= ImGui::TempInputScalar(value_bb, value_id, (std::string(label) + "##value_input").c_str(),
				data_type, value, format, &min, &max);
		}
		else
		{
			const ImU32 textCol = ImGui::GetColorU32(valueHovered
				? ImVec4(1.f, 0.294f, 0.471f, 1.f)
				: ImVec4(1.f, 1.f, 1.f, 0.95f));
			window->DrawList->AddText(Menu::font18, 18.f, valuePos, textCol, value_buf);
		}
	}
	ImGui::EndGroup();

	ImGui::Dummy(ImVec2(0.f, rowGap - 2.f));

	const float trackW = size.x - (btnW + trackGap) * 2.f - 10.f;
	const float startX = ImGui::GetCursorPosX();

	// − button
	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1.f, 1.f, 1.f, 0.05f));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.f, 1.f, 1.f, 0.10f));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1.f, 1.f, 1.f, 0.16f));
	ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.f);
	if (AnimatedButton((std::string("-##dec") + label).c_str(), ImVec2(btnW, trackH)))
	{
		if constexpr (std::is_same_v<T, int>)
			*value = ImMax(min, *value - 1);
		else
			*value = ImMax(min, *value - (max - min) * 0.01f);
		value_changed = true;
	}
	ImGui::PopStyleVar();
	ImGui::PopStyleColor(3);

	ImGui::SameLine(0.f, trackGap);

	// Track / grab
	const ImVec2 frame_bb_max = ImVec2(window->DC.CursorPos.x + trackW, window->DC.CursorPos.y + trackH);
	const ImRect frame_bb(window->DC.CursorPos, frame_bb_max);
	const ImRect total_bb(frame_bb.Min, frame_bb.Max);

	ImGui::ItemSize(total_bb, style.FramePadding.y);
	if (!ImGui::ItemAdd(total_bb, id, &frame_bb, temp_input_allowed ? ImGuiItemFlags_Inputable : 0))
		return value_changed;

	const bool hovered = ImGui::ItemHoverable(frame_bb, id);
	bool temp_input_is_active = temp_input_allowed && ImGui::TempInputIsActive(id);
	if (!temp_input_is_active)
	{
		const bool input_requested_by_tabbing = temp_input_allowed && (g.LastItemData.StatusFlags & ImGuiItemStatusFlags_FocusedByTabbing) != 0;
		const bool clicked = hovered && ImGui::IsMouseClicked(0, id);
		const bool make_active = (input_requested_by_tabbing || clicked || g.NavActivateId == id || g.NavActivateInputId == id);
		if (make_active && clicked)
			ImGui::SetKeyOwner(ImGuiKey_MouseLeft, id);
		if (make_active && temp_input_allowed)
			if (input_requested_by_tabbing || (clicked && g.IO.KeyCtrl) || g.NavActivateInputId == id)
				temp_input_is_active = true;

		if (make_active && !temp_input_is_active)
		{
			ImGui::SetActiveID(id, window);
			ImGui::SetFocusID(id, window);
			ImGui::FocusWindow(window);
			g.ActiveIdUsingNavDirMask |= (1 << ImGuiDir_Left) | (1 << ImGuiDir_Right);
		}
	}

	if (temp_input_is_active)
	{
		const bool is_clamp_input = (flags & ImGuiSliderFlags_AlwaysClamp) != 0;
		return ImGui::TempInputScalar(frame_bb, id, label, data_type, value, format, is_clamp_input ? &min : NULL, is_clamp_input ? &max : NULL) || value_changed;
	}

	ImGui::RenderNavHighlight(frame_bb, id);

	const float bar_h = 6.f;
	const float track_y = frame_bb.Min.y + trackH * 0.5f;
	const ImVec2 track_min(frame_bb.Min.x, track_y - bar_h * 0.5f);
	const ImVec2 track_max(frame_bb.Max.x, track_y + bar_h * 0.5f);
	const float track_round = bar_h * 0.5f;

	window->DrawList->AddRectFilled(track_min, track_max,
		ImGui::GetColorU32(hovered || g.ActiveId == id ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg), track_round);

	ImRect grab_bb;
	value_changed |= ImGui::SliderBehavior(frame_bb, id, data_type, value, &min, &max, format, flags, &grab_bb);
	if (value_changed)
		ImGui::MarkItemEdited(id);

	const float grab_center_x = (grab_bb.Min.x + grab_bb.Max.x) * 0.5f;
	if (grab_bb.Max.x > grab_bb.Min.x)
	{
		// Animate the fill as a normalized fraction so it stays correct while
		// the window itself is moving/scaling during the open animation.
		const float track_span = ImMax(track_max.x - track_min.x, 1.f);
		const float target_frac = ImClamp((grab_center_x - track_min.x) / track_span, 0.f, 1.f);
		float& frac = Menu::AnimSlot((unsigned int)id ^ 0x51ED270Bu);
		frac = Menu::Approach(frac, target_frac, g.ActiveId == id ? 30.f : 16.f, g.IO.DeltaTime);
		const float fill_x = track_min.x + track_span * ImClamp(frac, 0.f, 1.f);

		const float hoverAnim = Menu::Anim01((unsigned int)id ^ 0x9E3779B9u, (hovered || g.ActiveId == id) ? 1.f : 0.f, 14.f);
		const float activeAnim = Menu::Anim01((unsigned int)id ^ 0x7F4A7C15u, g.ActiveId == id ? 1.f : 0.f, 20.f);

		const float styleAlpha = g.Style.Alpha;
		const ImVec4 accent = Menu::AccentVec(1.f);

		window->DrawList->AddRectFilled(track_min, ImVec2(fill_x, track_max.y), ImGui::GetColorU32(ImGuiCol_Button), track_round);

		// Soft halo grows on hover, blooms while dragging
		const float halo = (0.10f + 0.12f * hoverAnim + 0.15f * activeAnim) * styleAlpha;
		const float grab_r = 6.f + 1.f * hoverAnim + 0.8f * activeAnim;
		window->DrawList->AddCircleFilled(ImVec2(fill_x, track_y), grab_r + 5.f, ImColor(accent.x, accent.y, accent.z, halo), 24);
		window->DrawList->AddCircleFilled(ImVec2(fill_x, track_y), grab_r + 1.f, ImColor(0.f, 0.f, 0.f, 0.35f * styleAlpha), 24);
		window->DrawList->AddCircleFilled(ImVec2(fill_x, track_y), grab_r, ImGui::GetColorU32(ImGuiCol_Button), 24);
	}

	ImGui::SameLine(0.f, trackGap);

	ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1.f, 1.f, 1.f, 0.05f));
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.f, 1.f, 1.f, 0.10f));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1.f, 1.f, 1.f, 0.16f));
	ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.f);
	if (AnimatedButton((std::string("+##inc") + label).c_str(), ImVec2(btnW, trackH)))
	{
		if constexpr (std::is_same_v<T, int>)
			*value = ImMin(max, *value + 1);
		else
			*value = ImMin(max, *value + (max - min) * 0.01f);
		value_changed = true;
	}
	ImGui::PopStyleVar();
	ImGui::PopStyleColor(3);

	ImGui::SetCursorPosX(startX);
	ImGui::Dummy(ImVec2(0.f, 4.f));

	IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | (temp_input_allowed ? ImGuiItemStatusFlags_Inputable : 0));
	return value_changed;
}

bool Menu::Slider(const char* label, int* value, int min, int max, ImVec2 size, const char* format, ImGuiSliderFlags flags)
{
	return SliderStacked(label, value, min, max, size, format, flags, ImGuiDataType_S32);
}

bool Menu::Slider(const char* label, float* value, float min, float max, ImVec2 size, const char* format, ImGuiSliderFlags flags)
{
	return SliderStacked(label, value, min, max, size, format, flags, ImGuiDataType_Float);
}

bool Menu::CheckboxBehavior(const char* label, bool* v)
{
	ImGuiWindow* window = ImGui::GetCurrentWindow();
	if (window->SkipItems)
		return false;

	ImGuiContext& g = *GImGui;
	const ImGuiStyle& style = g.Style;
	const ImGuiID id = window->GetID(label);
	const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

	const float height = 22.f;
	const float width = 40.f;
	const ImVec2 pos = window->DC.CursorPos;
	const float row_h = ImMax(height, label_size.y + style.FramePadding.y * 2.0f);
	const ImVec2 total_bb_max(pos.x + width + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), pos.y + row_h);
	const ImRect total_bb(pos, total_bb_max);
	ImGui::ItemSize(total_bb, style.FramePadding.y);
	if (!ImGui::ItemAdd(total_bb, id))
	{
		IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
		return false;
	}

	bool hovered, held;
	bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
	if (pressed)
	{
		*v = !(*v);
		ImGui::MarkItemEdited(id);
	}

	const float toggle_y = pos.y + (row_h - height) * 0.5f;
	const ImRect toggle_bb(ImVec2(pos.x, toggle_y), ImVec2(pos.x + width, toggle_y + height));
	ImGui::RenderNavHighlight(total_bb, id);

	const float styleAlpha = g.Style.Alpha;
	const float onAnim = Anim01((unsigned int)id ^ kAnimValue, *v ? 1.f : 0.f, 16.f);
	const float hoverAnim = Anim01((unsigned int)id ^ kAnimHover, hovered ? 1.f : 0.f, 14.f);
	const float pressAnim = Anim01((unsigned int)id ^ kAnimPress, held ? 1.f : 0.f, 24.f);

	// Track crossfades between subtle white (off) and accent (on)
	const ImVec4 offVec(1.f, 1.f, 1.f, 0.08f + 0.05f * hoverAnim);
	const ImVec4 onVec = AccentVec(1.f);
	ImVec4 trackVec = LerpVec4(offVec, onVec, onAnim);
	trackVec.w *= styleAlpha;

	// Soft accent glow bloom as the toggle turns on
	if (onAnim > 0.01f)
	{
		const float glow = (0.20f + 0.10f * hoverAnim) * onAnim * styleAlpha;
		window->DrawList->AddRectFilled(
			ImVec2(toggle_bb.Min.x - 3.f, toggle_bb.Min.y - 3.f),
			ImVec2(toggle_bb.Max.x + 3.f, toggle_bb.Max.y + 3.f),
			ImColor(onVec.x, onVec.y, onVec.z, glow), (height + 6.f) * 0.5f);
	}

	window->DrawList->AddRectFilled(toggle_bb.Min, toggle_bb.Max, ImColor(trackVec), height * 0.5f);

	// Knob glides between ends; grows slightly on hover, squashes while held
	const float knob_r = (height * 0.5f - 3.f) + 0.8f * hoverAnim - 1.2f * pressAnim;
	const float knob_min_x = toggle_bb.Min.x + (height * 0.5f);
	const float knob_max_x = toggle_bb.Max.x - (height * 0.5f);
	const float knob_x = Lerp(knob_min_x, knob_max_x, onAnim);
	const float knob_y = toggle_bb.Min.y + height * 0.5f;

	// Dark knob when on (reference style), light gray when off
	const ImVec4 knobOff(0.55f, 0.55f, 0.58f, 1.f);
	const ImVec4 knobOn(settings::Menu_SecondaryColor[0], settings::Menu_SecondaryColor[1], settings::Menu_SecondaryColor[2], 1.f);
	ImVec4 knobVec = LerpVec4(knobOff, knobOn, onAnim);
	knobVec.w *= styleAlpha;

	window->DrawList->AddCircleFilled(ImVec2(knob_x, knob_y + 0.5f), knob_r, ImColor(0.f, 0.f, 0.f, 0.25f * styleAlpha), 24);
	window->DrawList->AddCircleFilled(ImVec2(knob_x, knob_y), knob_r, ImColor(knobVec), 24);

	ImVec2 label_pos = ImVec2(toggle_bb.Max.x + style.ItemInnerSpacing.x, pos.y + (row_h - label_size.y) * 0.5f);
	if (g.LogEnabled)
		ImGui::LogRenderedText(&label_pos, *v ? "[x]" : "[ ]");
	if (label_size.x > 0.0f)
		ImGui::RenderText(label_pos, label);

	IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags | ImGuiItemStatusFlags_Checkable | (*v ? ImGuiItemStatusFlags_Checked : 0));
	return pressed;
}

bool Menu::Checkbox(const char* label, bool* v, ImVec2 size)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5.f);
	Menu::Text(label, FontSize::SIZE_18);
	ImGui::SameLine();

	const float w = 40.f; // Width of pill toggle
	const float space = size.x - font18->CalcTextSizeA(18, FLT_MAX, 0.0f, label).x - w;

	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space - 10);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.f);

	return CheckboxBehavior(("##" + std::string(label)).c_str(), v);
}

bool Menu::ColorEdit(const char* label, float* col, ImVec2 size, ImGuiColorEditFlags flags)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5.f);
	Menu::Text(label, FontSize::SIZE_18);
	ImGui::SameLine();

	const float w = 30.f; // Width of preview
	const float space = size.x - font18->CalcTextSizeA(18, FLT_MAX, 0.0f, label).x - w;

	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space - 10);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.f);

	return ImGui::ColorEdit4(("##" + std::string(label)).c_str(), col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | flags);
}

bool Menu::Dropdown(const char* label, const char* items[], int* item_current, int items_count, ImVec2 size)
{
	if (size.x == 0)
	{
		size.x = ImGui::GetWindowSize().x - 40.f;
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5.f);
	Menu::Text(label, FontSize::SIZE_18);
	ImGui::SameLine();

	const float w = 358.f; // Width of dropdown
	const float space = size.x - font18->CalcTextSizeA(18, FLT_MAX, 0.0f, label).x - w;

	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space - 10);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.f);

	return ImGui::Combo(("##" + std::string(label)).c_str(), item_current, items, items_count);
}

void Menu::MoveCursorToCenter(bool checkInGame)
{
	if (checkInGame && SDK::minecraft->IsInGuiState())
		return;

	RECT clientRect;
	if (GetClientRect(handleWindow, &clientRect)) {
		// Calculate the center of the client area
		int clientCenterX = (clientRect.right - clientRect.left) / 2;
		int clientCenterY = (clientRect.bottom - clientRect.top) / 2;

		// Create a POINT to hold the center in client coordinates
		POINT clientCenterPoint = { clientCenterX, clientCenterY };

		// Convert client coordinates to screen coordinates
		ClientToScreen(handleWindow, &clientCenterPoint);

		// Move the cursor to the center of the client area
		SetCursorPos(clientCenterPoint.x, clientCenterPoint.y);
	}
}

void Menu::Shutdown()
{
	Menu::open = false;
	Menu::openHudEditor = false;
	Menu::RemoveHooks();
	wglMakeCurrent(Menu::handleDeviceContext, Menu::originalGLContext);
	if (Menu::menuGLContext)
	{
		wglDeleteContext(Menu::menuGLContext);
		Menu::menuGLContext = nullptr;
	}
	//ImGui::DestroyContext(); // This is causing a crash
}

void Menu::PlaceHooks()
{
	Menu::Hook_wglSwapBuffers();
}

void Menu::RemoveHooks()
{
	Menu::Unhook_wndProc();
	Menu::Unhook_wglSwapBuffers();
}
