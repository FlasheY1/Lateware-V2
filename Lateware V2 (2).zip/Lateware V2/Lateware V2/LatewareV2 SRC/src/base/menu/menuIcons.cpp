#include "menuIcons.h"

#include <cstring>
#include <string>
#include <unordered_map>

#include <Windows.h>
#include <GL/gl.h>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_NO_STDIO
#define STB_IMAGE_STATIC
#include "stb/stb_image.h"

#include "menuIconAtlasData.h"

// itemIcons.cpp already defines STB_IMAGE_IMPLEMENTATION — avoid duplicate symbols.
// We use STB_IMAGE_STATIC so stbi_* are local to this TU.

namespace
{
	bool g_attempted = false;
	bool g_ready = false;
	GLuint g_tex = 0;
	std::unordered_map<std::string, ImVec2> g_uv0;
	std::unordered_map<std::string, ImVec2> g_uv1;
}

void MenuIcons::EnsureLoaded()
{
	if (g_attempted)
		return;
	g_attempted = true;

	int w = 0, h = 0, ch = 0;
	unsigned char* pixels = stbi_load_from_memory(
		MENU_ICON_ATLAS_PNG, (int)MENU_ICON_ATLAS_PNG_SIZE, &w, &h, &ch, 4);
	if (!pixels || w <= 0 || h <= 0)
	{
		if (pixels) stbi_image_free(pixels);
		return;
	}

	GLuint tex = 0;
	glGenTextures(1, &tex);
	if (!tex)
	{
		stbi_image_free(pixels);
		return;
	}

	GLint last = 0;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &last);
	glBindTexture(GL_TEXTURE_2D, tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
	glBindTexture(GL_TEXTURE_2D, (GLuint)last);
	stbi_image_free(pixels);

	g_tex = tex;
	const float invW = 1.f / (float)w;
	const float invH = 1.f / (float)h;
	for (int i = 0; i < MENU_ICON_COUNT; ++i)
	{
		const MenuIconEntry& e = MENU_ICON_ENTRIES[i];
		g_uv0[e.name] = ImVec2((float)e.x * invW, (float)e.y * invH);
		g_uv1[e.name] = ImVec2((float)(e.x + MENU_ICON_TILE) * invW, (float)(e.y + MENU_ICON_TILE) * invH);
	}
	g_ready = true;
}

ImTextureID MenuIcons::GetAtlas()
{
	EnsureLoaded();
	return g_ready ? (ImTextureID)(intptr_t)g_tex : (ImTextureID)0;
}

bool MenuIcons::GetUv(const char* name, ImVec2& uvMin, ImVec2& uvMax)
{
	EnsureLoaded();
	if (!g_ready || !name)
		return false;
	auto it = g_uv0.find(name);
	if (it == g_uv0.end())
		return false;
	uvMin = it->second;
	uvMax = g_uv1[name];
	return true;
}

void MenuIcons::Draw(ImDrawList* draw, const char* name, ImVec2 min, ImVec2 max, float alpha)
{
	if (!draw)
		return;
	ImVec2 uv0, uv1;
	if (!GetUv(name, uv0, uv1))
		return;
	draw->AddImage(GetAtlas(), min, max, uv0, uv1, ImColor(1.f, 1.f, 1.f, alpha));
}
