#include "menu.h"
#include "menuIcons.h"

#include <cmath>
#include <unordered_map>

#include <imgui/imgui_internal.h>

#include "base/base.h"
#include "moduleManager/moduleManager.h"
#include "moduleManager/commonData.h"
#include "sdk/net/minecraft/client/Minecraft.h"
#include "util/logger.h"
#include "util/window/borderless.h"
#include "configManager/configManager.h"
#include "notificationManager/notificationManager.h"

namespace
{
	constexpr float kSidebarW = 236.f;
	constexpr float kContentPad = 28.f;
	constexpr float kSidePad = 20.f;
	constexpr float kPillH = 42.f;
	constexpr float kPillGap = 8.f;
	constexpr float kChipH = 40.f;
	constexpr float kChipGapX = 12.f;
	constexpr float kChipGapY = 12.f;
	constexpr float kSectionGap = 20.f;
	constexpr float kIconSz = 22.f;
	constexpr float kIconPad = 10.f;
	constexpr float kProfileH = 84.f;
	constexpr float kProfileBottomPad = 22.f;

	constexpr int CATEGORY_FONT_SIZE_INT = 17;
	constexpr int MODULE_FONT_SIZE_INT = 15;

	ImU32 AccentCol(float a = 1.f)
	{
		return ImColor(
			settings::Menu_PrimaryColor[0],
			settings::Menu_PrimaryColor[1],
			settings::Menu_PrimaryColor[2],
			settings::Menu_PrimaryColor[3] * a);
	}

	float& HoverAnim(ImGuiID id)
	{
		static std::unordered_map<ImGuiID, float> s_map;
		return s_map[id];
	}

	float EaseOutCubic(float t)
	{
		const float u = 1.f - t;
		return 1.f - u * u * u;
	}

	float EaseOutQuint(float t)
	{
		const float u = 1.f - t;
		return 1.f - u * u * u * u * u;
	}

	// Slight overshoot for a springy, "alive" open animation
	float EaseOutBack(float t)
	{
		const float c1 = 1.70158f;
		const float c3 = c1 + 1.f;
		const float u = t - 1.f;
		return 1.f + c3 * u * u * u + c1 * u * u;
	}

	ImVec2 CalcModuleChipSize(const char* label)
	{
		ImFont* font = Menu::font16 ? Menu::font16 : ImGui::GetFont();
		const ImVec2 textSize = font->CalcTextSizeA((float)MODULE_FONT_SIZE_INT, FLT_MAX, 0.f, label);
		const float iconBox = 20.f;
		return ImVec2(kIconPad + iconBox + 10.f + textSize.x + 16.f, kChipH);
	}

	bool SidebarPill(const char* label, bool selected, ImVec2 size)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems)
			return false;

		const ImGuiID id = window->GetID(label);
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb);
		if (!ImGui::ItemAdd(bb, id))
			return false;

		bool hovered = false, held = false;
		const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		const float dt = ImGui::GetIO().DeltaTime;
		const float styleAlpha = ImGui::GetStyle().Alpha;

		float& hoverAnim = HoverAnim(id);
		hoverAnim = Menu::Approach(hoverAnim, (!selected && hovered) ? 1.f : 0.f, 16.f, dt);
		float& selAnim = HoverAnim(id ^ 0x51EDu);
		selAnim = Menu::Approach(selAnim, selected ? 1.f : 0.f, 14.f, dt);

		ImDrawList* draw = window->DrawList;
		const float radius = size.y * 0.5f;

		// Selection fill is drawn by the sliding indicator; pills only add a soft hover wash
		if (hoverAnim > 0.01f)
			draw->AddRectFilled(bb.Min, bb.Max, ImColor(1.f, 1.f, 1.f, (0.05f + 0.08f * hoverAnim) * styleAlpha), radius);

		const float iconBox = kIconSz;
		const ImVec2 iconMin(bb.Min.x + kIconPad + 4.f, bb.Min.y + (size.y - iconBox) * 0.5f);
		const ImVec2 iconMax(iconMin.x + iconBox, iconMin.y + iconBox);
		MenuIcons::Draw(draw, label, iconMin, iconMax, (0.80f + 0.20f * ImMax(selAnim, hoverAnim)) * styleAlpha);

		ImFont* font = Menu::font18 ? Menu::font18 : ImGui::GetFont();
		const ImVec2 textSize = font->CalcTextSizeA((float)CATEGORY_FONT_SIZE_INT, FLT_MAX, 0.f, label);
		const ImVec2 textPos(
			iconMax.x + 10.f,
			bb.Min.y + (size.y - textSize.y) * 0.5f);

		const ImVec4 idle(0.70f, 0.70f, 0.74f, 1.f);
		const ImVec4 hot = Menu::AccentVec(1.f);
		const ImVec4 sel(1.f, 1.f, 1.f, 1.f);
		ImVec4 col = Menu::LerpVec4(idle, hot, hoverAnim);
		col = Menu::LerpVec4(col, sel, selAnim);
		col.w *= styleAlpha;
		draw->AddText(font, (float)CATEGORY_FONT_SIZE_INT, textPos, ImColor(col), label);

		return pressed;
	}

	bool ModuleChip(const char* label, bool selected)
	{
		ImFont* font = Menu::font16 ? Menu::font16 : ImGui::GetFont();
		const ImVec2 textSize = font->CalcTextSizeA((float)MODULE_FONT_SIZE_INT, FLT_MAX, 0.f, label);
		const float iconBox = 20.f;
		const ImVec2 size = CalcModuleChipSize(label);

		ImGuiWindow* window = ImGui::GetCurrentWindow();
		const ImGuiID id = window->GetID(label);
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb);
		if (!ImGui::ItemAdd(bb, id))
			return false;

		bool hovered = false, held = false;
		const bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		const float dt = ImGui::GetIO().DeltaTime;
		const float styleAlpha = ImGui::GetStyle().Alpha;

		float& hoverAnim = HoverAnim(id);
		hoverAnim = Menu::Approach(hoverAnim, hovered ? 1.f : 0.f, 16.f, dt);
		float& selAnim = HoverAnim(id ^ 0x51EDu);
		selAnim = Menu::Approach(selAnim, selected ? 1.f : 0.f, 14.f, dt);
		float& pressAnim = HoverAnim(id ^ 0x7F4Au);
		pressAnim = Menu::Approach(pressAnim, held ? 1.f : 0.f, 24.f, dt);

		ImDrawList* draw = window->DrawList;
		const float radius = 12.f;

		// Chip fill crossfades from subtle white (idle/hover) into the accent (selected)
		const ImVec4 idleFill(1.f, 1.f, 1.f, 0.04f + 0.08f * hoverAnim);
		ImVec4 fillVec = Menu::LerpVec4(idleFill, Menu::AccentVec(0.92f), selAnim);
		fillVec.w *= styleAlpha * (1.f - 0.10f * pressAnim);

		// Soft accent glow underneath the selected chip
		if (selAnim > 0.01f)
			draw->AddRectFilled(
				ImVec2(bb.Min.x - 2.f, bb.Min.y - 2.f),
				ImVec2(bb.Max.x + 2.f, bb.Max.y + 2.f),
				AccentCol(0.16f * selAnim * styleAlpha), radius + 2.f);

		draw->AddRectFilled(bb.Min, bb.Max, ImColor(fillVec), radius);

		const float borderA = (0.25f * hoverAnim + 0.40f * selAnim) * styleAlpha;
		if (borderA > 0.01f)
			draw->AddRect(bb.Min, bb.Max, AccentCol(borderA), radius, 0, 1.2f);

		const ImVec2 iconMin(bb.Min.x + kIconPad, bb.Min.y + (size.y - iconBox) * 0.5f);
		const ImVec2 iconMax(iconMin.x + iconBox, iconMin.y + iconBox);
		MenuIcons::Draw(draw, label, iconMin, iconMax, (0.9f + 0.1f * ImMax(hoverAnim, selAnim)) * styleAlpha);

		const ImVec2 textPos(iconMax.x + 10.f, bb.Min.y + (size.y - textSize.y) * 0.5f);
		const ImVec4 idle(0.72f, 0.72f, 0.76f, 1.f);
		const ImVec4 hot = Menu::AccentVec(1.f);
		const ImVec4 sel(1.f, 1.f, 1.f, 1.f);
		ImVec4 col = Menu::LerpVec4(idle, hot, hoverAnim);
		col = Menu::LerpVec4(col, sel, selAnim);
		col.w *= styleAlpha;
		draw->AddText(font, (float)MODULE_FONT_SIZE_INT, textPos, ImColor(col), label);

		return pressed;
	}

	// Wrap module chips across rows instead of one cramped horizontal strip.
	void DrawWrappedModuleChips(
		std::vector<std::unique_ptr<ModuleBase>>& modules,
		const std::string& category,
		int& selectedModule,
		float availWidth)
	{
		float rowX = 0.f;
		bool firstInRow = true;

		for (int i = 0; i < (int)modules.size(); i++)
		{
			if (modules[i]->GetCategory() != category)
				continue;

			const ImVec2 chipSize = CalcModuleChipSize(modules[i]->GetName().c_str());
			if (!firstInRow && rowX + chipSize.x > availWidth)
			{
				rowX = 0.f;
				firstInRow = true;
			}

			if (!firstInRow)
				ImGui::SameLine(0.f, kChipGapX);

			if (ModuleChip(modules[i]->GetName().c_str(), i == selectedModule))
				selectedModule = i;

			rowX += chipSize.x + kChipGapX;
			firstInRow = false;
		}
	}
}

std::unique_ptr<std::once_flag> setConfigName = std::make_unique<std::once_flag>();

void Menu::RenderMenu()
{
	static int selectedCategory = 0;
	static int selectedModule = 0;
	static int prevCategory = 0;
	static float categoryAnim = 1.f;
	static float categorySlideDir = 1.f;
	static int prevModule = -1;
	static float moduleAnim = 1.f;

	std::vector<std::string> categories = ModuleManager::GetCategories();
	std::vector<std::unique_ptr<ModuleBase>>& modules = ModuleManager::GetModules();

	if (categories.empty() || modules.empty())
		return;

	MenuIcons::EnsureLoaded();

	if (!Menu::openHudEditor && selectedCategory == -2 && selectedModule == 3)
		Menu::openHudEditor = true;
	else if (Menu::openHudEditor && (selectedCategory != -2 || selectedModule != 3))
		Menu::openHudEditor = false;

	// Category change → slide content
	if (selectedCategory != prevCategory)
	{
		categorySlideDir = (selectedCategory > prevCategory) ? 1.f : -1.f;
		categoryAnim = 0.f;
		prevCategory = selectedCategory;
	}
	categoryAnim = Menu::Approach(categoryAnim, 1.f, 9.f, ImGui::GetIO().DeltaTime);
	if (categoryAnim > 0.999f) categoryAnim = 1.f;

	// Module change → settings panel fades in and rises into place
	if (selectedModule != prevModule)
	{
		moduleAnim = 0.f;
		prevModule = selectedModule;
	}
	moduleAnim = Menu::Approach(moduleAnim, 1.f, 10.f, ImGui::GetIO().DeltaTime);
	if (moduleAnim > 0.999f) moduleAnim = 1.f;

	const float anim = EaseOutQuint(Menu::openAnim);
	const float alpha = anim;
	const float slide = (1.f - anim) * 36.f;
	// Springy scale with a slight overshoot; fade uses the smoother quint ease
	const float scale = 0.94f + 0.06f * EaseOutBack(Menu::openAnim);

	const ImVec2 display = ImGui::GetIO().DisplaySize;
	const ImVec2 baseSize(1080.f, 680.f);
	const ImVec2 winSize(baseSize.x * scale, baseSize.y * scale);
	const ImVec2 winPos(
		(display.x - winSize.x) * 0.5f,
		(display.y - winSize.y) * 0.5f + slide);

	// Dim the game behind the menu and lay a soft drop shadow under the window.
	// The background draw list renders beneath every ImGui window.
	{
		ImDrawList* bgDraw = ImGui::GetBackgroundDrawList();
		bgDraw->AddRectFilled(ImVec2(0.f, 0.f), display, ImColor(0.f, 0.f, 0.f, 0.42f * alpha));

		const int shadowLayers = 8;
		for (int i = 0; i < shadowLayers; i++)
		{
			const float expand = 2.f + (float)i * 4.f;
			const float a = 0.055f * alpha * (1.f - (float)i / (float)shadowLayers);
			bgDraw->AddRect(
				ImVec2(winPos.x - expand, winPos.y - expand + 5.f),
				ImVec2(winPos.x + winSize.x + expand, winPos.y + winSize.y + expand + 5.f),
				ImColor(0.f, 0.f, 0.f, a),
				settings::Menu_WindowRounding + expand, 0, 4.5f);
		}

		// Faint accent bloom hugging the window
		bgDraw->AddRect(
			ImVec2(winPos.x - 3.f, winPos.y - 3.f),
			ImVec2(winPos.x + winSize.x + 3.f, winPos.y + winSize.y + 3.f),
			AccentCol(0.10f * alpha), settings::Menu_WindowRounding + 3.f, 0, 3.f);
	}

	ImGui::SetNextWindowPos(winPos, ImGuiCond_Always);
	ImGui::SetNextWindowSize(winSize, ImGuiCond_Always);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.f, 0.f));
	ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
	ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
	ImGui::Begin("Lateware V2", nullptr,
		ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar |
		ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
		ImGuiWindowFlags_NoMove);
	{
		const ImVec2 wpos = ImGui::GetWindowPos();
		const ImVec2 wsize = ImGui::GetWindowSize();
		ImDrawList* rootDraw = ImGui::GetWindowDrawList();

		// Soft glow border
		rootDraw->AddRect(wpos, ImVec2(wpos.x + wsize.x, wpos.y + wsize.y),
			AccentCol(0.18f * alpha), settings::Menu_WindowRounding, 0, 1.5f);
		rootDraw->AddRect(wpos, ImVec2(wpos.x + wsize.x, wpos.y + wsize.y),
			ImColor(1.f, 1.f, 1.f, 0.06f * alpha), settings::Menu_WindowRounding, 0, 1.f);

		const float sidebarW = kSidebarW;

		// ── Sidebar ──────────────────────────────────────────────
		ImGui::SetCursorPos(ImVec2(0.f, 0.f));
		ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.045f, 0.045f, 0.055f, 1.f));
		ImGui::BeginChild("##Sidebar", ImVec2(sidebarW, wsize.y), false,
			ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
		{
			ImGui::SetCursorPos(ImVec2(kSidePad, 28.f));
			Menu::BoldText(Base::m_name, FontSize::SIZE_22);
			if (Base::m_version && Base::m_version[0] != '\0')
			{
				ImGui::SetCursorPosX(kSidePad);
				Menu::TextColored(Base::m_version, ImVec4(1.f, 1.f, 1.f, 0.38f), FontSize::SIZE_14);
			}

			ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

			// Sidebar ItemSpacing is 12px globally; zero it here so pill gaps
			// are only kPillGap. Otherwise Friends/Configs/Settings fall past
			// the profile card and get clipped by navBottomLimit.
			ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.f, 0.f));

			const float pillW = sidebarW - kSidePad * 2.f;
			const float profileTop = wsize.y - kProfileH - kProfileBottomPad;

			static const char* extra[] = { "Friends", "Configs", "Settings" };
			static const int extraId[] = { -3, -1, -2 };
			constexpr int extraCount = 3;
			const float extraBlockH = extraCount * kPillH + (extraCount - 1) * kPillGap;
			const float extraStartY = profileTop - 20.f - extraBlockH;
			const float navBottomLimit = extraStartY - 12.f;

			// Sliding selection indicator. The target Y (relative to the window so
			// the open animation doesn't drag it around) is captured while laying
			// out pills, so we draw with last frame's target; the ease hides the
			// one-frame lag and makes selection glide between categories.
			static float s_indTargetY = -1.f;
			static float s_indY = -1.f;
			if (s_indTargetY >= 0.f)
			{
				if (s_indY < 0.f) s_indY = s_indTargetY;
				s_indY = Menu::Approach(s_indY, s_indTargetY, 14.f, ImGui::GetIO().DeltaTime);

				ImDrawList* indDraw = ImGui::GetWindowDrawList();
				const ImVec2 indMin(wpos.x + kSidePad, wpos.y + s_indY);
				const ImVec2 indMax(wpos.x + kSidePad + pillW, wpos.y + s_indY + kPillH);
				indDraw->AddRectFilled(
					ImVec2(indMin.x - 2.f, indMin.y - 2.f),
					ImVec2(indMax.x + 2.f, indMax.y + 2.f),
					AccentCol(0.18f * alpha), (kPillH + 4.f) * 0.5f);
				indDraw->AddRectFilled(indMin, indMax, AccentCol(0.92f * alpha), kPillH * 0.5f);
				indDraw->AddRectFilled(
					ImVec2(indMin.x + 4.f, indMin.y + 10.f),
					ImVec2(indMin.x + 7.f, indMax.y - 10.f),
					ImColor(1.f, 1.f, 1.f, 0.95f * alpha), 2.f);
			}

			auto tryPill = [&](const char* label, bool selected, int onSelectCategory, int onSelectModule, bool clipToNav) -> bool
			{
				// Keep module pills from colliding with Friends/Configs/Settings.
				if (clipToNav && ImGui::GetCursorPosY() + kPillH > navBottomLimit)
					return false;

				ImGui::SetCursorPosX(kSidePad);
				if (selected)
					s_indTargetY = ImGui::GetCursorScreenPos().y - wpos.y;
				const bool pressed = SidebarPill(label, selected, ImVec2(pillW, kPillH));
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kPillGap);
				if (pressed)
				{
					selectedCategory = onSelectCategory;
					selectedModule = onSelectModule;
				}
				return pressed;
			};

			for (int i = 0; i < (int)categories.size(); i++)
			{
				tryPill(categories[i].c_str(), selectedCategory == i, i,
					ModuleManager::GetFirstModuleIndexByCategory(categories[i]), true);
			}

			if (ImGui::GetCursorPosY() + 8.f < extraStartY)
			{
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.f);
				ImGui::SetCursorPosX(kSidePad);
				Menu::HorizontalSeparator("SideSep", pillW, 1.f);
			}

			ImGui::SetCursorPosY(extraStartY);
			for (int i = 0; i < extraCount; ++i)
				tryPill(extra[i], selectedCategory == extraId[i], extraId[i], 0, false);

			ImGui::PopStyleVar();

			// Profile card — roomy bottom block so username isn't crushed
			std::string userName = CommonData::CopyPlayerName();
			if (userName.empty() || !CommonData::dataUpdated)
				userName = "Player";

			ImDrawList* sideDraw = ImGui::GetWindowDrawList();
			const ImVec2 cardMin(wpos.x + kSidePad, wpos.y + profileTop);
			const ImVec2 cardMax(wpos.x + sidebarW - kSidePad, wpos.y + profileTop + kProfileH);
			sideDraw->AddRectFilled(cardMin, cardMax, ImColor(1.f, 1.f, 1.f, 0.04f), 14.f);
			sideDraw->AddRect(cardMin, cardMax, ImColor(1.f, 1.f, 1.f, 0.06f), 14.f, 0, 1.f);

			const float avatarR = 16.f;
			const ImVec2 avatarC(cardMin.x + 22.f, (cardMin.y + cardMax.y) * 0.5f);
			const float pulse = 0.5f + 0.5f * sinf((float)ImGui::GetTime() * 2.0f);
			sideDraw->AddCircleFilled(avatarC, avatarR + 3.f + pulse, AccentCol(0.14f + 0.08f * pulse), 28);
			sideDraw->AddCircleFilled(avatarC, avatarR, AccentCol(0.85f), 28);
			sideDraw->AddCircle(avatarC, avatarR, ImColor(1.f, 1.f, 1.f, 0.18f), 28, 1.2f);

			ImFont* nameFont = Menu::boldFont18 ? Menu::boldFont18 : Menu::fontBold;
			ImFont* subFont = Menu::font14 ? Menu::font14 : Menu::font;
			const float textLeft = avatarC.x + avatarR + 12.f;
			const float textMaxW = cardMax.x - textLeft - 10.f;

			// Truncate long usernames so they never collide with the card edge
			std::string displayName = userName;
			ImVec2 nameSz = nameFont->CalcTextSizeA(17.f, FLT_MAX, 0.f, displayName.c_str());
			if (nameSz.x > textMaxW && textMaxW > 20.f)
			{
				while (displayName.size() > 1)
				{
					displayName.pop_back();
					std::string trial = displayName + "...";
					if (nameFont->CalcTextSizeA(17.f, FLT_MAX, 0.f, trial.c_str()).x <= textMaxW)
					{
						displayName = trial;
						break;
					}
				}
			}

			const ImVec2 namePos(textLeft, avatarC.y - 16.f);
			sideDraw->AddText(nameFont, 17.f, namePos, ImColor(1.f, 1.f, 1.f, 1.f), displayName.c_str());
			sideDraw->AddText(subFont, 13.f,
				ImVec2(textLeft, namePos.y + 22.f),
				ImColor(0.55f, 0.55f, 0.60f, 1.f),
				"in-game");
		}
		ImGui::EndChild();
		ImGui::PopStyleColor();

		rootDraw->AddLine(
			ImVec2(wpos.x + sidebarW, wpos.y + 14.f),
			ImVec2(wpos.x + sidebarW, wpos.y + wsize.y - 14.f),
			ImColor(1.f, 1.f, 1.f, 0.06f), 1.f);

		// ── Content ──────────────────────────────────────────────
		ImGui::SetCursorPos(ImVec2(sidebarW, 0.f));
		ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(
			settings::Menu_BackgroundColor[0],
			settings::Menu_BackgroundColor[1],
			settings::Menu_BackgroundColor[2],
			1.f));
		ImGui::BeginChild("##Content", ImVec2(wsize.x - sidebarW, wsize.y), false);
		{
			const float catEase = EaseOutQuint(categoryAnim);
			const float contentSlideX = (1.f - catEase) * 56.f * categorySlideDir;
			const float contentAlpha = 0.35f + 0.65f * catEase;

			ImGui::SetCursorPos(ImVec2(kContentPad + contentSlideX, kContentPad));
			ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * contentAlpha);
			ImGui::BeginGroup();

			const float chipAvail = wsize.x - sidebarW - kContentPad * 2.f;

			if (selectedCategory >= 0)
			{
				if (selectedCategory >= (int)categories.size())
					selectedCategory = 0;

				if (selectedModule >= (int)modules.size() || selectedModule < 0)
					selectedModule = ModuleManager::GetFirstModuleIndexByCategory(categories[selectedCategory]);

				DrawWrappedModuleChips(modules, categories[selectedCategory], selectedModule, chipAvail);

				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
				Menu::HorizontalSeparator("ContentSep", ImGui::GetContentRegionAvail().x, 1.f);
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

				if (selectedModule >= 0 && selectedModule < (int)modules.size())
				{
					const float modEase = EaseOutQuint(moduleAnim);
					ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * (0.20f + 0.80f * modEase));
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (1.f - modEase) * 12.f);
					ImGui::BeginGroup();

					Menu::BoldText(modules[selectedModule]->GetName().c_str(), FontSize::SIZE_24);
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 12.f);

					modules[selectedModule]->RenderMenu();

					ImGui::EndGroup();
					ImGui::PopStyleVar();
				}
			}
			else if (selectedCategory == -1) // Configs
			{
				Menu::BoldText("Configs", FontSize::SIZE_22);
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

				static std::vector<std::string> configFiles = configmanager::GetConfigList();
				static int selectedConfig = 0;
				std::string selectedConfigName = configFiles.size() > 0 && configFiles.size() > selectedConfig ? configFiles[selectedConfig] : "null";

				ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.f, 0.f, 0.f, 0.f));
				ImGui::BeginChild("###ConfigLits", ImVec2(0, 400.f));
				{
					bool hasScrollbar = ImGui::GetCurrentWindow()->ScrollMax.y > 0.0f;

					for (int i = 0; i < (int)configFiles.size(); ++i)
					{
						bool deleted = false;
						if (Menu::ConfigItem(configFiles[i].c_str(), &deleted, hasScrollbar))
						{
							selectedConfig = i;
							setConfigName = std::make_unique<std::once_flag>();
						}

						if (deleted)
						{
							if (configmanager::RemoveConfig(i))
								NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" has been removed.", configFiles[i].c_str());
							else
								NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" could not be removed.", configFiles[i].c_str());

							configFiles = configmanager::GetConfigList();
							if (selectedConfig == i)
							{
								selectedConfig = 0;
								setConfigName = std::make_unique<std::once_flag>();
							}
						}
					}
				}
				ImGui::EndChild();
				ImGui::PopStyleColor();

				ImVec2 openButtonSize = Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Open Folder");
				openButtonSize.x += ImGui::GetStyle().FramePadding.x * 8;
				ImVec2 refreshButtonSize = Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Refresh");
				refreshButtonSize.x += ImGui::GetStyle().FramePadding.x * 8;

				if (Menu::Button(("Load \"" + selectedConfigName + "\"").c_str(), ImVec2(ImGui::GetWindowSize().x - openButtonSize.x - refreshButtonSize.x - 56.f, 30.f)))
				{
					if (configFiles.size() > 0)
					{
						if (configmanager::LoadConfig(selectedConfig))
						{
							NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" has been loaded.", selectedConfigName.c_str());
							Menu::ResetSetupFlags();
						}
						else
						{
							NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" could not be loaded.", selectedConfigName.c_str());
						}
					}
				}

				ImGui::SameLine();
				if (Menu::Button("Open Folder", ImVec2(openButtonSize.x, 30.f)))
					ShellExecuteA(NULL, "open", configmanager::GetConfigPath().c_str(), NULL, NULL, SW_SHOWNORMAL);

				ImGui::SameLine();
				if (Menu::Button("Refresh", ImVec2(refreshButtonSize.x, 30.f)))
				{
					configFiles = configmanager::GetConfigList();
					NotificationManager::Send("Lateware V2 :: Config", "Config list has been refreshed.");
				}

				ImVec2 saveButtonSize = Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Save");
				saveButtonSize.x += ImGui::GetStyle().FramePadding.x * 8;
				saveButtonSize.y += ImGui::GetStyle().FramePadding.y * 2;

				static char saveConfigName[128] = "";
				std::call_once(*setConfigName, []() {
					const char* selectedConfigNameC = configFiles.size() > 0 ? configFiles[selectedConfig].c_str() : "";
					strcpy_s(saveConfigName, selectedConfigNameC);
					});

				ImGui::SetNextItemWidth(ImGui::GetWindowSize().x + 190.f - saveButtonSize.x);
				ImGui::InputText("##saveConfigName", saveConfigName, IM_ARRAYSIZE(saveConfigName));
				ImGui::SameLine();
				if (Menu::Button("Save", ImVec2(saveButtonSize.x, 30.f)))
				{
					int result = configmanager::SaveConfig(saveConfigName);
					if (result != -1)
					{
						configFiles = configmanager::GetConfigList();
						selectedConfig = result;
						NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" has been saved.", saveConfigName);
					}
					else
					{
						NotificationManager::Send("Lateware V2 :: Config", "Config \"%s\" could not be saved.", saveConfigName);
					}
				}
			}
			else if (selectedCategory == -3) // Friends
			{
				Menu::BoldText("Friends", FontSize::SIZE_22);
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

				std::vector<std::string> friends = settings::friends;

				ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.f, 0.f, 0.f, 0.f));
				ImGui::BeginChild("###FriendsLits", ImVec2(0, 440.f));
				{
					bool hasScrollbar = ImGui::GetCurrentWindow()->ScrollMax.y > 0.0f;
					for (int i = 0; i < (int)friends.size(); ++i)
					{
						bool deleted = false;
						Menu::ConfigItem(friends[i].c_str(), &deleted, hasScrollbar);
						if (deleted)
						{
							if (configmanager::RemoveFriend(friends[i].c_str()))
								NotificationManager::Send("Lateware V2 :: Friends", "Friend \"%s\" has been removed.", friends[i].c_str());
							else
								NotificationManager::Send("Lateware V2 :: Friends", "Friend \"%s\" could not be removed.", friends[i].c_str());
						}
					}
				}
				ImGui::EndChild();
				ImGui::PopStyleColor();

				ImVec2 addFriendButtonSize = Menu::font18->CalcTextSizeA(18, FLT_MAX, 0.0f, "Add");
				addFriendButtonSize.x += ImGui::GetStyle().FramePadding.x * 8;

				static char newFriendName[128] = "";
				ImGui::SetNextItemWidth(ImGui::GetWindowSize().x + 190.f - addFriendButtonSize.x);
				ImGui::InputText("##addFriendName", newFriendName, IM_ARRAYSIZE(newFriendName));
				ImGui::SameLine();
				if (Menu::Button("Add", ImVec2(addFriendButtonSize.x, 30.f)))
				{
					if (configmanager::AddFriend(newFriendName))
						NotificationManager::Send("Lateware V2 :: Friends", "Friend \"%s\" has been added.", newFriendName);
					else
						NotificationManager::Send("Lateware V2 :: Friends", "Friend \"%s\" could not be added.", newFriendName);
				}
			}
			else if (selectedCategory == -2) // Settings
			{
				static const char* settingTabs[] = { "HUD", "General", "Style" };
				static int settingView = 0;
				const int settingModuleMap[] = { 3, 0, 2 };

				ImGui::BeginGroup();
				for (int i = 0; i < 3; i++)
				{
					if (i > 0) ImGui::SameLine(0.f, kChipGapX);
					if (ModuleChip(settingTabs[i], settingView == i))
					{
						settingView = i;
						selectedModule = settingModuleMap[i];
					}
				}
				ImGui::EndGroup();

				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
				Menu::HorizontalSeparator("SettingsSep", ImGui::GetContentRegionAvail().x, 1.f);
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

				selectedModule = settingModuleMap[settingView];

				const float settingsEase = EaseOutQuint(moduleAnim);
				ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * (0.20f + 0.80f * settingsEase));
				ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (1.f - settingsEase) * 12.f);
				ImGui::BeginGroup();

				if (selectedModule == 0)
				{
					Menu::KeybindButton("Menu", settings::Menu_Keybind, false);
					Menu::KeybindButton("Detach", settings::Menu_DetachKey, false);

					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
					Menu::HorizontalSeparator("Sep1");
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

					Menu::Checkbox("GUI Movement", &settings::Menu_GUIMovement);

					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
					if (Menu::DetachButton("Detach Client", ImVec2(180.f, 34.f), FontSize::SIZE_18))
						Base::m_running = false;
				}
				else if (selectedModule == 2)
				{
					if (Menu::ColorEdit("Primary Color", settings::Menu_PrimaryColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Secondary Color", settings::Menu_SecondaryColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Background Color", settings::Menu_BackgroundColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Child Background Color", settings::Menu_ChildBackgroundColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Outline Color", settings::Menu_OutlineColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Text Color", settings::Menu_TextColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Seperator Color", settings::Menu_SeperatorColor)) Menu::SetupStyle();
					if (Menu::ColorEdit("Detach Button Color", settings::Menu_DetachButtonColor)) Menu::SetupStyle();

					if (Menu::Slider("Window Rounding", &settings::Menu_WindowRounding, 0.f, 18.f)) Menu::SetupStyle();
					if (Menu::Slider("Item Rounding", &settings::Menu_ComponentsRounding, 0.f, 14.f)) Menu::SetupStyle();
				}
				else if (selectedModule == 3)
				{
					Menu::Checkbox("Disable all Hud/Overlay rendering", &settings::Hud_DisableAllRendering);

					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
					Menu::HorizontalSeparatorText("Watermark", FontSize::SIZE_18);
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

					Menu::Checkbox("Show Watermark", &settings::Hud_Watermark);
					Menu::Checkbox("Version", &settings::Hud_WatermarkVersion);
					Menu::Checkbox("FPS", &settings::Hud_WatermarkFps);
					Menu::Checkbox("Ping", &settings::Hud_WatermarkPing);
					Menu::Checkbox("Coordinates", &settings::Hud_WatermarkCoords);
					Menu::Checkbox("Direction", &settings::Hud_WatermarkDirection);
					Menu::Checkbox("Time", &settings::Hud_WatermarkTime);

					if (Menu::Slider("X Position##Watermark", &settings::Hud_WatermarkPosition[0], 0.f, 1920.f)) Menu::ResetSetupFlags();
					if (Menu::Slider("Y Position##Watermark", &settings::Hud_WatermarkPosition[1], 0.f, 1080.f)) Menu::ResetSetupFlags();

					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
					Menu::HorizontalSeparatorText("Keybinds", FontSize::SIZE_18);
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

					Menu::Checkbox("Show Keybinds", &settings::Hud_ShowKeybinds);
					if (Menu::Slider("X Position##Keybinds", &settings::Hud_KeybindsPosition[0], 0.f, 1920.f)) Menu::ResetSetupFlags();
					if (Menu::Slider("Y Position##Keybinds", &settings::Hud_KeybindsPosition[1], 0.f, 1080.f)) Menu::ResetSetupFlags();

					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);
					Menu::HorizontalSeparatorText("Radar", FontSize::SIZE_18);
					ImGui::SetCursorPosY(ImGui::GetCursorPosY() + kSectionGap);

					if (Menu::Slider("X Position##Radar", &settings::Radar_Position[0], 0.f, 1920.f)) Menu::ResetSetupFlags();
					if (Menu::Slider("Y Position##Radar", &settings::Radar_Position[1], 0.f, 1080.f)) Menu::ResetSetupFlags();
					if (Menu::Slider("Size", &settings::Radar_Size, 0.f, 500.f)) Menu::ResetSetupFlags();
					Menu::Slider("Rounding", &settings::Radar_SquareRoundness, 0.f, 100.f);
				}

				ImGui::EndGroup();
				ImGui::PopStyleVar(); // settings tab fade
			}
			else
			{
				selectedCategory = 0;
			}

			ImGui::EndGroup();
			ImGui::PopStyleVar(); // content slide alpha
		}
		ImGui::EndChild();
		ImGui::PopStyleColor();
	}
	ImGui::End();
	ImGui::PopStyleVar(3);
}
