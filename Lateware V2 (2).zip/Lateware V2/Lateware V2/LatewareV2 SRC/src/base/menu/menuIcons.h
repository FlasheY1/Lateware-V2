#pragma once

#include <imgui/imgui.h>

struct MenuIcons
{
	static void EnsureLoaded();
	static bool GetUv(const char* name, ImVec2& uvMin, ImVec2& uvMax);
	static ImTextureID GetAtlas();
	static void Draw(ImDrawList* draw, const char* name, ImVec2 min, ImVec2 max, float alpha = 1.f);
};
