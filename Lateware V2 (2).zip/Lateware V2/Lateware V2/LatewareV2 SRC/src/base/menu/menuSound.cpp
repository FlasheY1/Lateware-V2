#include "menuSound.h"

#include <cstdio>
#include <string>

#include <Windows.h>
#include <mmsystem.h>

#include "menuOpenSoundData.h"

#pragma comment(lib, "winmm.lib")

namespace
{
	std::string g_tempPath;
	bool g_extracted = false;

	bool EnsureExtracted()
	{
		if (g_extracted && !g_tempPath.empty())
			return true;

		char tempDir[MAX_PATH]{};
		const DWORD n = GetTempPathA(MAX_PATH, tempDir);
		if (n == 0 || n >= MAX_PATH)
			return false;

		g_tempPath = std::string(tempDir) + "LatewareV2_menu_open.mp3";

		HANDLE h = CreateFileA(g_tempPath.c_str(), GENERIC_WRITE, 0, nullptr,
			CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY, nullptr);
		if (h == INVALID_HANDLE_VALUE)
			return false;

		DWORD written = 0;
		const BOOL ok = WriteFile(h, MENU_OPEN_SOUND_MP3, (DWORD)MENU_OPEN_SOUND_MP3_SIZE, &written, nullptr);
		CloseHandle(h);
		if (!ok || written != MENU_OPEN_SOUND_MP3_SIZE)
			return false;

		g_extracted = true;
		return true;
	}
}

void MenuSound::PlayOpen()
{
	if (!EnsureExtracted())
		return;

	// Restart from the beginning if already playing.
	mciSendStringA("close lateware_menu_sfx", nullptr, 0, nullptr);

	char openCmd[512];
	std::snprintf(openCmd, sizeof(openCmd),
		"open \"%s\" type mpegvideo alias lateware_menu_sfx", g_tempPath.c_str());
	if (mciSendStringA(openCmd, nullptr, 0, nullptr) != 0)
		return;

	mciSendStringA("play lateware_menu_sfx from 0", nullptr, 0, nullptr);
}
