#pragma once

struct MenuSound
{
	// Async; safe to call from WndProc. Plays once per open.
	static void PlayOpen();
};
