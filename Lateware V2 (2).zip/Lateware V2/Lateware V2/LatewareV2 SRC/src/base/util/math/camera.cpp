#include "camera.h"

#include "base.h"
#include "util/logger.h"
#include "util/math/math.h"

Vector3 CameraUtils::GetCameraPosition(const Matrix& modelView) {
	Matrix inversed = modelView.Inverse();

	// Position is relative to the position of the player.
	// inversed.m30 = x
	// inversed.m31 = y
	// inversed.m32 = z

	return Vector3{ inversed.m30, inversed.m31, inversed.m32 };
}

bool CameraUtils::WorldToScreen(Vector3 point, Matrix modelView, Matrix projection, int screenWidth, int screenHeight, Vector2 &screenPos) {
	// csp = Clip Space Position
	Vector4 csp = Math::Multiply(
		Math::Multiply(
			Vector4 {point.x, point.y, point.z, 1.0f},
			modelView
		),
		projection
	);

	if (csp.w < 0.05f)
		return false;

	// ndc = Native Device Coordinate
	const float invW = 1.0f / csp.w;
	Vector3 ndc{
		csp.x * invW,
		csp.y * invW,
		csp.z * invW
	};

	// Accept normal NDC plus a small band this client's MV/P sometimes produces.
	if (!((ndc.z > -1.0f && ndc.z < 1.15f)))
		return false;

	screenPos = Vector2{
		((ndc.x + 1.0f) / 2.0f) * screenWidth,
		((1.0f - ndc.y) / 2.0f) * screenHeight,
	};
	return true;
}