#pragma once

#include <imgui/imgui.h>

// Embedded Minecraft 1.8-style item icons for overlay drawing (nametags, etc.).
struct ItemIcons
{
	// Must be called on the OpenGL/render thread (e.g. inside wglSwapBuffers).
	static void EnsureLoaded();

	static bool HasIcon(int itemId);
	static ImTextureID GetAtlasTexture();

	// Returns UV min/max in [0,1] for AddImage. False if item has no icon.
	static bool GetUv(int itemId, ImVec2& uvMin, ImVec2& uvMax);

	static void DrawIcon(ImDrawList* draw, int itemId, ImVec2 min, ImVec2 max, float alpha = 1.f);
	static void DrawEmptySlot(ImDrawList* draw, ImVec2 min, ImVec2 max, float alpha = 1.f);
};
