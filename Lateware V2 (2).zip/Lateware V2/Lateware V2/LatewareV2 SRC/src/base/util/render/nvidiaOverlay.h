#pragma once

#include <Windows.h>
#include <string>
#include <vector>

// Transparent layered ESP window (gated on NVIDIA overlay being present).
// Heavy D2D / UpdateLayeredWindow work runs on a worker thread so the game
// render thread only publishes a lightweight draw list.
namespace NvidiaOverlay
{
	struct Color
	{
		float r, g, b, a;
	};

	struct DrawCmd
	{
		enum class Type : uint8_t { FillRect, CornerBox, HealthBar, Nametag };

		Type type = Type::CornerBox;
		float x0 = 0.f, y0 = 0.f, x1 = 0.f, y1 = 0.f;
		float thickness = 1.5f;
		float health01 = 1.f;
		float fontSize = 16.f;
		Color color{};
		Color colorSecondary{};
		Color bg{};
		bool hasOutline = false;
		bool hasBackground = false;
		std::string text;
	};

	struct FrameSubmit
	{
		HWND gameHwnd = nullptr;
		int screenX = 0;
		int screenY = 0;
		int width = 0;
		int height = 0;
		int maxFps = 30;
		std::vector<DrawCmd> cmds;
	};

	void Shutdown();
	bool IsConnected();

	// Game-thread only: publish the next overlay frame (non-blocking).
	void SubmitFrame(FrameSubmit&& frame);

	// Game-thread only: ask worker to clear / tear down drawing.
	void RequestClear();

	// True when enough time has passed to build+submit another frame.
	bool ShouldSubmitFrame(int maxOverlayFps);
}
