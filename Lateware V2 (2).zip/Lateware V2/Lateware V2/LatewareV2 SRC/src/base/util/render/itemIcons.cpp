#include "itemIcons.h"

#include <unordered_map>

#include <Windows.h>
#include <GL/gl.h>

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_STATIC
#define STBI_ONLY_PNG
#define STBI_NO_STDIO
#include "stb/stb_image.h"

#include "itemIconAtlasData.h"

namespace
{
	bool g_attempted = false;
	bool g_ready = false;
	GLuint g_tex = 0;
	std::unordered_map<int, ImVec2> g_uvMin;
	std::unordered_map<int, ImVec2> g_uvMax;

	bool UploadAtlas()
	{
		int w = 0, h = 0, channels = 0;
		unsigned char* pixels = stbi_load_from_memory(
			ITEM_ICON_ATLAS_PNG, (int)ITEM_ICON_ATLAS_PNG_SIZE,
			&w, &h, &channels, 4);
		if (!pixels || w <= 0 || h <= 0)
		{
			if (pixels) stbi_image_free(pixels);
			return false;
		}

		GLuint tex = 0;
		glGenTextures(1, &tex);
		if (!tex)
		{
			stbi_image_free(pixels);
			return false;
		}

		GLint lastTex = 0;
		glGetIntegerv(GL_TEXTURE_BINDING_2D, &lastTex);

		glBindTexture(GL_TEXTURE_2D, tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

		glBindTexture(GL_TEXTURE_2D, (GLuint)lastTex);
		stbi_image_free(pixels);

		g_tex = tex;
		g_uvMin.clear();
		g_uvMax.clear();
		g_uvMin.reserve(ITEM_ICON_COUNT);
		g_uvMax.reserve(ITEM_ICON_COUNT);

		const float invW = 1.f / (float)w;
		const float invH = 1.f / (float)h;
		for (int i = 0; i < ITEM_ICON_COUNT; ++i)
		{
			const ItemIconEntry& e = ITEM_ICON_ENTRIES[i];
			g_uvMin[e.itemId] = ImVec2((float)e.x * invW, (float)e.y * invH);
			g_uvMax[e.itemId] = ImVec2((float)(e.x + ITEM_ICON_TILE) * invW, (float)(e.y + ITEM_ICON_TILE) * invH);
		}
		return true;
	}
}

void ItemIcons::EnsureLoaded()
{
	if (g_attempted)
		return;
	g_attempted = true;

	// Must run with a current GL context (ImGui overlay path). Fail soft.
	if (wglGetCurrentContext() == nullptr)
	{
		g_ready = false;
		g_attempted = false; // retry next frame once context exists
		return;
	}

	try
	{
		g_ready = UploadAtlas();
	}
	catch (...)
	{
		g_ready = false;
	}
}

bool ItemIcons::HasIcon(int itemId)
{
	EnsureLoaded();
	return g_ready && g_uvMin.find(itemId) != g_uvMin.end();
}

ImTextureID ItemIcons::GetAtlasTexture()
{
	EnsureLoaded();
	return g_ready ? (ImTextureID)(intptr_t)g_tex : (ImTextureID)0;
}

bool ItemIcons::GetUv(int itemId, ImVec2& uvMin, ImVec2& uvMax)
{
	EnsureLoaded();
	if (!g_ready)
		return false;
	auto it = g_uvMin.find(itemId);
	if (it == g_uvMin.end())
		return false;
	uvMin = it->second;
	uvMax = g_uvMax[itemId];
	return true;
}

void ItemIcons::DrawEmptySlot(ImDrawList* draw, ImVec2 min, ImVec2 max, float alpha)
{
	if (!draw)
		return;
	draw->AddRectFilled(min, max, ImColor(0.08f, 0.09f, 0.11f, 0.75f * alpha), 3.f);
	draw->AddRect(min, max, ImColor(1.f, 1.f, 1.f, 0.12f * alpha), 3.f, 0, 1.0f);
}

void ItemIcons::DrawIcon(ImDrawList* draw, int itemId, ImVec2 min, ImVec2 max, float alpha)
{
	if (!draw)
		return;

	ImVec2 uv0, uv1;
	if (!GetUv(itemId, uv0, uv1))
	{
		DrawEmptySlot(draw, min, max, alpha);
		return;
	}

	draw->AddRectFilled(min, max, ImColor(0.05f, 0.055f, 0.07f, 0.55f * alpha), 3.f);
	draw->AddImage(GetAtlasTexture(), min, max, uv0, uv1, ImColor(1.f, 1.f, 1.f, alpha));
	draw->AddRect(min, max, ImColor(1.f, 1.f, 1.f, 0.14f * alpha), 3.f, 0, 1.0f);
}
