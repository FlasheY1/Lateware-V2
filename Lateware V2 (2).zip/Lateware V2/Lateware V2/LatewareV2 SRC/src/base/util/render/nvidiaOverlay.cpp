#include "nvidiaOverlay.h"

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <thread>

#include "util/nativeLock.h"

#include <d2d1.h>
#include <dwrite.h>

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

namespace
{
	HWND g_nvidiaHwnd = nullptr;
	HWND g_hwnd = nullptr;
	bool g_classReg = false;
	bool g_comInit = false;
	bool g_nvidiaHidden = false;
	long long g_lastFindMs = 0;
	long long g_lastSubmitMs = 0;

	ID2D1Factory* g_factory = nullptr;
	IDWriteFactory* g_dwrite = nullptr;
	ID2D1DCRenderTarget* g_rt = nullptr;
	ID2D1SolidColorBrush* g_brush = nullptr;
	IDWriteTextFormat* g_textFormat = nullptr;
	float g_textFormatSize = 0.f;

	HDC g_screenDc = nullptr;
	HDC g_memDc = nullptr;
	HBITMAP g_dib = nullptr;
	HBITMAP g_oldBmp = nullptr;
	BYTE* g_bits = nullptr;
	UINT g_stride = 0;

	UINT g_width = 0;
	UINT g_height = 0;
	int g_screenX = 0;
	int g_screenY = 0;
	int g_lastX = INT_MIN;
	int g_lastY = INT_MIN;
	int g_lastW = 0;
	int g_lastH = 0;

	RECT g_dirty{};
	RECT g_prevDirty{};
	bool g_hasDirty = false;
	bool g_hasPrevDirty = false;
	bool g_forceFullClear = true;
	bool g_inFrame = false;

	NativeLock g_submitMutex;
	NvidiaOverlay::FrameSubmit g_pending{};
	bool g_hasPending = false;
	std::atomic<bool> g_clearRequested{ false };
	std::atomic<bool> g_workerRun{ false };
	std::thread g_worker;
	HANDLE g_wakeEvent = nullptr;

	constexpr wchar_t kOverlayClass[] = L"LatewareV2.NvidiaEsp.Overlay";
	constexpr int kDirtyPad = 3;

	long long NowMs()
	{
		return std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::steady_clock::now().time_since_epoch()).count();
	}

	D2D1_COLOR_F ToD2D(const NvidiaOverlay::Color& c)
	{
		return D2D1::ColorF(c.r, c.g, c.b, c.a);
	}

	void ExpandDirty(float x0, float y0, float x1, float y1)
	{
		const float loX = (x0 < x1) ? x0 : x1;
		const float hiX = (x0 > x1) ? x0 : x1;
		const float loY = (y0 < y1) ? y0 : y1;
		const float hiY = (y0 > y1) ? y0 : y1;

		RECT r{
			static_cast<LONG>(std::floor(loX)) - kDirtyPad,
			static_cast<LONG>(std::floor(loY)) - kDirtyPad,
			static_cast<LONG>(std::ceil(hiX)) + kDirtyPad,
			static_cast<LONG>(std::ceil(hiY)) + kDirtyPad
		};

		if (r.left < 0) r.left = 0;
		if (r.top < 0) r.top = 0;
		if (r.right > static_cast<LONG>(g_width)) r.right = static_cast<LONG>(g_width);
		if (r.bottom > static_cast<LONG>(g_height)) r.bottom = static_cast<LONG>(g_height);
		if (r.right <= r.left || r.bottom <= r.top)
			return;

		if (!g_hasDirty)
		{
			g_dirty = r;
			g_hasDirty = true;
			return;
		}

		if (r.left < g_dirty.left) g_dirty.left = r.left;
		if (r.top < g_dirty.top) g_dirty.top = r.top;
		if (r.right > g_dirty.right) g_dirty.right = r.right;
		if (r.bottom > g_dirty.bottom) g_dirty.bottom = r.bottom;
	}

	bool EnsureBrush()
	{
		if (g_brush || !g_rt)
			return g_brush != nullptr;
		return SUCCEEDED(g_rt->CreateSolidColorBrush(D2D1::ColorF(1.f, 1.f, 1.f), &g_brush)) && g_brush;
	}

	ID2D1SolidColorBrush* Brush(const NvidiaOverlay::Color& color)
	{
		if (!EnsureBrush())
			return nullptr;
		g_brush->SetColor(ToD2D(color));
		return g_brush;
	}

	bool EnsureTextFormat(float fontSize)
	{
		if (!g_dwrite)
			return false;
		if (g_textFormat && std::fabs(g_textFormatSize - fontSize) < 0.01f)
			return true;

		if (g_textFormat)
		{
			g_textFormat->Release();
			g_textFormat = nullptr;
		}

		if (FAILED(g_dwrite->CreateTextFormat(
			L"Segoe UI", nullptr,
			DWRITE_FONT_WEIGHT_SEMI_BOLD, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL,
			fontSize, L"en-us", &g_textFormat)) || !g_textFormat)
			return false;

		g_textFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP);
		g_textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
		g_textFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
		g_textFormatSize = fontSize;
		return true;
	}

	std::wstring Utf8ToWide(const char* text)
	{
		if (!text || !*text)
			return {};
		const int n = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
		if (n <= 1)
			return {};
		std::wstring out(static_cast<size_t>(n - 1), L'\0');
		MultiByteToWideChar(CP_UTF8, 0, text, -1, out.data(), n);
		return out;
	}

	bool IsNvidiaOverlayWindow(HWND hwnd)
	{
		if (!hwnd || !IsWindow(hwnd))
			return false;
		char cls[256]{};
		char title[512]{};
		GetClassNameA(hwnd, cls, sizeof(cls));
		GetWindowTextA(hwnd, title, sizeof(title));
		if (_stricmp(cls, "CEF-OSC-WIDGET") == 0)
			return true;
		return strstr(title, "NVIDIA GeForce Overlay") != nullptr
			|| _stricmp(title, "NVIDIA GeForce Overlay") == 0;
	}

	HWND FindNvidiaOverlayWindow()
	{
		HWND exact = FindWindowA("CEF-OSC-WIDGET", "NVIDIA GeForce Overlay");
		if (exact && IsWindow(exact))
			return exact;
		exact = FindWindowA(nullptr, "NVIDIA GeForce Overlay");
		if (exact && IsWindow(exact))
			return exact;
		exact = FindWindowA("CEF-OSC-WIDGET", nullptr);
		if (exact && IsWindow(exact))
			return exact;

		HWND found = nullptr;
		EnumWindows([](HWND hwnd, LPARAM lp) -> BOOL {
			if (!IsWindow(hwnd) || !IsNvidiaOverlayWindow(hwnd))
				return TRUE;
			*reinterpret_cast<HWND*>(lp) = hwnd;
			return FALSE;
		}, reinterpret_cast<LPARAM>(&found));
		return found;
	}

	LRESULT CALLBACK OverlayWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
	{
		if (msg == WM_NCHITTEST)
			return HTTRANSPARENT;
		if (msg == WM_ERASEBKGND)
			return 1;
		if (msg == WM_PAINT)
		{
			PAINTSTRUCT ps{};
			BeginPaint(hwnd, &ps);
			EndPaint(hwnd, &ps);
			return 0;
		}
		return DefWindowProcW(hwnd, msg, wParam, lParam);
	}

	bool EnsureWindowClass()
	{
		if (g_classReg)
			return true;
		WNDCLASSEXW wc{};
		wc.cbSize = sizeof(wc);
		wc.lpfnWndProc = OverlayWndProc;
		wc.hInstance = GetModuleHandleW(nullptr);
		wc.lpszClassName = kOverlayClass;
		const ATOM atom = RegisterClassExW(&wc);
		if (!atom && GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
			return false;
		g_classReg = true;
		return true;
	}

	void HideNvidiaOnce(HWND hwnd)
	{
		if (!hwnd || !IsWindow(hwnd) || g_nvidiaHidden)
			return;
		LONG_PTR ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
		ex |= WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;
		SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex);
		ShowWindow(hwnd, SW_HIDE);
		g_nvidiaHidden = true;
	}

	bool EnsureDrawWindow()
	{
		if (g_hwnd && IsWindow(g_hwnd))
			return true;
		if (!EnsureWindowClass())
			return false;
		g_hwnd = CreateWindowExW(
			WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
			kOverlayClass, L"Lateware V2 NVIDIA ESP", WS_POPUP,
			0, 0, 2, 2, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
		return g_hwnd != nullptr;
	}

	void ClearRectCpu(const RECT& r)
	{
		if (!g_bits || r.right <= r.left || r.bottom <= r.top)
			return;
		const int left = (r.left > 0) ? r.left : 0;
		const int top = (r.top > 0) ? r.top : 0;
		const int right = (r.right < static_cast<LONG>(g_width)) ? r.right : static_cast<LONG>(g_width);
		const int bottom = (r.bottom < static_cast<LONG>(g_height)) ? r.bottom : static_cast<LONG>(g_height);
		if (right <= left || bottom <= top)
			return;
		const size_t rowBytes = static_cast<size_t>(right - left) * 4;
		for (int y = top; y < bottom; ++y)
			std::memset(g_bits + static_cast<size_t>(y) * g_stride + static_cast<size_t>(left) * 4, 0, rowBytes);
	}

	void ReleaseSurface()
	{
		if (g_inFrame && g_rt)
		{
			g_rt->EndDraw();
			g_inFrame = false;
		}
		if (g_brush) { g_brush->Release(); g_brush = nullptr; }
		if (g_rt) { g_rt->Release(); g_rt = nullptr; }
		if (g_memDc)
		{
			if (g_oldBmp) { SelectObject(g_memDc, g_oldBmp); g_oldBmp = nullptr; }
			DeleteDC(g_memDc);
			g_memDc = nullptr;
		}
		if (g_dib) { DeleteObject(g_dib); g_dib = nullptr; }
		g_bits = nullptr;
		g_stride = 0;
		g_width = g_height = 0;
		g_forceFullClear = true;
		g_hasDirty = g_hasPrevDirty = false;
	}

	bool EnsureFactories()
	{
		if (!g_comInit)
		{
			const HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
			if (SUCCEEDED(hr) || hr == RPC_E_CHANGED_MODE)
				g_comInit = true;
			else
				return false;
		}
		if (!g_factory && FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &g_factory)))
			return false;
		if (!g_dwrite && FAILED(DWriteCreateFactory(
			DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&g_dwrite))))
			return false;
		if (!g_screenDc)
			g_screenDc = GetDC(nullptr);
		return g_screenDc != nullptr;
	}

	bool CreateSurface(UINT w, UINT h)
	{
		if (!g_factory || w < 2 || h < 2)
			return false;
		if (g_rt && g_memDc && g_dib && g_width == w && g_height == h)
			return true;

		ReleaseSurface();
		g_memDc = CreateCompatibleDC(g_screenDc);
		if (!g_memDc)
			return false;

		BITMAPINFO bmi{};
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = static_cast<LONG>(w);
		bmi.bmiHeader.biHeight = -static_cast<LONG>(h);
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;

		void* bits = nullptr;
		g_dib = CreateDIBSection(g_memDc, &bmi, DIB_RGB_COLORS, &bits, nullptr, 0);
		if (!g_dib || !bits)
		{
			ReleaseSurface();
			return false;
		}

		g_bits = static_cast<BYTE*>(bits);
		g_stride = w * 4;
		g_oldBmp = static_cast<HBITMAP>(SelectObject(g_memDc, g_dib));
		std::memset(g_bits, 0, static_cast<size_t>(g_stride) * h);

		const D2D1_RENDER_TARGET_PROPERTIES rtp = D2D1::RenderTargetProperties(
			D2D1_RENDER_TARGET_TYPE_DEFAULT,
			D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED),
			96.f, 96.f, D2D1_RENDER_TARGET_USAGE_GDI_COMPATIBLE, D2D1_FEATURE_LEVEL_DEFAULT);

		ID2D1DCRenderTarget* dcRt = nullptr;
		if (FAILED(g_factory->CreateDCRenderTarget(&rtp, &dcRt)) || !dcRt)
		{
			ReleaseSurface();
			return false;
		}

		RECT bind{ 0, 0, static_cast<LONG>(w), static_cast<LONG>(h) };
		if (FAILED(dcRt->BindDC(g_memDc, &bind)))
		{
			dcRt->Release();
			ReleaseSurface();
			return false;
		}

		dcRt->SetAntialiasMode(D2D1_ANTIALIAS_MODE_ALIASED);
		dcRt->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_GRAYSCALE);
		g_rt = dcRt;
		g_width = w;
		g_height = h;
		g_forceFullClear = true;
		return true;
	}

	bool PresentLayered(const RECT* dirtyOpt)
	{
		if (!g_hwnd || !IsWindow(g_hwnd) || !g_memDc || !g_bits || g_width < 2 || g_height < 2)
			return false;

		POINT ptDst{ g_screenX, g_screenY };
		POINT ptSrc{ 0, 0 };
		SIZE size{ static_cast<LONG>(g_width), static_cast<LONG>(g_height) };
		BLENDFUNCTION blend{ AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

		UPDATELAYEREDWINDOWINFO info{};
		info.cbSize = sizeof(info);
		info.hdcDst = g_screenDc;
		info.pptDst = &ptDst;
		info.psize = &size;
		info.hdcSrc = g_memDc;
		info.pptSrc = &ptSrc;
		info.pblend = &blend;
		info.dwFlags = ULW_ALPHA;
		info.prcDirty = dirtyOpt;
		return UpdateLayeredWindowIndirect(g_hwnd, &info) != FALSE;
	}

	bool EnsureConnectedWorker()
	{
		const long long now = NowMs();
		if (now - g_lastFindMs >= 2000 || !g_nvidiaHwnd || !IsWindow(g_nvidiaHwnd))
		{
			g_lastFindMs = now;
			g_nvidiaHwnd = FindNvidiaOverlayWindow();
			g_nvidiaHidden = false;
		}
		if (!g_nvidiaHwnd)
			return false;

		HideNvidiaOnce(g_nvidiaHwnd);
		if (!EnsureFactories() || !EnsureDrawWindow())
			return false;
		return true;
	}

	bool BeginFrameWorker()
	{
		if (!g_rt || g_inFrame || g_width < 2 || g_height < 2)
			return false;

		RECT bind{ 0, 0, static_cast<LONG>(g_width), static_cast<LONG>(g_height) };
		if (FAILED(g_rt->BindDC(g_memDc, &bind)))
			return false;

		if (g_forceFullClear)
		{
			std::memset(g_bits, 0, static_cast<size_t>(g_stride) * g_height);
			g_forceFullClear = false;
			g_hasPrevDirty = false;
		}
		else if (g_hasPrevDirty)
		{
			ClearRectCpu(g_prevDirty);
		}

		g_hasDirty = false;
		g_dirty = {};
		g_rt->BeginDraw();
		g_rt->SetTransform(D2D1::Matrix3x2F::Identity());
		g_inFrame = true;
		return true;
	}

	void EndFrameWorker()
	{
		if (!g_inFrame || !g_rt)
			return;

		const HRESULT hr = g_rt->EndDraw();
		g_inFrame = false;

		RECT presentDirty{};
		const RECT* dirtyPtr = nullptr;
		if (g_hasDirty && g_hasPrevDirty)
		{
			presentDirty.left = (g_dirty.left < g_prevDirty.left) ? g_dirty.left : g_prevDirty.left;
			presentDirty.top = (g_dirty.top < g_prevDirty.top) ? g_dirty.top : g_prevDirty.top;
			presentDirty.right = (g_dirty.right > g_prevDirty.right) ? g_dirty.right : g_prevDirty.right;
			presentDirty.bottom = (g_dirty.bottom > g_prevDirty.bottom) ? g_dirty.bottom : g_prevDirty.bottom;
			dirtyPtr = &presentDirty;
		}
		else if (g_hasDirty)
		{
			presentDirty = g_dirty;
			dirtyPtr = &presentDirty;
		}
		else if (g_hasPrevDirty)
		{
			presentDirty = g_prevDirty;
			dirtyPtr = &presentDirty;
		}

		if (SUCCEEDED(hr) || hr == D2DERR_RECREATE_TARGET)
		{
			PresentLayered(dirtyPtr);
			g_prevDirty = g_hasDirty ? g_dirty : RECT{};
			g_hasPrevDirty = g_hasDirty;
		}
		if (hr == D2DERR_RECREATE_TARGET)
			ReleaseSurface();
	}

	void DrawLineW(float x1, float y1, float x2, float y2, const NvidiaOverlay::Color& color, float thickness)
	{
		ID2D1SolidColorBrush* brush = Brush(color);
		if (!brush)
			return;
		ExpandDirty(x1 - thickness, y1 - thickness, x2 + thickness, y2 + thickness);
		g_rt->DrawLine(D2D1::Point2F(x1, y1), D2D1::Point2F(x2, y2), brush, thickness);
	}

	void DrawCornerBoxW(float left, float top, float right, float bottom, const NvidiaOverlay::Color& color, float thickness)
	{
		const float boxW = right - left;
		const float boxH = bottom - top;
		if (boxW < 2.f || boxH < 2.f)
			return;
		float corner = (boxW < boxH ? boxW : boxH) * 0.22f;
		if (corner < 6.f) corner = 6.f;
		if (corner > 14.f) corner = 14.f;

		DrawLineW(left, top + corner, left, top, color, thickness);
		DrawLineW(left, top, left + corner, top, color, thickness);
		DrawLineW(right - corner, top, right, top, color, thickness);
		DrawLineW(right, top, right, top + corner, color, thickness);
		DrawLineW(left, bottom - corner, left, bottom, color, thickness);
		DrawLineW(left, bottom, left + corner, bottom, color, thickness);
		DrawLineW(right - corner, bottom, right, bottom, color, thickness);
		DrawLineW(right, bottom, right, bottom - corner, color, thickness);
	}

	void FillRectW(float x, float y, float w, float h, const NvidiaOverlay::Color& color)
	{
		if (w <= 0.f || h <= 0.f)
			return;
		ID2D1SolidColorBrush* brush = Brush(color);
		if (!brush)
			return;
		ExpandDirty(x, y, x + w, y + h);
		g_rt->FillRectangle(D2D1::RectF(x, y, x + w, y + h), brush);
	}

	void DrawTextW(float x, float y, const std::wstring& text, const NvidiaOverlay::Color& color, float fontSize, bool centered)
	{
		if (text.empty() || !EnsureTextFormat(fontSize))
			return;
		IDWriteTextLayout* layout = nullptr;
		if (FAILED(g_dwrite->CreateTextLayout(text.c_str(), static_cast<UINT32>(text.size()),
			g_textFormat, 4096.f, fontSize * 2.f, &layout)) || !layout)
			return;

		DWRITE_TEXT_METRICS metrics{};
		layout->GetMetrics(&metrics);
		const float drawX = centered ? (x - metrics.width * 0.5f) : x;
		ExpandDirty(drawX - 1.f, y - 1.f, drawX + metrics.width + 1.f, y + metrics.height + 1.f);

		if (ID2D1SolidColorBrush* outline = Brush(NvidiaOverlay::Color{ 0.f, 0.f, 0.f, color.a * 0.9f }))
		{
			for (int oy = -1; oy <= 1; ++oy)
				for (int ox = -1; ox <= 1; ++ox)
					if (ox || oy)
						g_rt->DrawTextLayout(D2D1::Point2F(drawX + ox, y + oy), layout, outline);
		}
		if (ID2D1SolidColorBrush* brush = Brush(color))
			g_rt->DrawTextLayout(D2D1::Point2F(drawX, y), layout, brush);
		layout->Release();
	}

	float MeasureTextW(const std::wstring& text, float fontSize)
	{
		if (text.empty() || !EnsureTextFormat(fontSize))
			return 0.f;
		IDWriteTextLayout* layout = nullptr;
		if (FAILED(g_dwrite->CreateTextLayout(text.c_str(), static_cast<UINT32>(text.size()),
			g_textFormat, 4096.f, fontSize * 2.f, &layout)) || !layout)
			return 0.f;
		DWRITE_TEXT_METRICS metrics{};
		layout->GetMetrics(&metrics);
		layout->Release();
		return metrics.width;
	}

	void ReplayCmd(const NvidiaOverlay::DrawCmd& cmd)
	{
		using Type = NvidiaOverlay::DrawCmd::Type;
		switch (cmd.type)
		{
		case Type::FillRect:
			FillRectW(cmd.x0, cmd.y0, cmd.x1 - cmd.x0, cmd.y1 - cmd.y0, cmd.color);
			break;
		case Type::CornerBox:
			if (cmd.hasOutline)
				DrawCornerBoxW(cmd.x0 - 1.f, cmd.y0 - 1.f, cmd.x1 + 1.f, cmd.y1 + 1.f, cmd.colorSecondary, cmd.thickness + 0.6f);
			DrawCornerBoxW(cmd.x0, cmd.y0, cmd.x1, cmd.y1, cmd.color, cmd.thickness);
			break;
		case Type::HealthBar:
		{
			const float h = cmd.y1 - cmd.y0;
			const float w = cmd.x1 - cmd.x0;
			FillRectW(cmd.x0, cmd.y0, w, h, cmd.colorSecondary);
			const float filledH = h * cmd.health01;
			FillRectW(cmd.x0, cmd.y1 - filledH, w, filledH, cmd.color);
			break;
		}
		case Type::Nametag:
		{
			const std::wstring wide = Utf8ToWide(cmd.text.c_str());
			const float textW = MeasureTextW(wide, cmd.fontSize);
			const float textH = cmd.fontSize + 2.f;
			if (cmd.hasBackground)
			{
				const float padX = 5.f, padY = 2.f;
				FillRectW(cmd.x0 - textW * 0.5f - padX, cmd.y0 - padY, textW + padX * 2.f, textH + padY * 2.f, cmd.bg);
			}
			DrawTextW(cmd.x0, cmd.y0, wide, cmd.color, cmd.fontSize, true);
			break;
		}
		}
	}

	void SyncGeometry(const NvidiaOverlay::FrameSubmit& frame)
	{
		g_screenX = frame.screenX;
		g_screenY = frame.screenY;
		if (frame.screenX != g_lastX || frame.screenY != g_lastY || frame.width != g_lastW || frame.height != g_lastH)
		{
			SetWindowPos(g_hwnd, HWND_TOPMOST, frame.screenX, frame.screenY, frame.width, frame.height,
				SWP_SHOWWINDOW | SWP_NOACTIVATE);
			g_lastX = frame.screenX;
			g_lastY = frame.screenY;
			g_lastW = frame.width;
			g_lastH = frame.height;
		}
		CreateSurface(static_cast<UINT>(frame.width), static_cast<UINT>(frame.height));
	}

	void ClearAll()
	{
		if (!g_hwnd || !IsWindow(g_hwnd) || !g_bits)
			return;
		g_forceFullClear = true;
		if (!BeginFrameWorker())
			return;
		EndFrameWorker();
	}

	void ProcessFrame(NvidiaOverlay::FrameSubmit& frame)
	{
		if (!EnsureConnectedWorker())
			return;
		if (frame.width < 2 || frame.height < 2)
			return;

		SyncGeometry(frame);
		if (!BeginFrameWorker())
			return;

		for (const auto& cmd : frame.cmds)
			ReplayCmd(cmd);

		EndFrameWorker();
	}

	void WorkerMain()
	{
		CoInitializeEx(nullptr, COINIT_MULTITHREADED);

		while (g_workerRun.load(std::memory_order_acquire))
		{
			WaitForSingleObject(g_wakeEvent, 50);

			if (g_clearRequested.exchange(false))
			{
				ClearAll();
				continue;
			}

			NvidiaOverlay::FrameSubmit local;
			{
				NativeGuard lock(g_submitMutex);
				if (!g_hasPending)
					continue;
				local = std::move(g_pending);
				g_hasPending = false;
			}

			ProcessFrame(local);
		}

		ReleaseSurface();
		if (g_hwnd)
		{
			DestroyWindow(g_hwnd);
			g_hwnd = nullptr;
		}
		g_nvidiaHwnd = nullptr;
		g_nvidiaHidden = false;

		if (g_textFormat) { g_textFormat->Release(); g_textFormat = nullptr; g_textFormatSize = 0.f; }
		if (g_dwrite) { g_dwrite->Release(); g_dwrite = nullptr; }
		if (g_factory) { g_factory->Release(); g_factory = nullptr; }
		if (g_screenDc) { ReleaseDC(nullptr, g_screenDc); g_screenDc = nullptr; }

		CoUninitialize();
	}

	void EnsureWorker()
	{
		if (g_workerRun.load(std::memory_order_acquire))
			return;

		if (!g_wakeEvent)
			g_wakeEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);

		g_workerRun.store(true, std::memory_order_release);
		g_worker = std::thread(WorkerMain);
	}
}

namespace NvidiaOverlay
{
	void Shutdown()
	{
		RequestClear();
		g_workerRun.store(false, std::memory_order_release);
		if (g_wakeEvent)
			SetEvent(g_wakeEvent);
		if (g_worker.joinable())
			g_worker.join();
		if (g_wakeEvent)
		{
			CloseHandle(g_wakeEvent);
			g_wakeEvent = nullptr;
		}
		g_hasPending = false;
	}

	bool IsConnected()
	{
		return g_nvidiaHwnd && IsWindow(g_nvidiaHwnd) && g_hwnd && IsWindow(g_hwnd);
	}

	bool ShouldSubmitFrame(int maxOverlayFps)
	{
		if (maxOverlayFps <= 0)
			maxOverlayFps = 30;
		const long long now = NowMs();
		const long long interval = 1000 / maxOverlayFps;
		if (now - g_lastSubmitMs < interval)
			return false;
		g_lastSubmitMs = now;
		return true;
	}

	void SubmitFrame(FrameSubmit&& frame)
	{
		EnsureWorker();
		{
			NativeGuard lock(g_submitMutex);
			g_pending = std::move(frame);
			g_hasPending = true;
		}
		if (g_wakeEvent)
			SetEvent(g_wakeEvent);
	}

	void RequestClear()
	{
		g_clearRequested.store(true, std::memory_order_release);
		{
			NativeGuard lock(g_submitMutex);
			g_pending = {};
			g_hasPending = false;
		}
		if (g_wakeEvent)
			SetEvent(g_wakeEvent);
		else
			EnsureWorker();
	}
}
