#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

// std::mutex from the MSVC DLL does not match the older msvcp140.dll that
// JDK 17 already loaded into javaw. lock() then reads a null pointer inside
// msvcp140. SRWLOCK lives in kernel32 and is safe in an injected module.
struct NativeLock
{
	SRWLOCK srw = SRWLOCK_INIT;

	void lock() { AcquireSRWLockExclusive(&srw); }
	void unlock() { ReleaseSRWLockExclusive(&srw); }

	NativeLock() = default;
	NativeLock(const NativeLock&) = delete;
	NativeLock& operator=(const NativeLock&) = delete;
};

struct NativeGuard
{
	NativeLock& lockRef;

	explicit NativeGuard(NativeLock& l) : lockRef(l) { lockRef.lock(); }
	~NativeGuard() { lockRef.unlock(); }

	NativeGuard(const NativeGuard&) = delete;
	NativeGuard& operator=(const NativeGuard&) = delete;
};
