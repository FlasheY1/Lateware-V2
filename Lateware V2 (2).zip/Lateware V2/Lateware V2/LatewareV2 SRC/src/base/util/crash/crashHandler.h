#pragma once

#include <cstdarg>

// Process-wide crash reports (text + minidump) plus SEH guards around
// the update/render loops so a single module fault is logged instead of
// silently taking down the JVM.
struct CrashHandler
{
	using Fn = void(*)(void*);

	static void Init();
	static void Shutdown();

	// Run `fn(user)` inside SEH. Returns false if a crash was caught and logged.
	static bool Guard(Fn fn, void* user, const char* area);

	static void SetContext(const char* area);
	static const char* GetContext();

	static void Breadcrumb(const char* text);
	static void Breadcrumbf(const char* fmt, ...);

	// If a JNI exception is pending, record it and clear it (crash precursor).
	static void CheckJni(const char* where);

	static const char* LastReportPath();

	class Scope
	{
	public:
		explicit Scope(const char* area);
		~Scope();
	private:
		const char* m_prev;
	};
};

#define CRASH_SCOPE(name) CrashHandler::Scope _crash_scope_{ (name) }
