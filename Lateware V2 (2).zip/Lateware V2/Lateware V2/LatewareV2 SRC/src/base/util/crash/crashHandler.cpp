#include "crashHandler.h"

#include <atomic>
#include <cstdint>
#include <cstdarg>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <exception>
#include <string>

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <dbghelp.h>
#include <Psapi.h>
#include <shlobj.h>

#include "base.h"
#include "java/java.h"
#include "moduleManager/moduleManager.h"
#include "moduleManager/commonData.h"
#include "sdk/sdk.h"

#pragma comment(lib, "dbghelp.lib")
#pragma comment(lib, "psapi.lib")

namespace
{
	constexpr int kBreadcrumbCap = 192;
	constexpr int kBreadcrumbLen = 240;
	constexpr int kReportCap = 48 * 1024;

	char g_crumbs[kBreadcrumbCap][kBreadcrumbLen]{};
	std::atomic<unsigned> g_crumbHead{ 0 };
	std::atomic<unsigned> g_crumbCount{ 0 };

	thread_local const char* t_context = "none";
	thread_local const char* t_guardArea = nullptr;

	std::atomic<int> g_writing{ 0 };
	std::atomic<int> g_inited{ 0 };
	LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;
	terminate_handler g_prevTerminate = nullptr;

	char g_crashDir[MAX_PATH]{};
	char g_lastReport[MAX_PATH]{};
	DWORD g_updateThreadId = 0;

	void SafeCopy(char* dst, size_t dstSize, const char* src)
	{
		if (!dst || dstSize == 0)
			return;
		if (!src)
		{
			dst[0] = 0;
			return;
		}
		strncpy_s(dst, dstSize, src, _TRUNCATE);
	}

	const char* ExceptionName(DWORD code)
	{
		switch (code)
		{
		case EXCEPTION_ACCESS_VIOLATION: return "ACCESS_VIOLATION";
		case EXCEPTION_ARRAY_BOUNDS_EXCEEDED: return "ARRAY_BOUNDS_EXCEEDED";
		case EXCEPTION_BREAKPOINT: return "BREAKPOINT";
		case EXCEPTION_DATATYPE_MISALIGNMENT: return "DATATYPE_MISALIGNMENT";
		case EXCEPTION_FLT_DENORMAL_OPERAND: return "FLT_DENORMAL_OPERAND";
		case EXCEPTION_FLT_DIVIDE_BY_ZERO: return "FLT_DIVIDE_BY_ZERO";
		case EXCEPTION_FLT_INEXACT_RESULT: return "FLT_INEXACT_RESULT";
		case EXCEPTION_FLT_INVALID_OPERATION: return "FLT_INVALID_OPERATION";
		case EXCEPTION_FLT_OVERFLOW: return "FLT_OVERFLOW";
		case EXCEPTION_FLT_STACK_CHECK: return "FLT_STACK_CHECK";
		case EXCEPTION_FLT_UNDERFLOW: return "FLT_UNDERFLOW";
		case EXCEPTION_ILLEGAL_INSTRUCTION: return "ILLEGAL_INSTRUCTION";
		case EXCEPTION_IN_PAGE_ERROR: return "IN_PAGE_ERROR";
		case EXCEPTION_INT_DIVIDE_BY_ZERO: return "INT_DIVIDE_BY_ZERO";
		case EXCEPTION_INT_OVERFLOW: return "INT_OVERFLOW";
		case EXCEPTION_INVALID_DISPOSITION: return "INVALID_DISPOSITION";
		case EXCEPTION_NONCONTINUABLE_EXCEPTION: return "NONCONTINUABLE_EXCEPTION";
		case EXCEPTION_PRIV_INSTRUCTION: return "PRIV_INSTRUCTION";
		case EXCEPTION_SINGLE_STEP: return "SINGLE_STEP";
		case EXCEPTION_STACK_OVERFLOW: return "STACK_OVERFLOW";
		case 0xE06D7363: return "CPP_EXCEPTION";
		case 0xC0000374: return "HEAP_CORRUPTION";
		default: return "UNKNOWN";
		}
	}

	const char* McVersionName()
	{
		switch (Java::version)
		{
		case MinecraftVersion::LUNAR_1_8_9: return "Lunar 1.8.9";
		case MinecraftVersion::LUNAR_1_7_10: return "Lunar 1.7.10";
		case MinecraftVersion::VANILLA_1_8_9: return "Vanilla 1.8.9";
		case MinecraftVersion::VANILLA_1_7_10: return "Vanilla 1.7.10";
		case MinecraftVersion::FORGE_1_8_9: return "Forge 1.8.9";
		case MinecraftVersion::FORGE_1_7_10: return "Forge 1.7.10";
		default: return "Unknown";
		}
	}

	void EnsureCrashDir()
	{
		if (g_crashDir[0])
			return;

		char docs[MAX_PATH]{};
		if (FAILED(SHGetFolderPathA(nullptr, CSIDL_PERSONAL, nullptr, SHGFP_TYPE_CURRENT, docs)))
			GetTempPathA(MAX_PATH, docs);

		char fusion[MAX_PATH]{};
		snprintf(fusion, sizeof(fusion), "%s\\Lateware V2", docs);
		CreateDirectoryA(fusion, nullptr);
		snprintf(g_crashDir, sizeof(g_crashDir), "%s\\crashes", fusion);
		CreateDirectoryA(g_crashDir, nullptr);
	}

	void PruneOldCrashes()
	{
		if (!g_crashDir[0])
			return;

		char pattern[MAX_PATH]{};
		snprintf(pattern, sizeof(pattern), "%s\\crash_*.txt", g_crashDir);

		struct Entry { char name[MAX_PATH]; FILETIME ft; };
		Entry entries[64]{};
		int n = 0;

		WIN32_FIND_DATAA fd{};
		HANDLE find = FindFirstFileA(pattern, &fd);
		if (find == INVALID_HANDLE_VALUE)
			return;

		auto dropOldest = [&]()
		{
			if (n <= 0)
				return;
			int oldest = 0;
			for (int i = 1; i < n; ++i)
			{
				if (CompareFileTime(&entries[i].ft, &entries[oldest].ft) < 0)
					oldest = i;
			}
			char txt[MAX_PATH]{};
			char dmp[MAX_PATH]{};
			snprintf(txt, sizeof(txt), "%s\\%s", g_crashDir, entries[oldest].name);
			SafeCopy(dmp, sizeof(dmp), txt);
			const size_t len = strlen(dmp);
			if (len > 4)
				memcpy(dmp + len - 4, ".dmp", 5);
			DeleteFileA(txt);
			DeleteFileA(dmp);
			entries[oldest] = entries[n - 1];
			--n;
		};

		do
		{
			if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				continue;
			if (n >= 64)
				dropOldest();
			SafeCopy(entries[n].name, sizeof(entries[n].name), fd.cFileName);
			entries[n].ft = fd.ftLastWriteTime;
			++n;
		} while (FindNextFileA(find, &fd));
		FindClose(find);

		constexpr int kKeep = 40;
		while (n > kKeep)
			dropOldest();
	}

	bool IsReadable(const void* p, size_t bytes = sizeof(void*))
	{
		MEMORY_BASIC_INFORMATION mbi{};
		if (!VirtualQuery(p, &mbi, sizeof(mbi)))
			return false;
		if (mbi.State != MEM_COMMIT)
			return false;
		const DWORD protect = mbi.Protect & 0xFF;
		if (protect == PAGE_NOACCESS || protect == PAGE_EXECUTE)
			return false;
		const uintptr_t start = (uintptr_t)p;
		const uintptr_t end = start + bytes;
		const uintptr_t regionEnd = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
		return end <= regionEnd;
	}

	void ModuleNameFromAddr(void* addr, char* out, size_t outSize, uintptr_t* outBase)
	{
		out[0] = 0;
		if (outBase) *outBase = 0;
		HMODULE mod = nullptr;
		if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
			(LPCSTR)addr, &mod) || !mod)
			return;
		GetModuleFileNameA(mod, out, (DWORD)outSize);
		if (outBase)
			*outBase = (uintptr_t)mod;
	}

	int Append(char* buf, int cap, int used, const char* fmt, ...)
	{
		if (used < 0 || used >= cap)
			return cap;
		va_list args;
		va_start(args, fmt);
		const int n = vsnprintf(buf + used, (size_t)(cap - used), fmt, args);
		va_end(args);
		if (n < 0)
			return used;
		const int next = used + n;
		return next < cap ? next : cap - 1;
	}

	void WriteFileAll(const char* path, const char* data, int len)
	{
		HANDLE h = CreateFileA(path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (h == INVALID_HANDLE_VALUE)
			return;
		DWORD written = 0;
		WriteFile(h, data, (DWORD)(len < 0 ? 0 : len), &written, nullptr);
		CloseHandle(h);
	}

	void WriteMinidump(const char* path, EXCEPTION_POINTERS* ep)
	{
		HANDLE h = CreateFileA(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (h == INVALID_HANDLE_VALUE)
			return;

		MINIDUMP_EXCEPTION_INFORMATION info{};
		info.ThreadId = GetCurrentThreadId();
		info.ExceptionPointers = ep;
		info.ClientPointers = FALSE;

		const MINIDUMP_TYPE type = (MINIDUMP_TYPE)(MiniDumpNormal | MiniDumpWithThreadInfo | MiniDumpWithUnloadedModules);
		MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), h, type, ep ? &info : nullptr, nullptr, nullptr);
		CloseHandle(h);
	}

	void DumpBreadcrumbs(char* buf, int cap, int& used)
	{
		used = Append(buf, cap, used, "=== Recent breadcrumbs (oldest -> newest) ===\n");
		const unsigned count = g_crumbCount.load(std::memory_order_relaxed);
		const unsigned head = g_crumbHead.load(std::memory_order_relaxed);
		const unsigned n = count < (unsigned)kBreadcrumbCap ? count : (unsigned)kBreadcrumbCap;
		for (unsigned i = 0; i < n; ++i)
		{
			const unsigned idx = (head + kBreadcrumbCap - n + i) % kBreadcrumbCap;
			used = Append(buf, cap, used, "  %s\n", g_crumbs[idx]);
		}
		used = Append(buf, cap, used, "\n");
	}

	void DumpEnabledModules(char* buf, int cap, int& used)
	{
		used = Append(buf, cap, used, "=== Enabled modules ===\n");
		if (ModuleManager::GetModules().empty())
		{
			used = Append(buf, cap, used, "  (none loaded yet)\n\n");
			return;
		}
		for (auto& module : ModuleManager::GetModules())
		{
			if (!module)
				continue;
			used = Append(buf, cap, used, "  [%s] %s  key=%d  enabled=%s\n",
				module->GetCategory().c_str(),
				module->GetName().c_str(),
				module->GetKey(),
				module->IsEnabled() ? "yes" : "no");
		}
		used = Append(buf, cap, used, "\n");
	}

	void DumpLoadedModules(char* buf, int cap, int& used, void* faultAddr)
	{
		used = Append(buf, cap, used, "=== Loaded modules ===\n");
		HMODULE mods[384]{};
		DWORD needed = 0;
		HANDLE proc = GetCurrentProcess();
		if (!EnumProcessModules(proc, mods, sizeof(mods), &needed))
		{
			used = Append(buf, cap, used, "  EnumProcessModules failed (%lu)\n\n", GetLastError());
			return;
		}
		const unsigned count = needed / sizeof(HMODULE);
		char name[MAX_PATH]{};
		for (unsigned i = 0; i < count && i < 384; ++i)
		{
			MODULEINFO mi{};
			GetModuleInformation(proc, mods[i], &mi, sizeof(mi));
			GetModuleFileNameA(mods[i], name, MAX_PATH);
			const bool hit = faultAddr
				&& (uintptr_t)faultAddr >= (uintptr_t)mi.lpBaseOfDll
				&& (uintptr_t)faultAddr < (uintptr_t)mi.lpBaseOfDll + mi.SizeOfImage;
			used = Append(buf, cap, used, "  %s%p-%p  %s\n",
				hit ? ">> " : "   ",
				mi.lpBaseOfDll,
				(void*)((uintptr_t)mi.lpBaseOfDll + mi.SizeOfImage),
				name);
		}
		used = Append(buf, cap, used, "\n");
	}

	void DumpStack(char* buf, int cap, int& used, CONTEXT* ctx)
	{
		used = Append(buf, cap, used, "=== Stack (RSP walk) ===\n");
		if (!ctx)
		{
			used = Append(buf, cap, used, "  (no context)\n\n");
			return;
		}

#ifdef _WIN64
		used = Append(buf, cap, used, "  RIP=%p  RSP=%p  RBP=%p\n", (void*)ctx->Rip, (void*)ctx->Rsp, (void*)ctx->Rbp);
		if (IsReadable((void*)ctx->Rsp, 8 * 24))
		{
			const uintptr_t* rsp = (const uintptr_t*)ctx->Rsp;
			for (int i = 0; i < 24; ++i)
			{
				char mod[MAX_PATH]{};
				uintptr_t base = 0;
				ModuleNameFromAddr((void*)rsp[i], mod, sizeof(mod), &base);
				const char* slash = strrchr(mod, '\\');
				used = Append(buf, cap, used, "  [%02d] %p", i, (void*)rsp[i]);
				if (mod[0])
					used = Append(buf, cap, used, "  %s+0x%llX", slash ? slash + 1 : mod, (unsigned long long)(rsp[i] - base));
				used = Append(buf, cap, used, "\n");
			}
		}
		else
		{
			used = Append(buf, cap, used, "  RSP not readable\n");
		}
#else
		used = Append(buf, cap, used, "  EIP=%p  ESP=%p  EBP=%p\n", (void*)ctx->Eip, (void*)ctx->Esp, (void*)ctx->Ebp);
#endif
		used = Append(buf, cap, used, "\n");
	}

	const char* HintFor(DWORD code, const char* area)
	{
		if (code == EXCEPTION_ACCESS_VIOLATION)
			return "Null/dangling pointer. Often a JNI local ref used after PopLocalFrame, or a Java object collected while we still held it.";
		if (code == 0xC0000374)
			return "Heap corruption. Look for use-after-free in String/Item conversions or overflowing a std::vector from the render thread.";
		if (code == EXCEPTION_STACK_OVERFLOW)
			return "Stack overflow. Check recursion (inventory sorter) or a giant alloca on the update thread.";
		if (area && strstr(area, "render"))
			return "Crashed on the OpenGL thread. Check overlay/ImGui data races (copy render snapshots under the module mutex).";
		if (area && strstr(area, "CommonData"))
			return "Crashed while snapshotting the world. Likely a bad JNI mapping or disconnect mid-tick.";
		if (area && strstr(area, "::Update"))
			return "Crashed inside a module Update(). That module was auto-disabled — reproduce with only that module on.";
		return "See breadcrumbs + fault module above. Reproduce, then search the codebase for the last CRASH_SCOPE / module name.";
	}

	void WriteReport(EXCEPTION_POINTERS* ep, const char* area, const char* extra)
	{
		if (g_writing.exchange(1) != 0)
			return;

		EnsureCrashDir();

		SYSTEMTIME st{};
		GetLocalTime(&st);
		char stamp[32]{};
		snprintf(stamp, sizeof(stamp), "%04d%02d%02d_%02d%02d%02d",
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

		char txtPath[MAX_PATH]{};
		char dmpPath[MAX_PATH]{};
		snprintf(txtPath, sizeof(txtPath), "%s\\crash_%s.txt", g_crashDir, stamp);
		snprintf(dmpPath, sizeof(dmpPath), "%s\\crash_%s.dmp", g_crashDir, stamp);
		SafeCopy(g_lastReport, sizeof(g_lastReport), txtPath);

		static char report[kReportCap];
		int used = 0;

		const DWORD code = (ep && ep->ExceptionRecord) ? ep->ExceptionRecord->ExceptionCode : 0;
		void* fault = (ep && ep->ExceptionRecord) ? ep->ExceptionRecord->ExceptionAddress : nullptr;
		const DWORD tid = GetCurrentThreadId();

		used = Append(report, kReportCap, used,
			"Lateware V2 crash report\n"
			"======================\n"
			"Time:              %04d-%02d-%02d %02d:%02d:%02d\n"
			"Client:            %s %s\n"
			"Minecraft:         %s\n"
			"Thread:            %lu%s\n"
			"Area:              %s\n"
			"TLS context:       %s\n"
			"Exception:         0x%08lX (%s)\n"
			"Fault address:     %p\n",
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond,
			Base::m_name,
			Base::m_version,
			McVersionName(),
			tid,
			(tid == g_updateThreadId) ? "  [update thread]" : "  [likely render / JVM thread]",
			area ? area : "(unknown)",
			t_context ? t_context : "(none)",
			code, ExceptionName(code),
			fault);

		if (ep && ep->ExceptionRecord && code == EXCEPTION_ACCESS_VIOLATION
			&& ep->ExceptionRecord->NumberParameters >= 2)
		{
			used = Append(report, kReportCap, used, "Access:            %s at %p\n",
				ep->ExceptionRecord->ExceptionInformation[0] == 1 ? "WRITE" :
				ep->ExceptionRecord->ExceptionInformation[0] == 8 ? "DEP/NX" : "READ",
				(void*)ep->ExceptionRecord->ExceptionInformation[1]);
		}

		char faultMod[MAX_PATH]{};
		uintptr_t faultBase = 0;
		ModuleNameFromAddr(fault, faultMod, sizeof(faultMod), &faultBase);
		if (faultMod[0])
		{
			used = Append(report, kReportCap, used, "Fault module:      %s\n", faultMod);
			used = Append(report, kReportCap, used, "Fault offset:      0x%llX\n",
				(unsigned long long)((uintptr_t)fault - faultBase));
		}

		HMODULE self = nullptr;
		GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
			(LPCSTR)&WriteReport, &self);
		char selfPath[MAX_PATH]{};
		if (self)
			GetModuleFileNameA(self, selfPath, MAX_PATH);
		used = Append(report, kReportCap, used, "Lateware V2 module:  %p  %s\n", self, selfPath);

		used = Append(report, kReportCap, used,
			"Java::env:         %p\n"
			"Java initialized:  %s\n"
			"SDK::minecraft:    %p\n"
			"dataUpdated:       %s\n"
			"in-world players:  %zu\n",
			Java::env,
			Java::initialized ? "yes" : "no",
			SDK::minecraft,
			CommonData::dataUpdated.load() ? "yes" : "no",
			CommonData::nativePlayerList.size());

		if (extra && extra[0])
			used = Append(report, kReportCap, used, "Extra:             %s\n", extra);

		used = Append(report, kReportCap, used, "Hint:              %s\n\n", HintFor(code, area));

		if (ep && ep->ContextRecord)
			DumpStack(report, kReportCap, used, ep->ContextRecord);

		DumpBreadcrumbs(report, kReportCap, used);
		// Salvage the useful bits if enumerating modules crashes (heap already toast).
		WriteFileAll(txtPath, report, used);
		if (ep)
			WriteMinidump(dmpPath, ep);

		DumpEnabledModules(report, kReportCap, used);
		DumpLoadedModules(report, kReportCap, used, fault);

		used = Append(report, kReportCap, used,
			"=== How to use this ===\n"
			"1. Area / TLS context names the last guarded scope (module or subsystem).\n"
			"2. Breadcrumbs are the last ~%d log lines before the crash.\n"
			"3. Open the .dmp in Visual Studio with a matching Lateware V2.dll for a full call stack.\n"
			"4. If a module was auto-disabled, turn only that module back on to reproduce.\n",
			kBreadcrumbCap);

		WriteFileAll(txtPath, report, used);
		PruneOldCrashes();

		char console[512]{};
		snprintf(console, sizeof(console), "[CRASH] %s  wrote %s", area ? area : "unknown", txtPath);
		OutputDebugStringA(console);
		fputs(console, stdout);
		fputc('\n', stdout);
		fflush(stdout);

		g_writing.store(0);
	}

	LONG WINAPI Unhandled(EXCEPTION_POINTERS* ep)
	{
		WriteReport(ep, t_context, "unhandled process exception");
		if (g_prevFilter)
			return g_prevFilter(ep);
		return EXCEPTION_CONTINUE_SEARCH;
	}

	void OnTerminate()
	{
		WriteReport(nullptr, t_context, "std::terminate (uncaught C++ exception)");
		if (g_prevTerminate)
			g_prevTerminate();
		abort();
	}

	void OnAbort(int)
	{
		WriteReport(nullptr, t_context, "abort() / fatal CRT");
		signal(SIGABRT, SIG_DFL);
		abort();
	}

	void OnInvalidParameter(const wchar_t*, const wchar_t*, const wchar_t*, unsigned int, uintptr_t)
	{
		WriteReport(nullptr, t_context, "invalid CRT parameter");
	}

	void OnPureCall()
	{
		WriteReport(nullptr, t_context, "pure virtual call");
	}
}

CrashHandler::Scope::Scope(const char* area)
	: m_prev(t_context)
{
	t_context = area ? area : "none";
}

CrashHandler::Scope::~Scope()
{
	t_context = m_prev;
}

void CrashHandler::SetContext(const char* area)
{
	t_context = area ? area : "none";
}

const char* CrashHandler::GetContext()
{
	return t_context ? t_context : "none";
}

void CrashHandler::Breadcrumb(const char* text)
{
	if (!text)
		return;
	const unsigned idx = g_crumbHead.fetch_add(1, std::memory_order_relaxed) % kBreadcrumbCap;
	SYSTEMTIME st{};
	GetLocalTime(&st);
	snprintf(g_crumbs[idx], kBreadcrumbLen, "%02u:%02u:%02u.%03u [%s] %s",
		st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
		t_context ? t_context : "none",
		text);
	unsigned count = g_crumbCount.load(std::memory_order_relaxed);
	if (count < (unsigned)kBreadcrumbCap)
		g_crumbCount.compare_exchange_strong(count, count + 1, std::memory_order_relaxed);
}

void CrashHandler::Breadcrumbf(const char* fmt, ...)
{
	char buf[kBreadcrumbLen]{};
	va_list args;
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);
	Breadcrumb(buf);
}

void CrashHandler::CheckJni(const char* where)
{
	if (!Java::env || !Java::env->ExceptionCheck())
		return;

	jthrowable thrown = Java::env->ExceptionOccurred();
	Java::env->ExceptionClear();

	char msg[256] = "pending JNI exception";
	if (thrown)
	{
		jclass cls = Java::env->GetObjectClass(thrown);
		if (cls)
		{
			std::string name = Java::GetClazzName(thrown);
			jmethodID mid = Java::env->GetMethodID(cls, "getMessage", "()Ljava/lang/String;");
			jstring jmsg = mid ? (jstring)Java::env->CallObjectMethod(thrown, mid) : nullptr;
			if (Java::env->ExceptionCheck())
			{
				Java::env->ExceptionClear();
				jmsg = nullptr;
			}
			const std::string detail = Java::JStringToStd(jmsg);
			snprintf(msg, sizeof(msg), "JNI %s: %s%s%s",
				where ? where : "?",
				name.c_str(),
				detail.empty() ? "" : " — ",
				detail.c_str());
			Java::DeleteLocal(jmsg);
			Java::DeleteLocal(cls);
		}
		Java::DeleteLocal(thrown);
	}

	Breadcrumb(msg);
}

const char* CrashHandler::LastReportPath()
{
	return g_lastReport;
}

void CrashHandler::Init()
{
	if (g_inited.exchange(1) != 0)
		return;

	g_updateThreadId = GetCurrentThreadId();
	EnsureCrashDir();
	SetContext("Init");
	Breadcrumb("CrashHandler initialized");

	g_prevFilter = SetUnhandledExceptionFilter(Unhandled);
	g_prevTerminate = std::set_terminate(OnTerminate);
	signal(SIGABRT, OnAbort);
	_set_abort_behavior(0, _WRITE_ABORT_MSG);
	_set_purecall_handler(OnPureCall);
	_set_invalid_parameter_handler(OnInvalidParameter);
}

void CrashHandler::Shutdown()
{
	if (g_inited.exchange(0) == 0)
		return;
	SetUnhandledExceptionFilter(g_prevFilter);
	std::set_terminate(g_prevTerminate);
	signal(SIGABRT, SIG_DFL);
	_set_purecall_handler(nullptr);
	_set_invalid_parameter_handler(nullptr);
}

static LONG GuardFilter(EXCEPTION_POINTERS* ep)
{
	WriteReport(ep, t_guardArea, "caught by CrashHandler::Guard — execution continued");
	return EXCEPTION_EXECUTE_HANDLER;
}

bool CrashHandler::Guard(Fn fn, void* user, const char* area)
{
	if (!fn)
		return true;

	SetContext(area);
	t_guardArea = area;

	__try
	{
		fn(user);
		t_guardArea = nullptr;
		SetContext("none");
		return true;
	}
	__except (GuardFilter(GetExceptionInformation()))
	{
		t_guardArea = nullptr;
		SetContext("none");
		return false;
	}
}
