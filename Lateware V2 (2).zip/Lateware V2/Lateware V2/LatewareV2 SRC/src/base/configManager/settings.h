#pragma once

#include <string>
#include <vector>

#include <Windows.h>

struct settings
{
	inline static std::vector<std::string> friends;

	// Menu — dark charcoal + pink accent (reference GUI style)
	inline static float Menu_TextColor[4]{ 0.96f, 0.96f, 0.98f, 1.0f };
	inline static float Menu_SeperatorColor[4]{ 1.0f, 1.0f, 1.0f, 0.06f };
	inline static float Menu_PrimaryColor[4]{ 1.0f, 0.294f, 0.471f, 1.0f };      // #FF4B78
	inline static float Menu_SecondaryColor[4]{ 0.08f, 0.08f, 0.09f, 1.0f };     // dark knob on pink
	inline static float Menu_BackgroundColor[4]{ 0.07f, 0.07f, 0.075f, 0.98f };  // charcoal
	inline static float Menu_ChildBackgroundColor[4]{ 0.10f, 0.10f, 0.11f, 0.95f };
	inline static float Menu_OutlineColor[4]{ 1.0f, 1.0f, 1.0f, 0.04f };
	inline static float Menu_DetachButtonColor[4]{ 1.0f, 0.294f, 0.471f, 0.85f };

	inline static float Menu_WindowRounding = 16.0f;
	inline static float Menu_ComponentsRounding = 10.0f;

	inline static int Menu_Keybind = VK_INSERT;
	inline static int Menu_DetachKey = VK_END;

	inline static bool Menu_GUIMovement = false;
	inline static bool Menu_ShowHiddenCategories = false;
	inline static std::vector<std::string> Menu_HiddenCategoriesList{ "TnT Tag" };

	// Hud
	inline static bool Hud_DisableAllRendering = false;
	inline static bool Hud_Watermark = true;
	inline static float Hud_WatermarkPosition[2]{ 10, 10 };
	inline static bool Hud_WatermarkVersion = true;
	inline static bool Hud_WatermarkFps = false;
	inline static bool Hud_WatermarkPing = false;
	inline static bool Hud_WatermarkCoords = false;
	inline static bool Hud_WatermarkDirection = false;
	inline static bool Hud_WatermarkTime = false;
	inline static bool Hud_ShowKeybinds = true;
	inline static float Hud_KeybindsPosition[2]{ 10, 10 };

	// ESP
	inline static bool ESP_Enabled = false;
	inline static int ESP_Key = 0x0;
	inline static float ESP_FadeDistance = 3.0f;
	inline static bool ESP_HealthBar = true;
	inline static int ESP_BoxType = 0;
	inline static const char* ESP_BoxTypeList[4]{ "Corner 2D", "3D Box" };
	inline static float ESP_3DBoxColor[4]{ 0.85f, 0.88f, 0.95f, 0.9f };
	inline static float ESP_3DBoxThickness = 1.25f;
	inline static bool ESP_Box = true;
	inline static float ESP_BoxColor[4]{ 0.85f, 0.88f, 0.95f, 0.95f };
	inline static bool ESP_FilledBox = true;
	inline static float ESP_FilledBoxColor[4]{ 1.0f, 0.294f, 0.471f, 0.08f };
	inline static float ESP_SecondFilledBoxColor[4]{ 1.0f, 0.294f, 0.471f, 0.02f };
	inline static bool ESP_Outline = true;
	inline static float ESP_OutlineColor[4]{ 0.0f, 0.0f, 0.0f, 0.55f };
	inline static bool ESP_HighlightFriends = true;
	inline static float ESP_Friend3DBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.95f };
	inline static float ESP_FriendBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.95f };
	inline static float ESP_FriendFilledBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.10f };
	inline static float ESP_FriendSecondFilledBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.02f };
	inline static float ESP_FriendOutlineColor[4]{ 0.0f, 0.0f, 0.0f, 0.55f };

	// NVIDIA Overlay ESP (GeForce Overlay window / D2D) — keys kept as DESP_* for config compat
	inline static bool DESP_Enabled = false;
	inline static int DESP_Key = 0x0;
	inline static bool DESP_Box = true;
	inline static bool DESP_FilledBox = true;
	inline static bool DESP_Outline = true;
	inline static bool DESP_HealthBar = true;
	inline static bool DESP_Nametags = true;
	inline static bool DESP_ShowDistance = true;
	inline static bool DESP_ShowHealth = false;
	inline static bool DESP_NameBackground = true;
	inline static int DESP_TextScale = 2;
	inline static float DESP_MaxDistance = 128.0f;
	inline static float DESP_FadeDistance = 3.0f;
	inline static bool DESP_IgnoreFriends = false;
	inline static bool DESP_HighlightFriends = true;
	inline static float DESP_BoxColor[4]{ 0.85f, 0.88f, 0.95f, 0.95f };
	inline static float DESP_FilledBoxColor[4]{ 1.0f, 0.294f, 0.471f, 0.10f };
	inline static float DESP_NameColor[4]{ 0.95f, 0.96f, 0.98f, 1.0f };
	inline static float DESP_NameBackgroundColor[4]{ 0.05f, 0.055f, 0.07f, 0.72f };
	inline static float DESP_FriendBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.95f };
	inline static float DESP_FriendFilledBoxColor[4]{ 0.35f, 0.95f, 0.55f, 0.12f };
	inline static float DESP_FriendNameColor[4]{ 0.45f, 1.0f, 0.60f, 1.0f };
	// Cap overlay redraws. Lower = better game FPS. Drawing is async.
	inline static int DESP_OverlayFps = 30;

	// Nametag
	inline static bool NT_Enabled = false;
	inline static int NT_Key = 0x0;
	inline static float NT_TextSize = 16;
	inline static float NT_TextColor[4]{ 0.95f, 0.96f, 0.98f, 1.0f };
	inline static bool NT_TextOutline = true;
	inline static float NT_TextOutlineColor[4]{ 0.0f, 0.0f, 0.0f, 0.85f };
	inline static float NT_TextUnrenderDistance = 14.0f;
	inline static float NT_FadeDistance = 3.0f;
	inline static bool NT_Background = true;
	inline static float NT_BackgroundColor[4]{ 0.05f, 0.055f, 0.07f, 0.72f };
	inline static bool NT_BackgroundOutline = true;
	inline static float NT_BackgroundOutlineColor[4]{ 1.0f, 1.0f, 1.0f, 0.08f };
	inline static bool NT_IgnoreFriends = true;
	inline static bool NT_MultiLine = false;
	inline static bool NT_DisplayHealth = true;
	inline static bool NT_DisplayDistance = true;
	inline static bool NT_DisplayInvisible = true;
	inline static bool NT_DisplayArmor = true;
	inline static bool NT_DisplayHeldItem = true;

	// Array List
	inline static bool AL_Enabled = false;
	inline static int AL_Key = 0x0;
	inline static int AL_renderPosition = 1;
	inline static const char* AL_renderPositionList[4]{ "Top Left", "Top Right", "Bottom Left", "Bottom Right" };
	inline static float AL_textSize = 11;
	inline static float AL_textColor[4]{ 1.f, 1.f, 1.f, 1.f };
	inline static float AL_backgroundPadding = 5;
	inline static float AL_backgroundColor[4]{ 0.f, 0.f, 0.f, 0.8f };
	inline static float AL_backgroundRoundness = 5.f;
    inline static int AL_colorMode = 0;
    inline static const char* AL_colorModeList[16]{ 
	    "Static", "RGB Wave", "Purple Rain", "Golden Luxury", "Red Flow", "Neon Pulse",
	    "Ocean Depth", "Forest Mystical", "Sunset Dream", "Cotton Candy", "Magma Flow",
        "Aqua Breeze", "Cosmic Wave", "Cherry Blossom", "Cyberpunk"
    };
    inline static float AL_rgbSpeed = 1.0f;
    inline static bool AL_gradientEnabled = false;
    inline static float AL_gradientStartColor[4]{ 1.0f, 0.0f, 0.0f, 1.0f };
    inline static float AL_gradientEndColor[4]{ 0.0f, 0.0f, 1.0f, 1.0f };
	inline static bool AL_outlineEnabled = false;
    inline static float AL_outlineThickness = 1.0f;
    inline static float AL_outlineColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    inline static bool AL_outlineRGB = true;
	
	// Radar
	inline static bool Radar_Enabled = false;
	inline static int Radar_Key = 0x0;
	inline static float Radar_Radius = 50.0f;
	inline static bool Radar_RotateWithPlayer = true;
	inline static bool Radar_ShowNames = false;
	inline static float Radar_Size = 200.0f;
	inline static float Radar_SquareRoundness = 10.0f;
	inline static float Radar_Position[2]{ 10, 10 };
	inline static float Radar_LocalPlayerColor[4]{ 1, 0.5, 0, 1 };
	inline static float Radar_PlayerColor[4]{ 1, 1, 1, 1 };
	inline static float Radar_FriendColor[4]{ 0, 1, 0, 1 };
	inline static float Radar_BackgroundColor[4]{ 0.f, 0.f, 0.f, 0.8f };

	// Block ESP
	inline static bool BlockESP_Enabled = false;
	inline static int BlockESP_Key = 0x0;
	inline static int BlockESP_TargetID = 35;

	// SmokeBomb ESP (Mineplex Assassin Smoke Bomb)
	inline static bool SBESP_Enabled = false;
	inline static int SBESP_Key = 0x0;
	inline static float SBESP_MaxDistance = 64.f;

	// Aim Assist (Dope-style: center / multipoint yaw assist)
	inline static bool AA_Enabled = false;
	inline static int AA_Key = 0x0;
	inline static float AA_aimDistance = 6.f;
	inline static float AA_fov = 70.f;
	inline static float AA_speed = 2.5f;
	inline static bool AA_weaponOnly = true;
	inline static bool AA_throughWalls = false;
	inline static bool AA_clickingOnly = false;
	inline static bool AA_pitchRand = false;
	inline static int AA_mode = 0; // 0=Center, 1=Multipoint
	inline static const char* AA_modeList[2]{ "Center", "Multipoint" };
	inline static bool AA_ignoreFriends = true;
	inline static bool AA_fovCircle = false;
	inline static float AA_fovCircleColor[4]{ 1.f, 1.f, 1.f, 1.f };

	// Reach
	inline static bool Reach_Enabled = false;
	inline static int Reach_Key = 0x0;
	inline static float Reach_ReachDistance = 3.0f;

	// Anti Evade
	inline static bool AE_Enabled = false;
	inline static int AE_Key = 0x0;
	inline static float AE_Range = 4.5f;
	inline static float AE_Fov = 40.0f;
	inline static bool AE_IgnoreFriends = true;
	inline static int AE_MaxBlockPause = 1050; // their Evade fails ~1000ms into the block; resume clicking after this

	// Auto Evade
	inline static bool AutoE_Enabled = false;
	inline static int AutoE_Key = 0x0;
	inline static float AutoE_Range = 4.5f;
	inline static float AutoE_Fov = 60.0f;
	inline static int AutoE_BlockDuration = 1000; // Mineplex Evade fails after 1000ms of not being hit
	inline static int AutoE_ReleaseGap = 300;     // success recharge is 250ms; re-arm just after
	inline static int AutoE_FailCooldown = 16000; // failed Evade forces a 16s recharge
	inline static int AutoE_WaterRetryMs = 2000;  // wait after "cannot Evade in water" before retrying
	inline static int AutoE_FirstEvadeOffset = 0; // delay (ms) on first evade only; later ones fire immediately
	inline static bool AutoE_RequireLeather = true;
	inline static bool AutoE_RequireWeapon = true;
	inline static bool AutoE_IgnoreFriends = true;
	// Prediction (master toggle + per-feature checkbox/slider)
	inline static bool AutoE_PredictiveEnabled = true;
	inline static bool AutoE_RapidHitsEnabled = true;
	inline static int AutoE_RapidHits = 2;              // 0-5 opponent hits (no damage) before evade
	inline static bool AutoE_SuccessPredEnabled = true;
	inline static int AutoE_SuccessPredCount = 3;       // successful evades before look-only mode
	inline static bool AutoE_AntiWalkbackEnabled = true;
	inline static int AutoE_AntiWalkbackMs = 2000;      // ms walking away while hitting = bait
	inline static bool AutoE_SwingHook = false;   // DISABLED — HotSpot swingItem hook crashed on hit
	inline static bool AutoE_FastInput = true;    // keyBindUseItem instead of SendMessage
	inline static bool AutoE_FastLoop = true;     // 1ms loop only while blocking/prepared

	// Auto-Flash Stab — press once: axe -> RMB flash -> proximity triggerbot hit
	inline static bool AFS_Enabled = false;
	inline static int AFS_Key = 0x0;             // fire key (press once)
	inline static float AFS_FlashRange = 6.0f;
	inline static float AFS_Fov = 60.0f;
	inline static float AFS_HitProximity = 0.1f; // click when this close to their hitbox (inside them)
	inline static int AFS_MinArm = 10;           // ms after flash starts before triggerbot can fire
	inline static int AFS_Timeout = 1000;        // abandon if never near enough
	inline static bool AFS_RestoreSlot = true;
	inline static bool AFS_IgnoreFriends = true;

	// Auto Bottle
	inline static bool AB_Enabled = false;
	inline static int AB_Key = 0x0;
	inline static bool AB_Poison = true;
	inline static bool AB_Slow = true;
	inline static bool AB_Blind = true;
	inline static bool AB_Wither = true;
	inline static bool AB_Silence = true;
	inline static bool AB_AntiVoidMage = false; // skip bottling while Slowness III + Invisibility II
	inline static int AB_Cooldown = 5000; // Mineplex bottle recharge

	// Sprint Reset
	inline static bool SR_Enabled = false;
	inline static int SR_Key = 0x0;
	inline static float SR_DelayBetween = .5f;
	inline static float SR_LetGoDelay = .05f;

	// Sprint
	inline static bool S_Enabled = false;
	inline static int S_Key = 0x0;

	// Left Auto Clicker
	inline static bool LAC_Enabled = false;
	inline static int LAC_Key = 0x0;
	inline static float LAC_leftMaxCps = 18;
	inline static float LAC_leftMinCps = 13;
	inline static bool LAC_ignoreBlocks = true;
	inline static bool LAC_swordBlock = true;
	inline static bool LAC_weaponOnly = false;
	inline static bool LAC_allowInventory = false;
	inline static float LAC_inventoryMultiplier = 1.0f;
	inline static bool LAC_advancedMode = false;
	inline static float LAC_dropChance = 5.0f;
	inline static float LAC_spikeChance = 8.0f;
	inline static float LAC_spikeMultiplier = 1.3f;
	inline static float LAC_kurtosis = 1.0f;
	inline static bool LAC_burstEnabled = true;
	inline static float LAC_burstChance = 15.0f;

	// Right Auto Clicker
	inline static bool RAC_Enabled = false;
	inline static int RAC_Key = 0x0;
	inline static float RAC_rightMaxCps = 15;
	inline static float RAC_rightMinCps = 12;
	inline static bool RAC_blocksOnly = true;

	// Bridge Assist
	inline static bool BA_Enabled = false;
	inline static int BA_Key = 0x0;
	inline static bool BA_OnlyOnShift = true;
	inline static bool BA_IgnoreForwardsMovement = true;
	inline static bool BA_AutoSwap = false;
	inline static float BA_PitchCheck = 61.0f;
	inline static int BA_BlockCheck = 1;

	// Velocity
	inline static bool Velocity_Enabled = false;
	inline static int Velocity_Key = 0x0;
	inline static int Velocity_Mode = 0;
	inline static const char* Velocity_ModeList[0]{ "Jump Reset" };
	inline static float Velocity_JRReactionTime = 0.1f;
	inline static int Velocity_JRChange = 80;

	// Chest Stealer
	inline static bool CS_Enabled = false;
	inline static int CS_Key = 0x0;
	inline static int CS_Delay = 50;
	inline static std::vector<std::pair<int, int>> CS_Items{ };

	// Inventory Sorter
	inline static bool IS_Enabled = false;
	inline static int IS_Key = 0x0;
	inline static int IS_Delay = 50;

	// Client Brand Changer
	inline static bool CBC_Enabled = false;
	inline static int CBC_Key = 0x0;
	inline static std::string CBC_ClientBrand;

	// Block Reach
	inline static bool BR_Enabled = false;
	inline static int BR_Key = 0x0;
	inline static float BR_ReachDistance = 4.5f;

	// Weapon
	inline static bool Weapon_Sword = true;
	inline static bool Weapon_Axe = false;
	inline static bool Weapon_Stick = false;
	inline static bool Weapon_Fist = false;

	// Tag Back
	inline static bool TB_Enabled = false;
	inline static int TB_Key = 0x0;
	inline static bool TB_visibilityCheck = true;
	inline static bool TB_aimAssistFeedback = true;
	inline static float TB_aimAssistFeedbackColor[4]{ 1, 1, 1, 1 };
	inline static bool TB_fovCircle = true;
	inline static float TB_fovCircleColor[4]{ 1, 1, 1, 1 };
	inline static bool TB_adaptive = true;
	inline static float TB_adaptiveOffset = 3;
	inline static float TB_fov = 35.0f;
	inline static float TB_smooth = 15.f;
	inline static float TB_randomYaw = 2;
	inline static float TB_randomPitch = .075f;
	inline static int TB_targetPriority = 2;
	inline static const char* TB_targetPriorityList[3]{ "Distance", "Health", "Closest to Crosshair" };
	inline static bool TB_ignoreFriends = true;
	inline static bool TB_autoClick = true;
	inline static int TB_maxCps = 15;
	inline static int TB_minCps = 10;

	// IT Esp
	inline static bool ITESP_Enabled = false;
	inline static int ITESP_Key = 0x0;
	inline static bool ITESP_Text = true;
	inline static float ITESP_TextSize = 18;
	inline static float ITESP_TextColor[4]{ 1.0f, 1.0f, 1.0f, 1.0f };
	inline static bool ITESP_TextOutline = true;
	inline static float ITESP_TextOutlineColor[4]{ 0, 0, 0, 1.0f };
	inline static float ITESP_TextUnrenderDistance = 14.0f;
	inline static float ITESP_FadeDistance = 3.0f;
	inline static bool ITESP_HealthBar = true;
	inline static int ITESP_BoxType = 0;
	inline static const char* ITESP_BoxTypeList[4]{ "Dynamic 2D Box", "3D Box" };
	inline static float ITESP_3DBoxColor[4]{ 1, 0, 0, 1 };
	inline static float ITESP_3DBoxThickness = 1.0f;
	inline static bool ITESP_Box = true;
	inline static float ITESP_BoxColor[4]{ 1, 0, 0, 1 };
	inline static bool ITESP_FilledBox = true;
	inline static float ITESP_FilledBoxColor[4]{ 1, 0, 0, 0.15f };
	inline static float ITESP_SecondFilledBoxColor[4]{ 1, 0, 0, 0.15f };
	inline static bool ITESP_Outline = true;
	inline static float ITESP_OutlineColor[4]{ 1, 0, 0, 0.25 };
	inline static bool ITESP_HighlightFriends = true;
	inline static float ITESP_Friend3DBoxColor[4]{ 0, 1, 0, 1 };
	inline static float ITESP_FriendBoxColor[4]{ 0, 1, 0, 1 };
	inline static float ITESP_FriendFilledBoxColor[4]{ 0, 1, 0, 0.15f };
	inline static float ITESP_FriendSecondFilledBoxColor[4]{ 0, 1, 0, 0.15f };
	inline static float ITESP_FriendOutlineColor[4]{ 0, 1, 0, 0.25 };
};
