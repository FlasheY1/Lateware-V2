#pragma once

#include <string>

#include <jni/jni.h>
#include <jni/jvmti.h>

enum MinecraftVersion
{
	LUNAR_1_8_9,
	VANILLA_1_8_9,
	FORGE_1_8_9,
	LUNAR_1_7_10,
	VANILLA_1_7_10,
	FORGE_1_7_10,
	UNKNOWN
};

struct Java
{
	static void Init();
	static void Shutdown();

	static bool AssignClass(std::string name, jclass &out);
	static jclass GetClass(std::string name);
	static jclass FindClass(JNIEnv* env, jvmtiEnv* tienv, const std::string& path);
	static std::string GetClazzName(jobject obj);

	static void GetMinecraftVersion();

	// Copy a Java string to std::string, then release the UTF chars.
	// Does not DeleteLocalRef the jstring — caller owns that ref.
	static std::string JStringToStd(jstring str);

	static inline void DeleteLocal(jobject obj)
	{
		if (env != nullptr && obj != nullptr)
			env->DeleteLocalRef(obj);
	}

	static inline void PromoteGlobal(jclass& cls)
	{
		if (env == nullptr || cls == nullptr)
			return;
		jclass global = (jclass)env->NewGlobalRef(cls);
		env->DeleteLocalRef(cls);
		cls = global;
	}

	static inline void DeleteGlobal(jclass& cls)
	{
		if (env != nullptr && cls != nullptr)
			env->DeleteGlobalRef(cls);
		cls = nullptr;
	}

	static inline void ClearException()
	{
		if (env != nullptr && env->ExceptionCheck())
			env->ExceptionClear();
	}

	template<typename T>
	static T Convert(jobject obj);

	static inline JNIEnv* env = nullptr;
	static inline jvmtiEnv* tiEnv = nullptr;
	static inline bool initialized = false;
	static inline MinecraftVersion version = MinecraftVersion::UNKNOWN;

	// Bootstrap classes / method IDs — global refs, valid for the process lifetime.
	static inline jclass class_String = nullptr;
	static inline jclass class_List = nullptr;
	static inline jclass class_Set = nullptr;
	static inline jclass class_Map = nullptr;
	static inline jclass class_FloatBuffer = nullptr;
	static inline jclass class_Class = nullptr;

	static inline jmethodID mid_List_toArray = nullptr;
	static inline jmethodID mid_Set_toArray = nullptr;
	static inline jmethodID mid_Class_getName = nullptr;
	static inline jmethodID mid_FloatBuffer_get = nullptr;
	static inline jmethodID mid_Map_entrySet = nullptr;
};
