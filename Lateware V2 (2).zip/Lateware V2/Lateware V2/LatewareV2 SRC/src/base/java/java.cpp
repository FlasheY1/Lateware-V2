#include "java.h"

#include "util/logger.h"
#include "sdk/java/lang/String.h"

JavaVM* vm = nullptr;
jobject classLoader = nullptr;
jmethodID mid_findClass = nullptr;

static void setupClassLoader()
{
    jclass c_Thread = Java::env->FindClass("java/lang/Thread");
    jclass c_Map = Java::env->FindClass("java/util/Map");
    jclass c_Set = Java::env->FindClass("java/util/Set");
    jclass c_ClassLoader = Java::env->FindClass("java/lang/ClassLoader");

    if (!c_Thread || !c_Map || !c_Set || !c_ClassLoader)
    {
        Java::ClearException();
        LOG_ERROR("Failed to find core Java classes for classloader setup");
        return;
    }

    jmethodID mid_getAllStackTraces = Java::env->GetStaticMethodID(c_Thread, "getAllStackTraces", "()Ljava/util/Map;");
    jmethodID mid_keySet = Java::env->GetMethodID(c_Map, "keySet", "()Ljava/util/Set;");
    jmethodID mid_toArray = Java::env->GetMethodID(c_Set, "toArray", "()[Ljava/lang/Object;");
    jmethodID mid_getContextClassLoader = Java::env->GetMethodID(c_Thread, "getContextClassLoader", "()Ljava/lang/ClassLoader;");
    mid_findClass = Java::env->GetMethodID(c_ClassLoader, "findClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jmethodID mid_currentThread = Java::env->GetStaticMethodID(c_Thread, "currentThread", "()Ljava/lang/Thread;");

    if (!mid_getAllStackTraces || !mid_keySet || !mid_toArray || !mid_getContextClassLoader || !mid_findClass)
    {
        Java::ClearException();
        LOG_ERROR("Failed to resolve ClassLoader helper methods");
        return;
    }

    jobject obj_stackTracesMap = Java::env->CallStaticObjectMethod(c_Thread, mid_getAllStackTraces);
    if (Java::env->ExceptionCheck() || !obj_stackTracesMap)
    {
        Java::ClearException();
        LOG_ERROR("getAllStackTraces failed");
        return;
    }

    jobject obj_threadsSet = Java::env->CallObjectMethod(obj_stackTracesMap, mid_keySet);
    jobjectArray threads = (jobjectArray)Java::env->CallObjectMethod(obj_threadsSet, mid_toArray);
    if (Java::env->ExceptionCheck() || !threads)
    {
        Java::ClearException();
        LOG_ERROR("Failed to enumerate threads for classloader");
        return;
    }

    jint szThreads = Java::env->GetArrayLength(threads);

    for (int i = 0; i < szThreads; i++)
    {
        jobject thread = Java::env->GetObjectArrayElement(threads, i);
        jobject classLoaderObj = Java::env->CallObjectMethod(thread, mid_getContextClassLoader);
        Java::ClearException();

        if (classLoaderObj)
        {
            jstring className = Java::env->NewStringUTF("net.minecraft.client.Minecraft");
            jobject minecraftClass = Java::env->CallObjectMethod(classLoaderObj, mid_findClass, className);
            if (Java::env->ExceptionCheck())
            {
                Java::env->ExceptionClear();
                minecraftClass = nullptr;
            }

            Java::env->DeleteLocalRef(className);

            if (minecraftClass)
            {
                classLoader = Java::env->NewGlobalRef(classLoaderObj);

                Java::env->DeleteLocalRef(minecraftClass);
                Java::env->DeleteLocalRef(classLoaderObj);
                Java::env->DeleteLocalRef(thread);
                break;
            }

            Java::env->DeleteLocalRef(classLoaderObj);
        }

        Java::env->DeleteLocalRef(thread);
    }

    Java::env->DeleteLocalRef(threads);
    Java::env->DeleteLocalRef(obj_stackTracesMap);
    Java::env->DeleteLocalRef(obj_threadsSet);
    Java::env->DeleteLocalRef(c_Thread);
    Java::env->DeleteLocalRef(c_Map);
    Java::env->DeleteLocalRef(c_Set);
    Java::env->DeleteLocalRef(c_ClassLoader);

    Java::initialized = (classLoader != nullptr);
    if (!Java::initialized)
        LOG_ERROR("Could not locate Minecraft classloader");
}

static void InitCoreClasses()
{
    Java::class_String = Java::env->FindClass("java/lang/String");
    Java::class_List = Java::env->FindClass("java/util/List");
    Java::class_Set = Java::env->FindClass("java/util/Set");
    Java::class_Map = Java::env->FindClass("java/util/Map");
    Java::class_FloatBuffer = Java::env->FindClass("java/nio/FloatBuffer");
    Java::class_Class = Java::env->FindClass("java/lang/Class");
    Java::ClearException();

    Java::PromoteGlobal(Java::class_String);
    Java::PromoteGlobal(Java::class_List);
    Java::PromoteGlobal(Java::class_Set);
    Java::PromoteGlobal(Java::class_Map);
    Java::PromoteGlobal(Java::class_FloatBuffer);
    Java::PromoteGlobal(Java::class_Class);

    if (Java::class_List)
        Java::mid_List_toArray = Java::env->GetMethodID(Java::class_List, "toArray", "()[Ljava/lang/Object;");
    if (Java::class_Set)
        Java::mid_Set_toArray = Java::env->GetMethodID(Java::class_Set, "toArray", "()[Ljava/lang/Object;");
    if (Java::class_Class)
        Java::mid_Class_getName = Java::env->GetMethodID(Java::class_Class, "getName", "()Ljava/lang/String;");
    if (Java::class_FloatBuffer)
        Java::mid_FloatBuffer_get = Java::env->GetMethodID(Java::class_FloatBuffer, "get", "(I)F");
    if (Java::class_Map)
        Java::mid_Map_entrySet = Java::env->GetMethodID(Java::class_Map, "entrySet", "()Ljava/util/Set;");
    Java::ClearException();
}

void Java::Init()
{
    Java::initialized = false;
    Java::version = MinecraftVersion::UNKNOWN;
    classLoader = nullptr;
    mid_findClass = nullptr;
    Java::env = nullptr;
    Java::tiEnv = nullptr;
    vm = nullptr;

    jsize count = 0;
    if (JNI_GetCreatedJavaVMs(&vm, 1, &count) != JNI_OK || count == 0)
    {
        LOG_ERROR("No Java VM found in process");
        return;
    }

    jint res = vm->GetEnv((void**)&Java::env, JNI_VERSION_1_6);
    LOG_INFO("Got Java ENV");

    if (res == JNI_EDETACHED)
        res = vm->AttachCurrentThread((void**)&Java::env, nullptr);
    LOG_INFO("Attached to Java VM");

    if (res != JNI_OK || Java::env == nullptr)
    {
        LOG_ERROR("Failed to attach to Java VM");
        Java::env = nullptr;
        return;
    }

    InitCoreClasses();

    vm->GetEnv((void**)&Java::tiEnv, JVMTI_VERSION);
    setupClassLoader();
    if (!Java::initialized)
    {
        LOG_ERROR("Java classloader setup failed");
        return;
    }

    LOG_INFO("Java initialized");

    GetMinecraftVersion();
    Java::ClearException();
    LOG_INFO("Got Minecraft version: %d", static_cast<int>(Java::version));
}

void Java::Shutdown()
{
    if (Java::env != nullptr && classLoader != nullptr)
    {
        Java::env->DeleteGlobalRef(classLoader);
        classLoader = nullptr;
    }

    Java::DeleteGlobal(Java::class_String);
    Java::DeleteGlobal(Java::class_List);
    Java::DeleteGlobal(Java::class_Set);
    Java::DeleteGlobal(Java::class_Map);
    Java::DeleteGlobal(Java::class_FloatBuffer);
    Java::DeleteGlobal(Java::class_Class);
    Java::mid_List_toArray = nullptr;
    Java::mid_Set_toArray = nullptr;
    Java::mid_Class_getName = nullptr;
    Java::mid_FloatBuffer_get = nullptr;
    Java::mid_Map_entrySet = nullptr;

    if (vm != nullptr)
        vm->DetachCurrentThread();

    Java::env = nullptr;
    Java::tiEnv = nullptr;
    Java::initialized = false;
}

std::string Java::JStringToStd(jstring str)
{
    if (!env || !str)
        return {};

    const char* chars = env->GetStringUTFChars(str, nullptr);
    if (!chars)
    {
        ClearException();
        return {};
    }

    std::string result(chars);
    env->ReleaseStringUTFChars(str, chars);
    return result;
}

bool Java::AssignClass(std::string name, jclass &out)
{
    out = nullptr;
    ClearException();

    if (!env)
        return false;

    if (classLoader && mid_findClass)
    {
        jstring className = env->NewStringUTF(name.c_str());
        jobject findClass = env->CallObjectMethod(classLoader, mid_findClass, className);
        env->DeleteLocalRef(className);

        if (env->ExceptionCheck())
        {
            env->ExceptionClear();
            findClass = nullptr;
        }

        if (findClass)
        {
            out = (jclass)findClass;
            return true;
        }
    }

    out = env->FindClass(name.c_str());
    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
        out = nullptr;
    }

    return out != nullptr;
}

jclass Java::GetClass(std::string name)
{
    jclass out = nullptr;
    AssignClass(name, out);
    return out;
}

jclass Java::FindClass(JNIEnv* env, jvmtiEnv* tienv, const std::string& path)
{
    jint class_count = 0;
    jclass* classes = nullptr;
    jclass foundclass = nullptr;
    tienv->GetLoadedClasses(&class_count, &classes);
    for (int i = 0; i < class_count; ++i)
    {
        char* signature_buffer = nullptr;
        tienv->GetClassSignature(classes[i], &signature_buffer, nullptr);
        if (!signature_buffer)
        {
            env->DeleteLocalRef(classes[i]);
            continue;
        }
        std::string signature = signature_buffer;
        tienv->Deallocate((unsigned char*)signature_buffer);
        signature = signature.substr(1);
        signature.pop_back();
        if (signature == path)
        {
            foundclass = (jclass)env->NewLocalRef(classes[i]);
        }
        env->DeleteLocalRef(classes[i]);
    }
    tienv->Deallocate((unsigned char*)classes);
    return foundclass;
}

std::string Java::GetClazzName(jobject obj)
{
    if (!env || !obj)
        return {};

    jclass objClass = env->GetObjectClass(obj);
    if (!objClass)
    {
        ClearException();
        return {};
    }

    jmethodID getName = mid_Class_getName;
    if (!getName && class_Class)
        getName = env->GetMethodID(class_Class, "getName", "()Ljava/lang/String;");
    else if (!getName)
        getName = env->GetMethodID(env->GetObjectClass(objClass), "getName", "()Ljava/lang/String;");

    std::string result;
    if (getName)
    {
        jstring name = (jstring)env->CallObjectMethod(objClass, getName);
        if (env->ExceptionCheck())
        {
            env->ExceptionClear();
            name = nullptr;
        }
        result = JStringToStd(name);
        DeleteLocal(name);
    }

    DeleteLocal(objClass);
    return result;
}

static bool checkLunarClient()
{
    Java::ClearException();

    jclass minecraftClass = nullptr;
    if (!Java::AssignClass("net.minecraft.client.Minecraft", minecraftClass))
        return false;

    jmethodID getMinecraftMethod = Java::env->GetStaticMethodID(minecraftClass, "getMinecraft", "()Lnet/minecraft/client/Minecraft;");
    if (!getMinecraftMethod)
    {
        Java::ClearException();
        return false;
    }

    jobject theMinecraft = Java::env->CallStaticObjectMethod(minecraftClass, getMinecraftMethod);
    if (Java::env->ExceptionCheck() || !theMinecraft)
    {
        Java::ClearException();
        return false;
    }

    jfieldID launchedVersionField = Java::env->GetFieldID(minecraftClass, "launchedVersion", "Ljava/lang/String;");
    if (!launchedVersionField)
    {
        Java::ClearException();
        return false;
    }

    jobject launchedVersion = Java::env->GetObjectField(theMinecraft, launchedVersionField);
    if (!launchedVersion)
    {
        Java::ClearException();
        return false;
    }

    std::string version = String(launchedVersion).ToString();
    LOG_INFO("Lunar launchedVersion: %s", version.c_str());

    if (version.find("1.8.9") != std::string::npos)
    {
        Java::version = MinecraftVersion::LUNAR_1_8_9;
        return true;
    }
    if (version.find("1.7.10") != std::string::npos)
    {
        Java::version = MinecraftVersion::LUNAR_1_7_10;
        return true;
    }

    return false;
}

static bool CheckVanilla189()
{
    Java::ClearException();

    jclass minecraftClass = nullptr;
    if (!Java::AssignClass("ave", minecraftClass))
        return false;

    jmethodID getMinecraftMethod = Java::env->GetStaticMethodID(minecraftClass, "A", "()Lave;");
    if (!getMinecraftMethod)
    {
        Java::ClearException();
        return false;
    }

    jobject theMinecraft = Java::env->CallStaticObjectMethod(minecraftClass, getMinecraftMethod);
    if (Java::env->ExceptionCheck() || !theMinecraft)
    {
        Java::ClearException();
        return false;
    }

    jfieldID launchedVersionField = Java::env->GetFieldID(minecraftClass, "al", "Ljava/lang/String;");
    if (!launchedVersionField)
    {
        Java::ClearException();
        return false;
    }

    jobject launchedVersion = Java::env->GetObjectField(theMinecraft, launchedVersionField);
    if (!launchedVersion)
    {
        Java::ClearException();
        return false;
    }

    std::string version = String(launchedVersion).ToString();

    if (version.find("1.8.9") != std::string::npos)
    {
        Java::version = MinecraftVersion::VANILLA_1_8_9;
        return true;
    }

    return false;
}

static bool checkVanilla1710()
{
    Java::ClearException();

    jclass minecraftClass = nullptr;
    if (!Java::AssignClass("bao", minecraftClass))
        return false;

    jmethodID getMinecraftMethod = Java::env->GetStaticMethodID(minecraftClass, "B", "()Lbao;");
    if (!getMinecraftMethod)
    {
        Java::ClearException();
        return false;
    }

    jobject theMinecraft = Java::env->CallStaticObjectMethod(minecraftClass, getMinecraftMethod);
    if (Java::env->ExceptionCheck() || !theMinecraft)
    {
        Java::ClearException();
        return false;
    }

    jfieldID launchedVersionField = Java::env->GetFieldID(minecraftClass, "Z", "Ljava/lang/String;");
    if (!launchedVersionField)
    {
        Java::ClearException();
        return false;
    }

    jobject launchedVersion = Java::env->GetObjectField(theMinecraft, launchedVersionField);
    if (!launchedVersion)
    {
        Java::ClearException();
        return false;
    }

    std::string version = String(launchedVersion).ToString();

    if (version.find("1.7.10") != std::string::npos)
    {
        Java::version = MinecraftVersion::VANILLA_1_7_10;
        return true;
    }

    return false;
}

static bool checkForge189()
{
    Java::ClearException();

    jclass minecraftClass = nullptr;
    if (!Java::AssignClass("net.minecraft.client.Minecraft", minecraftClass))
        return false;

    jmethodID getMinecraftMethod = Java::env->GetStaticMethodID(minecraftClass, "func_71410_x", "()Lnet/minecraft/client/Minecraft;");
    if (!getMinecraftMethod)
    {
        Java::ClearException();
        return false;
    }

    jobject theMinecraft = Java::env->CallStaticObjectMethod(minecraftClass, getMinecraftMethod);
    if (Java::env->ExceptionCheck() || !theMinecraft)
    {
        Java::ClearException();
        return false;
    }

    jfieldID launchedVersionField = Java::env->GetFieldID(minecraftClass, "field_110447_Z", "Ljava/lang/String;");
    if (!launchedVersionField)
    {
        Java::ClearException();
        return false;
    }

    jobject launchedVersion = Java::env->GetObjectField(theMinecraft, launchedVersionField);
    if (!launchedVersion)
    {
        Java::ClearException();
        return false;
    }

    std::string version = String(launchedVersion).ToString();

    if (version.find("1.8.9") != std::string::npos)
    {
        Java::version = MinecraftVersion::FORGE_1_8_9;
        return true;
    }

    return false;
}

static bool checkForge1710()
{
    Java::ClearException();

    jclass minecraftClass = nullptr;
    if (!Java::AssignClass("net.minecraft.client.Minecraft", minecraftClass))
        return false;

    jmethodID getMinecraftMethod = Java::env->GetStaticMethodID(minecraftClass, "func_71410_x", "()Lnet/minecraft/client/Minecraft;");
    if (!getMinecraftMethod)
    {
        Java::ClearException();
        return false;
    }

    jobject theMinecraft = Java::env->CallStaticObjectMethod(minecraftClass, getMinecraftMethod);
    if (Java::env->ExceptionCheck() || !theMinecraft)
    {
        Java::ClearException();
        return false;
    }

    jfieldID launchedVersionField = Java::env->GetFieldID(minecraftClass, "field_110447_Z", "Ljava/lang/String;");
    if (!launchedVersionField)
    {
        Java::ClearException();
        return false;
    }

    jobject launchedVersion = Java::env->GetObjectField(theMinecraft, launchedVersionField);
    if (!launchedVersion)
    {
        Java::ClearException();
        return false;
    }

    std::string version = String(launchedVersion).ToString();
    LOG_INFO("Forge version: %s", version.c_str());

    if (version.find("1.7.10") != std::string::npos)
    {
        Java::version = MinecraftVersion::FORGE_1_7_10;
        return true;
    }

    return false;
}

void Java::GetMinecraftVersion()
{
    Java::version = MinecraftVersion::UNKNOWN;

    if (checkLunarClient()) return;
    if (CheckVanilla189()) return;
    if (checkForge189()) return;
    if (checkVanilla1710()) return;
    if (checkForge1710()) return;

    Java::version = MinecraftVersion::UNKNOWN;
    ClearException();
}

template<>
std::string Java::Convert<std::string>(jobject obj)
{
    return JStringToStd((jstring)obj);
}

template<>
int Java::Convert<int>(jobject obj)
{
    jclass cls = Java::env->GetObjectClass(obj);
    jmethodID mid = Java::env->GetMethodID(cls, "intValue", "()I");
    Java::env->DeleteLocalRef(cls);
    return Java::env->CallIntMethod(obj, mid);
}

template<>
float Java::Convert<float>(jobject obj)
{
    jclass cls = Java::env->GetObjectClass(obj);
    jmethodID mid = Java::env->GetMethodID(cls, "floatValue", "()F");
    Java::env->DeleteLocalRef(cls);
    return Java::env->CallFloatMethod(obj, mid);
}
