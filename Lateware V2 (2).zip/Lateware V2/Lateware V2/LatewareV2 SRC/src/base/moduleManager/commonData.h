#pragma once

#include <atomic>
#include <chrono>
#include <string>
#include <vector>

#include "util/math/geometry.h"
#include "util/logger.h"
#include "util/nativeLock.h"
#include "sdk/sdk.h"
#include "sdk/net/minecraft/util/AxisAlignedBB.h"
#include "java/java.h"

/*
This file is mainly for optimization purposes, instead of loading the data inside each module, we just load them here and then pass the data onto
the modules that will eventually use them.

The modules that write data will still need to access required java objects to do so.
*/
struct CommonData
{
	inline static NativeLock mutex;
	inline static std::atomic<bool> dataUpdated{ false };
	inline static Matrix modelView;
	inline static Matrix projection;
	inline static Vector3 renderPos;
	inline static float renderPartialTicks;
	inline static float fov;
	inline static int thirdPersonView;

	inline static int fps;
	inline static int ping;
	inline static std::string playerName;
	inline static Vector3 playerPos;
	inline static Vector3 playerLastPos;
	inline static Vector3 playerEyePos;
	inline static Vector2 playerAngles;
	inline static float playerYaw;
	inline static float playerPitch;

	struct PlayerData
	{
		CEntityPlayer obj = nullptr;
		Vector3 pos = Vector3();
		Vector3 lastPos = Vector3();
		BoundingBox boundingBox = BoundingBox();
		std::string name = "";
		float height = FLT_MAX;
		float width = FLT_MAX;
		float health = FLT_MAX;
		float maxHealth = FLT_MAX;
	};

	inline static std::vector<PlayerData> nativePlayerList;

	static std::string CopyPlayerName()
	{
		NativeGuard lock(mutex);
		return playerName;
	}

	static void ResetOutOfWorld()
	{
		NativeGuard lock(mutex);
		dataUpdated.store(false, std::memory_order_release);
		nativePlayerList.clear();
		fps = -1;
		ping = -1;
		playerName.clear();
		playerPos = Vector3();
		playerLastPos = Vector3();
		playerEyePos = Vector3();
		playerAngles = Vector2();
		playerYaw = 0.f;
		playerPitch = 0.f;
	}

	// True only when a live world + local player exist (not main menu / disconnect).
	static bool SanityCheck()
	{
		if (!Java::env || !SDK::minecraft || !SDK::minecraft->GetInstance()
			|| !SDK::minecraft->thePlayer || !SDK::minecraft->theWorld)
		{
			ResetOutOfWorld();
			return false;
		}

		jobject player = nullptr;
		jobject world = nullptr;
		try
		{
			player = SDK::minecraft->thePlayer->GetInstance();
			if (Java::env->ExceptionCheck() || !player)
			{
				Java::ClearException();
				Java::DeleteLocal(player);
				ResetOutOfWorld();
				return false;
			}
			world = SDK::minecraft->theWorld->GetInstance();
			if (Java::env->ExceptionCheck() || !world)
			{
				Java::ClearException();
				Java::DeleteLocal(player);
				Java::DeleteLocal(world);
				ResetOutOfWorld();
				return false;
			}
		}
		catch (...)
		{
			Java::DeleteLocal(player);
			Java::DeleteLocal(world);
			ResetOutOfWorld();
			return false;
		}

		Java::DeleteLocal(player);
		Java::DeleteLocal(world);
		return true;
	}

	static void UpdateData()
	{
		if (!SanityCheck()) return;

		try
		{
			Matrix newModelView = SDK::minecraft->activeRenderInfo->ModelViewMatrix();
			Matrix newProjection = SDK::minecraft->activeRenderInfo->ProjectionMatrix();
			const float newFov = SDK::minecraft->gameSettings->GetFOV();
			const int newThirdPerson = SDK::minecraft->gameSettings->GetThirdPersonView();

			// Camera origin for W2S: entityInterp - renderPos (no fake Y bias).
			// Prefer viewerPos on 1.8 when present (true camera in F5).
			Vector3 camera = SDK::minecraft->renderManager->RenderPos();
			if (Java::version == MinecraftVersion::LUNAR_1_8_9
				|| Java::version == MinecraftVersion::VANILLA_1_8_9
				|| Java::version == MinecraftVersion::FORGE_1_8_9)
			{
				Vector3 viewer = SDK::minecraft->renderManager->ViewerPos();
				if (!(viewer.x == 0.f && viewer.y == 0.f && viewer.z == 0.f))
					camera = viewer;
			}

			const float newPartialTicks = SDK::minecraft->timer->GetRenderPartialTicks();

			std::vector<PlayerData> newData;
			std::vector<CEntityPlayer> playerList = SDK::minecraft->theWorld->GetPlayerList();
			newData.reserve(playerList.size());
			for (CEntityPlayer& player : playerList)
			{
				if (!player.GetInstance())
					continue;

				CAxisAlignedBB bb = player.GetBB();
				BoundingBox nativeBb = bb.GetNativeBoundingBox();
				Java::DeleteLocal(bb.GetInstance());

				newData.push_back(PlayerData{
						player,
						player.GetPos(),
						player.GetLastTickPos(),
						nativeBb,
						player.GetName(),
						player.GetHeight(),
						player.GetWidth(),
						player.GetHealth(),
						player.GetMaxHealth(),
					});
			}

			const int newFps = SDK::minecraft->GetFps();
			const std::string newName = SDK::minecraft->thePlayer->GetName();
			const Vector3 newPos = SDK::minecraft->thePlayer->GetPos();
			const Vector3 newLastPos = SDK::minecraft->thePlayer->GetLastTickPos();
			const Vector3 newEyePos = SDK::minecraft->thePlayer->GetEyePos();
			const Vector2 newAngles = SDK::minecraft->thePlayer->GetAngles();

			static auto lastPingAt = std::chrono::steady_clock::now();
			static int cachedPing = -1;
			const auto now = std::chrono::steady_clock::now();
			if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastPingAt).count() >= 500
				|| cachedPing < 0)
			{
				cachedPing = SDK::minecraft->thePlayer->GetPing();
				lastPingAt = now;
			}

			{
				NativeGuard lock(mutex);
				modelView = newModelView;
				projection = newProjection;
				fov = newFov;
				thirdPersonView = newThirdPerson;
				renderPos = camera;
				renderPartialTicks = newPartialTicks;
				nativePlayerList = std::move(newData);
				fps = newFps;
				ping = cachedPing;
				playerName = newName;
				playerPos = newPos;
				playerLastPos = newLastPos;
				playerEyePos = newEyePos;
				playerAngles = newAngles;
				playerYaw = newAngles.x;
				playerPitch = newAngles.y;
				dataUpdated.store(true, std::memory_order_release);
			}
		}
		catch (...)
		{
			ResetOutOfWorld();
		}
	}
};
