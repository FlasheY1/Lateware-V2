#include "moduleManager.h"

#include "modules/combat/aimAssist.h"
#include "modules/combat/reach.h"
#include "modules/combat/antiEvade.h"
#include "modules/combat/autoEvade.h"
#include "modules/combat/autoBottle.h"
#include "modules/combat/autoFlashStab.h"
#include "modules/combat/leftAutoClicker.h"
#include "modules/combat/rightAutoClicker.h"
#include "modules/visual/esp.h"
#include "modules/visual/nvidiaEsp.h"
#include "modules/visual/radar.h"
#include "modules/visual/nametag.h"
#include "modules/visual/smokeBombEsp.h"
#include "modules/visual/blockEsp.h"
#include "modules/movement/bridgeAssist.h"
#include "modules/movement/velocity.h"
#include "modules/movement/sprintReset.h"
#include "modules/movement/sprint.h"
#include "modules/inventory/chestStealer.h"
#include "modules/inventory/inventorySorter.h"
#include "modules/utility/arrayList.h"
#include "modules/utility/clientBrandChanger.h"
#include "modules/utility/weapon.h"

#include "commonData.h"
#include "configManager/configManager.h"
#include "configManager/settings.h"
#include "java/javahook.h"
#include "sdk/strayCache.h"
#include "util/minecraft/inventory.h"
#include "util/keys.h"
#include "menu/menu.h"
#include "util/crash/crashHandler.h"
#include "util/logger.h"
#include "notificationManager/notificationManager.h"

#include <algorithm>
#include <cstdio>


void ModuleManager::Init()
{
	m_modules.push_back(std::make_unique<AntiEvade>());
	m_modules.push_back(std::make_unique<AutoEvade>());
	m_modules.push_back(std::make_unique<AutoBottle>());
	m_modules.push_back(std::make_unique<AutoFlashStab>());
	m_modules.push_back(std::make_unique<AimAssist>());
	m_modules.push_back(std::make_unique<Reach>());
	m_modules.push_back(std::make_unique<LeftAutoClicker>());
	m_modules.push_back(std::make_unique<RightAutoClicker>());
	m_modules.push_back(std::make_unique<Esp>());
	m_modules.push_back(std::make_unique<NvidiaEsp>());
	m_modules.push_back(std::make_unique<Radar>());
	m_modules.push_back(std::make_unique<Nametag>());
	m_modules.push_back(std::make_unique<SmokeBombEsp>());
	m_modules.push_back(std::make_unique<BridgeAssist>());
	m_modules.push_back(std::make_unique<Velocity>());
	m_modules.push_back(std::make_unique<SprintReset>());
	m_modules.push_back(std::make_unique<Sprint>());
	m_modules.push_back(std::make_unique<ChestStealer>());
	m_modules.push_back(std::make_unique<ArrayList>());
	m_modules.push_back(std::make_unique<ClientBrandChanger>());
	m_modules.push_back(std::make_unique<Weapon>());
	LOG_INFO("Modules initialized");

	// load friends
	configmanager::LoadFriends();
	LOG_INFO("Friends loaded");

	// load the first config
	std::vector<std::string> configList = configmanager::GetConfigList();
	if (!configList.empty())
	{
		if (configmanager::LoadConfig(0))
		{
			LOG_INFO("Config loaded: %s", configList[0].c_str());
		}
		else
		{
			LOG_WARNING("Failed to load the first config.");
		}
	}

	// init inventory system
	InventorySystem::Init();

	// HotSpot i2i hooks are installed lazily in UpdateModules.
	// Installing them on the title screen (RetransformClasses + live brand queries)
	// was crashing Lunar immediately after inject.
	LOG_INFO("Deferred HotSpot hooks until needed (in-world / CBC enabled)");
}

static void EnsureHotSpotHooks(bool /*inWorld*/)
{
	static bool s_brandHooked = false;

	try
	{
		// Only patch getClientModName when the user actually enables CBC.
		// NOTE: EntityLivingBase.swingItem HotSpot hook is intentionally NEVER
		// installed — it crashed Lunar on your own attacks (exit code 1).
		if (!s_brandHooked && settings::CBC_Enabled
			&& StrayCache::clientBrandRetriever_getClientModName != nullptr
			&& ClientBrandChanger::GetClientModName_callback != nullptr)
		{
			s_brandHooked = JavaHook::Hook(StrayCache::clientBrandRetriever_getClientModName, ClientBrandChanger::GetClientModName_callback);
			LOG_INFO(s_brandHooked ? "Hooked ClientBrandRetriever.getClientModName" : "Failed to hook ClientBrandRetriever.getClientModName");
		}
	}
	catch (const std::exception& e)
	{
		LOG_INFO("Error during deferred hook install: %s", e.what());
	}
}

static void ThunkUpdateData(void*)
{
	CommonData::UpdateData();
}

static void ThunkModuleUpdate(void* p)
{
	static_cast<ModuleBase*>(p)->Update();
}

static void ThunkModuleOverlay(void* p)
{
	static_cast<ModuleBase*>(p)->RenderOverlay();
}

static void ThunkModuleHud(void* p)
{
	static_cast<ModuleBase*>(p)->RenderHud();
}

static void ThunkAutoEvadeTick(void*)
{
	AutoEvade::TickDisabled();
}

static bool GuardModule(ModuleBase* module, CrashHandler::Fn fn, const char* phase, bool disableOnCrash)
{
	if (!module)
		return true;

	char area[96]{};
	std::snprintf(area, sizeof(area), "%s::%s", module->GetName().c_str(), phase);
	if (CrashHandler::Guard(fn, module, area))
	{
		// JNI env belongs to the update thread — skip checks on overlay/HUD.
		if (disableOnCrash)
			CrashHandler::CheckJni(area);
		return true;
	}

	if (disableOnCrash)
	{
		LOG_ERROR("%s crashed — module disabled. Report: %s", area, CrashHandler::LastReportPath());
		NotificationError("%s crashed and was disabled. See Documents\\Lateware V2\\crashes", area);
		module->SetEnabled(false);
	}
	else
	{
		LOG_ERROR("%s crashed (skipped this frame). Report: %s", area, CrashHandler::LastReportPath());
	}
	return false;
}

void ModuleManager::UpdateModules()
{
	// Every SDK call on the attached cheat thread allocates JNI local refs
	// that are never reclaimed until the thread detaches. Anti/Auto Evade
	// (and CommonData) scan the player list every ~5ms, so without a frame
	// the local-ref table overflows - most noticeable when holding a sword
	// on ladders (the AutoEvade weapon gate keeps the full scan running).
	if (!Java::env || !SDK::minecraft)
		return;

	JavaHook::JNIFrame frame(Java::env, 4096);
	if (!frame)
		return;

	CRASH_SCOPE("UpdateModules");

	if (!CrashHandler::Guard(&ThunkUpdateData, nullptr, "CommonData::UpdateData"))
	{
		LOG_ERROR("CommonData::UpdateData crashed. Report: %s", CrashHandler::LastReportPath());
		NotificationError("World snapshot crashed. See Documents\\Lateware V2\\crashes");
		return;
	}
	CrashHandler::CheckJni("CommonData::UpdateData");

	const bool inWorld = CommonData::SanityCheck();

	EnsureHotSpotHooks(inWorld);

	// Leaving a world (disconnect / main menu): release held evade block once.
	static bool s_wasInWorld = false;
	if (!inWorld && s_wasInWorld)
		AutoEvade::ReleaseBlock();
	s_wasInWorld = inWorld;

	for (auto& module : m_modules)
	{
		// Keybinds still work on the main menu (toggle modules / open binds).
		if (module->GetKey() != 0 && Keys::IsKeyPressedOnce(module->GetKey()) && !Menu::open)
		{
			module->Toggle();
		}

		// Skip world-dependent modules on the title screen / disconnect.
		if (!inWorld)
			continue;

		if (module->IsEnabled())
			GuardModule(module.get(), &ThunkModuleUpdate, "Update", true);
	}

	// Auto Evade: menu toggle flips the bool without SetEnabled, and disabled
	// modules skip Update — still force-release a stuck block / use-key.
	if (inWorld)
		CrashHandler::Guard(&ThunkAutoEvadeTick, nullptr, "AutoEvade::TickDisabled");
}

void ModuleManager::RenderOverlay()
{
	for (auto& module : m_modules)
	{
		// Always tick NVIDIA ESP so it can clear the overlay when disabled
		// via menu toggle (bool flip, not SetEnabled).
		if (module->IsEnabled() || module->AlwaysRenderOverlay())
			GuardModule(module.get(), &ThunkModuleOverlay, "RenderOverlay", false);
	}
}

void ModuleManager::RenderHud()
{
	for (auto& module : m_modules)
	{
		if (module->IsEnabled())
			GuardModule(module.get(), &ThunkModuleHud, "RenderHud", false);
	}

	// Render Keybinds Window
	if (settings::Hud_ShowKeybinds)
	{
		ImGuiWindowFlags windowFlags;
		if (!Menu::openHudEditor)
		{
			windowFlags = ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoMouseInputs;
		}
		else
		{
			windowFlags = 0;
		}

		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 10));

		std::call_once(*Menu::setupKeybindsFlag, [&]() {
			ImGui::SetNextWindowPos(ImVec2(settings::Hud_KeybindsPosition[0], settings::Hud_KeybindsPosition[1]));
			});

		if (ImGui::Begin("Keybinds", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize | windowFlags))
		{
			settings::Hud_KeybindsPosition[0] = ImGui::GetWindowPos().x;
			settings::Hud_KeybindsPosition[1] = ImGui::GetWindowPos().y;

			Menu::BoldText("Keybinds", FontSize::SIZE_18);
			Menu::HorizontalSeparator("KeybindsSeparator");

			for (auto& module : m_modules)
			{
				int key = module->GetKey();
				if (key != 0)
				{
					Menu::Text((module->GetName() + " : " + Keys::GetKeyName(key)).c_str(), FontSize::SIZE_16);
				}
			}
		}
		ImGui::End();

		ImGui::PopStyleVar();
	}
}

void ModuleManager::RenderMenu(int index)
{
	if (index < 0)
		return;

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 15);

	std::vector<std::string> categories = GetCategories();
	for (auto& module : m_modules)
	{
		if (module->GetCategory() == categories[index])
		{
			module->RenderMenu();
		}
	}
}

std::vector<std::string> ModuleManager::GetCategories()
{
	static std::vector<std::string> categories;
	if (categories.empty())
	{
		for (auto& module : m_modules)
		{
			if (std::find(categories.begin(), categories.end(), module->GetCategory()) == categories.end())
				categories.push_back(module->GetCategory());
		}
	}
	return categories;
}

int ModuleManager::GetFirstModuleIndexByCategory(const std::string& category)
{
	for (int i = 0; i < m_modules.size(); i++)
	{
		if (m_modules[i]->GetCategory() == category)
		{
			return i;
		}
	}

	return -1;
}
