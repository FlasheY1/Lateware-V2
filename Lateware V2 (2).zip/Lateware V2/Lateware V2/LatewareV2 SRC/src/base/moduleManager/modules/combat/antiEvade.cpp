#include "antiEvade.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <utility>

#include "configManager/configManager.h"
#include "java/java.h"
#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "util/math/math.h"

AntiEvade::AntiEvade()
{
	s_instance = this;
}

static long long AntiEvadeNowMillis()
{
	return std::chrono::duration_cast<std::chrono::milliseconds>(
		std::chrono::steady_clock::now().time_since_epoch()).count();
}

bool AntiEvade::ShouldPauseClicker()
{
	return s_instance && settings::AE_Enabled && s_instance->m_shouldPause;
}

bool AntiEvade::IsLeatherPiece(CItemStack& stack, int expectedId)
{
	if (!stack.GetInstance())
		return false;

	CItem item = stack.GetItem();
	if (!item.GetInstance())
		return false;

	// ID check only — unlocalized-name string work was a major stutter source.
	return item.GetID() == expectedId;
}

bool AntiEvade::IsWearingFullLeather(CEntityPlayer& entity)
{
	if (!entity.GetInstance())
		return false;

	CInventoryPlayer inventory = entity.GetInventory();
	if (!inventory.GetInstance())
		return false;

	std::vector<CItemStack> armor = inventory.GetArmorInventory();
	if (armor.size() < 4)
		return false;

	return IsLeatherPiece(armor[3], LEATHER_HELMET_ID)
		&& IsLeatherPiece(armor[2], LEATHER_CHESTPLATE_ID)
		&& IsLeatherPiece(armor[1], LEATHER_LEGGINGS_ID)
		&& IsLeatherPiece(armor[0], LEATHER_BOOTS_ID);
}

bool AntiEvade::GetCachedFullLeather(const std::string& name, CEntityPlayer& entity, long long now)
{
	auto it = m_leatherCache.find(name);
	if (it != m_leatherCache.end() && (now - it->second.checkedAt) < LEATHER_CACHE_MS)
		return it->second.fullLeather;

	const bool full = IsWearingFullLeather(entity);
	m_leatherCache[name] = LeatherCacheEntry{ full, now };
	return full;
}

bool AntiEvade::IsFacingPlayer(const Vector3& targetPos, float targetHeight, const Vector3& eyePos, const Vector2& lookAngles)
{
	Vector3 center = targetPos + Vector3(0.f, targetHeight * 0.5f, 0.f);
	Vector2 toTarget = Math::GetAngles(eyePos, center);
	Vector2 difference = Math::WrapAngleTo180(lookAngles.Invert() - toTarget.Invert());

	if (difference.x < 0) difference.x = -difference.x;
	if (difference.y < 0) difference.y = -difference.y;

	return difference.x <= settings::AE_Fov && difference.y <= settings::AE_Fov;
}

void AntiEvade::Update()
{
	m_shouldPause = false;
	m_blockingNearby = 0;
	m_expiredBlockers = 0;
	m_candidatesChecked = 0;

	if (!settings::AE_Enabled)
	{
		m_blockStart.clear();
		m_leatherCache.clear();
		return;
	}

	if (!CommonData::SanityCheck())
	{
		m_blockStart.clear();
		return;
	}

	const long long now = AntiEvadeNowMillis();
	const Vector3 localPos = CommonData::playerPos;
	const Vector3 eyePos = CommonData::playerEyePos;
	const Vector2 lookAngles = CommonData::playerAngles;
	const float rangeSq = settings::AE_Range * settings::AE_Range;

	std::unordered_map<std::string, long long> stillBlocking;
	stillBlocking.reserve(m_blockStart.size() + 4);

	// Use the once-per-tick CommonData list — do NOT re-fetch the world player list.
	for (CommonData::PlayerData& player : CommonData::nativePlayerList)
	{
		if (!player.obj.GetInstance())
			continue;

		if (!CommonData::playerName.empty() && player.name == CommonData::playerName)
			continue;

		const float dx = player.pos.x - localPos.x;
		const float dy = player.pos.y - localPos.y;
		const float dz = player.pos.z - localPos.z;
		if ((dx * dx + dy * dy + dz * dz) > rangeSq)
			continue;

		if (settings::AE_IgnoreFriends && configmanager::IsFriend(player.name))
			continue;

		++m_candidatesChecked;

		// Cheap JNI first: blocking is a single boolean field/method.
		if (!player.obj.IsBlocking())
			continue;

		if (!GetCachedFullLeather(player.name, player.obj, now))
			continue;

		const auto it = m_blockStart.find(player.name);
		const long long start = (it != m_blockStart.end()) ? it->second : now;
		stillBlocking[player.name] = start;
		++m_blockingNearby;

		if (now - start >= settings::AE_MaxBlockPause)
		{
			++m_expiredBlockers;
			continue;
		}

		if (!IsFacingPlayer(player.pos, player.height, eyePos, lookAngles))
			continue;

		m_shouldPause = true;
		// Keep scanning so every active blocker still advances their timer,
		// but facing+pause only needs one match for the clicker.
	}

	m_blockStart = std::move(stillBlocking);

	// Drop leather cache entries for players no longer nearby/blocking to bound memory.
	if (m_leatherCache.size() > 64)
	{
		for (auto it = m_leatherCache.begin(); it != m_leatherCache.end(); )
		{
			if (now - it->second.checkedAt > LEATHER_CACHE_MS * 4)
				it = m_leatherCache.erase(it);
			else
				++it;
		}
	}
}

void AntiEvade::RenderMenu()
{
	Menu::BoldText("Anti Evade", FontSize::SIZE_22);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.f);

	Menu::ToggleWithKeybind(&settings::AE_Enabled, settings::AE_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AE_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Text("", FontSize::SIZE_14);
	Menu::Text("", FontSize::SIZE_14);
	Menu::Text("", FontSize::SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AE_Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Range", &settings::AE_Range, 1.0f, 8.0f);
	Menu::Slider("FOV", &settings::AE_Fov, 5.0f, 90.0f);
	Menu::Slider("Max Pause (ms)", &settings::AE_MaxBlockPause, 500, 3000);
	Menu::Checkbox("Ignore Friends", &settings::AE_IgnoreFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AE_Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	const bool mappingOk = StrayCache::entityLivingBase_isBlocking != nullptr
		|| StrayCache::entityPlayer_isBlocking != nullptr;

	Menu::TextColored(
		mappingOk ? "Blocking detection: OK" : "Blocking detection: MISSING",
		mappingOk ? ImVec4(0.3f, 1.f, 0.3f, 1.f) : ImVec4(1.f, 0.3f, 0.3f, 1.f),
		FontSize::SIZE_16);

	char status[160];
	std::snprintf(status, sizeof(status),
		"Paused: %s | Nearby checked: %d | Leather blockers: %d | Expired: %d",
		m_shouldPause ? "YES" : "no", m_candidatesChecked, m_blockingNearby, m_expiredBlockers);
	Menu::Text(status, FontSize::SIZE_14);
}
