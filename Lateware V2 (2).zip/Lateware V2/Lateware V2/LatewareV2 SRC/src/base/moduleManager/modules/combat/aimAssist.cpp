#include "aimAssist.h"

#include <cmath>
#include <limits>
#include <numbers>
#include <vector>

#include "moduleManager/commonData.h"
#include "util/math/math.h"
#include "util/minecraft/minecraft.h"
#include "menu/menu.h"
#include "sdk/sdk.h"
#include "java/java.h"
#include "configManager/configManager.h"

namespace
{
	int RandomInteger(int min, int max)
	{
		if (min > max) std::swap(min, max);
		return min + (std::rand() % (max - min + 1));
	}

	float RandomFloat(float min, float max)
	{
		float f = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX);
		return min + f * (max - min);
	}

	float WrapTo180(float value)
	{
		if (value >= 180.f) value -= 360.f;
		if (value < -180.f) value += 360.f;
		return value;
	}

	double Dist3(const Vector3& a, const Vector3& b)
	{
		const double dx = a.x - b.x;
		const double dy = a.y - b.y;
		const double dz = a.z - b.z;
		return std::sqrt(dx * dx + dy * dy + dz * dz);
	}
}

void AimAssist::Update()
{
	if (!settings::AA_Enabled) return;
	if (Menu::open) return;
	if (!CommonData::SanityCheck()) return;
	if (SDK::minecraft->IsInGuiState()) return;

	if (settings::AA_clickingOnly && !(GetAsyncKeyState(VK_LBUTTON) & 0x8000))
		return;

	if (settings::AA_weaponOnly && !MinecraftUtils::IsWeapon(SDK::minecraft->thePlayer->GetInventory().GetCurrentItem()))
		return;

	if (!settings::AA_throughWalls && SDK::minecraft->GetMouseOver().IsTypeOfBlock())
		return;

	const Vector3 thePlayerPos = CommonData::playerPos;

	if (GetTickCount64() - m_targetUpdate > 100)
	{
		double bestDist = (std::numeric_limits<double>::max)();
		m_targetName.clear();

		for (CommonData::PlayerData& pl : CommonData::nativePlayerList)
		{
			if (Java::env->IsSameObject(SDK::minecraft->thePlayer->GetInstance(), pl.obj.GetInstance()))
				continue;
			if (settings::AA_ignoreFriends && configmanager::IsFriend(pl.name))
				continue;

			const double dist = Dist3(thePlayerPos, pl.pos);
			if (dist <= bestDist)
			{
				bestDist = dist;
				m_targetName = pl.name;
			}
		}

		m_targetUpdate = GetTickCount64();
	}

	const CommonData::PlayerData* target = nullptr;
	for (const CommonData::PlayerData& pl : CommonData::nativePlayerList)
	{
		if (pl.name == m_targetName)
		{
			target = &pl;
			break;
		}
	}

	if (!target)
		return;

	if (target->health <= 0.f)
		return;

	const Vector3 targetPos = target->pos;
	const double targetDistance = Dist3(targetPos, thePlayerPos);
	if (targetDistance > settings::AA_aimDistance)
		return;

	const float yaw = SDK::minecraft->thePlayer->GetRotationYaw();
	const float pitch = SDK::minecraft->thePlayer->GetRotationPitch();

	double distanceX = targetPos.x - thePlayerPos.x;
	double distanceZ = targetPos.z - thePlayerPos.z;

	if (settings::AA_mode == 1)
	{
		const Vector3 corners[4] = {
			{ targetPos.x - 0.30f, targetPos.y, targetPos.z + 0.30f },
			{ targetPos.x - 0.30f, targetPos.y, targetPos.z - 0.30f },
			{ targetPos.x + 0.30f, targetPos.y, targetPos.z - 0.30f },
			{ targetPos.x + 0.30f, targetPos.y, targetPos.z + 0.30f },
		};

		double best = Dist3(corners[0], thePlayerPos);
		Vector3 closest = corners[0];
		for (int i = 1; i < 4; i++)
		{
			const double d = Dist3(corners[i], thePlayerPos);
			if (d < best)
			{
				best = d;
				closest = corners[i];
			}
		}

		distanceX = closest.x - thePlayerPos.x;
		distanceZ = closest.z - thePlayerPos.z;
	}

	float fov = std::atan2(static_cast<float>(distanceZ), static_cast<float>(distanceX)) * 180.f / std::numbers::pi_v<float> - 90.f;
	fov = WrapTo180(std::fmod(fov - yaw, 360.f));

	if (static_cast<int>(std::fabs(fov)) <= static_cast<int>(settings::AA_fov) && std::fabs(fov) > 2.f)
	{
		const float speed = settings::AA_speed + RandomFloat(-1.f, 0.25f);
		fov *= RandomFloat(0.25f, 0.65f) * (speed + RandomFloat(1.f, 5.f));

		if (std::fabs(fov) <= 5.f && RandomInteger(1, 8) <= 2)
			fov *= -1.f;

		// Preserve Dope's inverted min/max quirk.
		const float rndAdd = RandomFloat(0.005f, 0.001f);
		const float newYaw = SDK::minecraft->thePlayer->GetRotationYaw() + fov * rndAdd;
		const float newPrevYaw = SDK::minecraft->thePlayer->GetPrevRotationYaw() + fov * rndAdd;

		SDK::minecraft->thePlayer->SetAngles(Vector2(newYaw, pitch));
		SDK::minecraft->thePlayer->SetPrevAngles(Vector2(newPrevYaw, SDK::minecraft->thePlayer->GetPrevRotationPitch()));

		if (settings::AA_pitchRand)
		{
			if (m_lastPitch == pitch && RandomInteger(1, 10) == 1 && std::fabs(pitch) < 80.f)
			{
				const float newRand = RandomFloat(-0.075f, 0.075f);
				SDK::minecraft->thePlayer->SetAngles(Vector2(newYaw, pitch + newRand));
				SDK::minecraft->thePlayer->SetPrevAngles(Vector2(
					newPrevYaw,
					SDK::minecraft->thePlayer->GetPrevRotationPitch() + newRand));
			}
			m_lastPitch = SDK::minecraft->thePlayer->GetRotationPitch();
		}
	}
}

void AimAssist::RenderOverlay()
{
	if (!settings::AA_Enabled || !CommonData::dataUpdated) return;
	if (!settings::AA_fovCircle) return;

	const ImVec2 screenSize = ImGui::GetWindowSize();
	const float radAimbotFov = settings::AA_fov * static_cast<float>(PI) / 180.f;
	const float radViewFov = CommonData::fov * static_cast<float>(PI) / 180.f;
	const float circleRadius = std::tanf(radAimbotFov / 2.f) / std::tanf(radViewFov / 2.f) * screenSize.x / 1.7325f;

	ImGui::GetWindowDrawList()->AddCircle(
		ImVec2(screenSize.x / 2.f, screenSize.y / 2.f),
		circleRadius,
		ImColor(settings::AA_fovCircleColor[0], settings::AA_fovCircleColor[1], settings::AA_fovCircleColor[2], settings::AA_fovCircleColor[3]),
		static_cast<int>(circleRadius / 3.f),
		1.f);
}

void AimAssist::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::AA_Enabled, settings::AA_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AA_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Range", &settings::AA_aimDistance, 1.0f, 10.0f);
	Menu::Slider("Field of View", &settings::AA_fov, 20.0f, 180.f);
	Menu::Slider("Horizontal Speed", &settings::AA_speed, 1.0f, 10.0f);
	Menu::Dropdown("Mode", settings::AA_modeList, &settings::AA_mode, 2);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AA_Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Weapon Only", &settings::AA_weaponOnly);
	Menu::Checkbox("Through Walls", &settings::AA_throughWalls);
	Menu::Checkbox("Only While Clicking", &settings::AA_clickingOnly);
	Menu::Checkbox("Pitch Randomization", &settings::AA_pitchRand);
	Menu::Checkbox("Ignore Friends", &settings::AA_ignoreFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AA_Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("FOV Circle", &settings::AA_fovCircle);
	if (settings::AA_fovCircle)
		Menu::ColorEdit("FOV Circle Color", settings::AA_fovCircleColor);
}
