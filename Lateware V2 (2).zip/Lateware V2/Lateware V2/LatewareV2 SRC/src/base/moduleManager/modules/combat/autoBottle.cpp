#include "autoBottle.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <string>
#include <vector>

#include <Windows.h>

#include "autoEvade.h"
#include "java/java.h"
#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "sdk/net/minecraft/item/ItemStack.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"

namespace
{
	long long NowMs()
	{
		return std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::steady_clock::now().time_since_epoch()).count();
	}

	std::string StripColorCodes(const std::string& in)
	{
		std::string out;
		out.reserve(in.size());
		for (size_t i = 0; i < in.size(); ++i)
		{
			if ((unsigned char)in[i] == 0xC2 && i + 1 < in.size() && (unsigned char)in[i + 1] == 0xA7)
			{
				i += 2;
				continue;
			}
			if ((unsigned char)in[i] == 0xA7)
			{
				i += 1;
				continue;
			}
			out += in[i];
		}
		return out;
	}

	std::string ToLower(std::string s)
	{
		std::transform(s.begin(), s.end(), s.begin(),
			[](unsigned char c) { return (char)std::tolower(c); });
		return s;
	}

	bool ChatOk()
	{
		return StrayCache::minecraft_ingameGUI
			&& StrayCache::guiIngame_getChatGUI
			&& StrayCache::guiNewChat_chatLines
			&& StrayCache::chatLine_getChatComponent
			&& StrayCache::iChatComponent_getUnformattedText;
	}

	std::string ExtractChatLineText(JNIEnv* env, jobject line)
	{
		jobject component = env->CallObjectMethod(line, StrayCache::chatLine_getChatComponent);
		env->DeleteLocalRef(line);
		if (env->ExceptionCheck() || !component)
		{
			Java::ClearException();
			if (component) env->DeleteLocalRef(component);
			return {};
		}

		jstring text = (jstring)env->CallObjectMethod(component, StrayCache::iChatComponent_getUnformattedText);
		env->DeleteLocalRef(component);
		if (env->ExceptionCheck() || !text)
		{
			Java::ClearException();
			if (text) env->DeleteLocalRef(text);
			return {};
		}

		std::string result;
		const char* chars = env->GetStringUTFChars(text, nullptr);
		if (chars)
		{
			result = chars;
			env->ReleaseStringUTFChars(text, chars);
		}
		env->DeleteLocalRef(text);
		return result;
	}

	std::vector<std::string> GetChatLines(int maxCount)
	{
		JNIEnv* env = Java::env;
		if (!env || !SDK::minecraft || !ChatOk())
			return {};

		jobject mc = SDK::minecraft->GetInstance();
		if (!mc)
			return {};

		static jmethodID listSize = nullptr;
		static jmethodID listGet = nullptr;
		if (!listSize || !listGet)
		{
			jclass listClass = env->FindClass("java/util/List");
			if (!listClass)
			{
				Java::ClearException();
				return {};
			}
			listSize = env->GetMethodID(listClass, "size", "()I");
			listGet = env->GetMethodID(listClass, "get", "(I)Ljava/lang/Object;");
			env->DeleteLocalRef(listClass);
			if (!listSize || !listGet)
			{
				Java::ClearException();
				return {};
			}
		}

		jobject ingameGui = env->GetObjectField(mc, StrayCache::minecraft_ingameGUI);
		if (env->ExceptionCheck() || !ingameGui)
		{
			Java::ClearException();
			if (ingameGui) env->DeleteLocalRef(ingameGui);
			return {};
		}

		jobject chatGui = env->CallObjectMethod(ingameGui, StrayCache::guiIngame_getChatGUI);
		env->DeleteLocalRef(ingameGui);
		if (env->ExceptionCheck() || !chatGui)
		{
			Java::ClearException();
			if (chatGui) env->DeleteLocalRef(chatGui);
			return {};
		}

		jobject lines = env->GetObjectField(chatGui, StrayCache::guiNewChat_chatLines);
		env->DeleteLocalRef(chatGui);
		if (env->ExceptionCheck() || !lines)
		{
			Java::ClearException();
			if (lines) env->DeleteLocalRef(lines);
			return {};
		}

		const jint size = env->CallIntMethod(lines, listSize);
		if (env->ExceptionCheck() || size <= 0)
		{
			Java::ClearException();
			env->DeleteLocalRef(lines);
			return {};
		}

		std::vector<std::string> result;
		const int count = size < maxCount ? (int)size : maxCount;
		result.reserve(count);
		for (int i = 0; i < count; ++i)
		{
			jobject line = env->CallObjectMethod(lines, listGet, i);
			if (env->ExceptionCheck() || !line)
			{
				Java::ClearException();
				if (line) env->DeleteLocalRef(line);
				break;
			}
			result.push_back(ExtractChatLineText(env, line));
		}
		env->DeleteLocalRef(lines);
		return result;
	}
}

bool AutoBottle::IsWaterBottle(CItemStack& stack)
{
	if (!stack.GetInstance())
		return false;

	CItem item = stack.GetItem();
	if (!item.GetInstance())
		return false;

	const int id = item.GetID();
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}

	// 1.8 drinkable water bottle = potion item, damage/metadata 0
	if (id != ITEM_POTION)
		return false;

	const int meta = stack.GetMetadata();
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}
	return meta == 0;
}

int AutoBottle::FindWaterBottleSlot()
{
	CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
	if (!inv.GetInstance())
		return -1;

	std::vector<CItemStack> main = inv.GetMainInventory();
	const int n = (int)main.size() < 9 ? (int)main.size() : 9;
	for (int i = 0; i < n; ++i)
	{
		if (IsWaterBottle(main[i]))
			return i;
	}
	return -1;
}

bool AutoBottle::PollSilenceFromChat()
{
	if (!settings::AB_Silence || !ChatOk())
		return m_silenceUntil > NowMs();

	std::vector<std::string> lines = GetChatLines(4);
	if (lines.empty() || lines[0].empty())
		return m_silenceUntil > NowMs();

	if (!m_chatPrimed)
	{
		m_chatPrimed = true;
		m_lastChatLine = lines[0];
		return m_silenceUntil > NowMs();
	}

	if (lines[0] != m_lastChatLine)
	{
		size_t newCount = 0;
		while (newCount < lines.size() && lines[newCount] != m_lastChatLine)
			++newCount;
		m_lastChatLine = lines[0];

		for (size_t i = 0; i < newCount; ++i)
		{
			const std::string clean = ToLower(StripColorCodes(lines[i]));
			// "{player} hit you with silencing arrow" / "... silencing arrow 2"
			if (clean.find("hit you with silencing arrow") != std::string::npos)
			{
				m_silenceUntil = NowMs() + SILENCE_ACTIVE_MS;
				break;
			}
		}
	}

	return m_silenceUntil > NowMs();
}

void AutoBottle::RefreshVoidMode()
{
	m_voidMode = false;

	if (!settings::AB_AntiVoidMage)
		return;
	if (!SDK::minecraft || !SDK::minecraft->thePlayer || !SDK::minecraft->thePlayer->GetInstance())
		return;
	if (!StrayCache::entityLivingBase_isPotionActive || !Java::env)
		return;

	// Void mode = Slowness + Invisibility both active (Mineplex Void uses III + II).
	// Use isPotionActive only — amplifier / Potion.potionTypes JNI was crashing,
	// and this must never run from the menu/render thread.
	try
	{
		if (!SDK::minecraft->thePlayer->IsPotionActive(POTION_SLOWNESS))
			return;
		if (!SDK::minecraft->thePlayer->IsPotionActive(POTION_INVISIBILITY))
			return;
		m_voidMode = true;
	}
	catch (...)
	{
		m_voidMode = false;
	}
}

bool AutoBottle::NeedsBottle()
{
	if (!SDK::minecraft->thePlayer || !SDK::minecraft->thePlayer->GetInstance())
		return false;

	// Never bottle while in Void Mage void-mode (would cancel invis / waste bottle)
	if (m_voidMode)
		return false;

	const bool silenced = PollSilenceFromChat();

	if (settings::AB_Poison && SDK::minecraft->thePlayer->IsPotionActive(POTION_POISON))
		return true;
	if (settings::AB_Slow && SDK::minecraft->thePlayer->IsPotionActive(POTION_SLOWNESS))
		return true;
	if (settings::AB_Blind && SDK::minecraft->thePlayer->IsPotionActive(POTION_BLINDNESS))
		return true;
	if (settings::AB_Wither && SDK::minecraft->thePlayer->IsPotionActive(POTION_WITHER))
		return true;
	if (silenced)
		return true;

	return false;
}

void AutoBottle::StartUse(int slot)
{
	CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
	m_prevSlot = inv.GetCurrentItemIndex();
	m_bottleSlot = slot;
	if (slot != m_prevSlot)
		inv.SetCurrentItemIndex(slot);

	m_phase = Phase::Press;
}

void AutoBottle::TickUse()
{
	const long long now = NowMs();
	POINT cursor{};
	GetCursorPos(&cursor);

	switch (m_phase)
	{
	case Phase::Press:
		SendMessage(Menu::handleWindow, WM_RBUTTONDOWN, MK_RBUTTON, MAKELPARAM(cursor.x, cursor.y));
		m_holdUntil = now + HOLD_MS;
		m_phase = Phase::Hold;
		break;

	case Phase::Hold:
		if (now >= m_holdUntil)
			m_phase = Phase::Release;
		break;

	case Phase::Release:
		SendMessage(Menu::handleWindow, WM_RBUTTONUP, 0, MAKELPARAM(cursor.x, cursor.y));
		if (SDK::minecraft->thePlayer && SDK::minecraft->thePlayer->GetInstance())
		{
			CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
			if (inv.GetInstance() && m_prevSlot >= 0 && m_prevSlot < 9)
				inv.SetCurrentItemIndex(m_prevSlot);
		}
		m_cooldownUntil = now + settings::AB_Cooldown;
		m_phase = Phase::Idle;
		m_bottleSlot = -1;
		break;

	default:
		m_phase = Phase::Idle;
		break;
	}
}

void AutoBottle::Update()
{
	if (!settings::AB_Enabled)
	{
		if (m_phase != Phase::Idle)
		{
			// Abort mid-use cleanly
			POINT cursor{};
			GetCursorPos(&cursor);
			SendMessage(Menu::handleWindow, WM_RBUTTONUP, 0, MAKELPARAM(cursor.x, cursor.y));
			m_phase = Phase::Idle;
		}
		m_chatPrimed = false;
		m_voidMode = false;
		return;
	}

	if (!CommonData::SanityCheck() || !SDK::minecraft || !SDK::minecraft->thePlayer)
	{
		m_voidMode = false;
		return;
	}

	// Always refresh on the cheat thread (never from RenderMenu / GL thread).
	RefreshVoidMode();

	if (Menu::open || SDK::minecraft->IsInGuiState())
		return;

	// Don't fight Auto Evade's right-click hold
	if (AutoEvade::ShouldPauseClicker())
		return;

	if (m_phase != Phase::Idle)
	{
		TickUse();
		return;
	}

	const long long now = NowMs();
	if (now < m_cooldownUntil)
	{
		if (settings::AB_Silence)
			PollSilenceFromChat();
		return;
	}

	if (!NeedsBottle())
		return;

	const int slot = FindWaterBottleSlot();
	if (slot < 0)
		return;

	StartUse(slot);
}

void AutoBottle::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::AB_Enabled, settings::AB_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AB_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Text("Uses a hotbar water bottle when a selected debuff is active.", FontSize::SIZE_14);
	Menu::Text("Bottles share a cooldown after each use (default 5s).", FontSize::SIZE_14);
	Menu::Text("Silence: chat \"hit you with silencing arrow\".", FontSize::SIZE_14);
	Menu::Text("Anti-Void Mage skips bottling while Slow + Invisibility are active.", FontSize::SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AB_Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Poison", &settings::AB_Poison);
	Menu::Checkbox("Slow", &settings::AB_Slow);
	Menu::Checkbox("Blind", &settings::AB_Blind);
	Menu::Checkbox("Withered", &settings::AB_Wither);
	Menu::Checkbox("Silenced", &settings::AB_Silence);
	Menu::Checkbox("Anti-Void Mage", &settings::AB_AntiVoidMage);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AB_Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Cooldown (ms)", &settings::AB_Cooldown, 1000, 10000);

	const long long now = NowMs();
	const int cdLeft = m_cooldownUntil > now ? (int)(m_cooldownUntil - now) : 0;
	const bool silenced = m_silenceUntil > now;
	// Read cached flag only — never call JNI from the menu/render thread.
	char status[192];
	std::snprintf(status, sizeof(status), "Cooldown: %dms | Silence: %s | VoidMode: %s | Phase: %s",
		cdLeft,
		silenced ? "active" : "no",
		m_voidMode ? "YES (skip bottle)" : "no",
		m_phase == Phase::Idle ? "idle" : "using");
	Menu::Text(status, FontSize::SIZE_14);

	const bool potionOk = StrayCache::entityLivingBase_isPotionActive != nullptr;
	Menu::TextColored(
		potionOk ? "Potion detection: OK" : "Potion detection: MISSING",
		potionOk ? ImVec4(0.3f, 1.f, 0.3f, 1.f) : ImVec4(1.f, 0.3f, 0.3f, 1.f),
		FontSize::SIZE_14);
}
