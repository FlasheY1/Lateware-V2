#include "autoEvade.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include <Windows.h>

#include "configManager/configManager.h"
#include "java/java.h"
#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "util/math/math.h"
#include "util/minecraft/minecraft.h"

AutoEvade::AutoEvade()
{
	s_instance = this;
}

static long long NowMillis()
{
	return std::chrono::duration_cast<std::chrono::milliseconds>(
		std::chrono::system_clock::now().time_since_epoch()).count();
}

bool AutoEvade::ShouldPauseClicker()
{
	// Paused from the moment we hold block until the server resolves the
	// attempt ("You used Evade" / "You failed to Evade").
	return s_instance && settings::AutoE_Enabled
		&& (s_instance->m_blocking || s_instance->m_prepared);
}

bool AutoEvade::ShouldUseFastLoop()
{
	// Only spin at 1ms while a block is held / prepared — not for the whole duel.
	return settings::AutoE_Enabled && settings::AutoE_FastLoop && s_instance
		&& (s_instance->m_blocking || s_instance->m_prepared);
}

// Removes legacy formatting codes (the '§' sign plus one code character) so
// the Mineplex messages can be matched as plain text.
static std::string StripColorCodes(const std::string& in)
{
	std::string out;
	out.reserve(in.size());
	for (size_t i = 0; i < in.size(); ++i)
	{
		// '§' is 0xC2 0xA7 in UTF-8 (what GetStringUTFChars hands us).
		if ((unsigned char)in[i] == 0xC2 && i + 1 < in.size() && (unsigned char)in[i + 1] == 0xA7)
		{
			i += 2; // skip 0xA7 and the code character after it
			continue;
		}
		if ((unsigned char)in[i] == 0xA7)
		{
			i += 1;
			continue;
		}
		out += in[i];
	}
	return out;
}

bool AutoEvade::ChatMonitoringAvailable()
{
	return StrayCache::minecraft_ingameGUI != nullptr
		&& StrayCache::guiIngame_getChatGUI != nullptr
		&& StrayCache::guiNewChat_chatLines != nullptr
		&& StrayCache::chatLine_getChatComponent != nullptr
		&& StrayCache::iChatComponent_getUnformattedText != nullptr;
}

// Extracts the unformatted text of one ChatLine jobject. Consumes (deletes)
// the passed local reference.
static std::string ExtractChatLineText(JNIEnv* env, jobject line)
{
	jobject component = env->CallObjectMethod(line, StrayCache::chatLine_getChatComponent);
	env->DeleteLocalRef(line);
	if (env->ExceptionCheck() || !component)
	{
		Java::ClearException();
		if (component) env->DeleteLocalRef(component);
		return {};
	}

	jstring text = (jstring)env->CallObjectMethod(component, StrayCache::iChatComponent_getUnformattedText);
	env->DeleteLocalRef(component);
	if (env->ExceptionCheck() || !text)
	{
		Java::ClearException();
		if (text) env->DeleteLocalRef(text);
		return {};
	}

	std::string result;
	const char* chars = env->GetStringUTFChars(text, nullptr);
	if (chars)
	{
		result = chars;
		env->ReleaseStringUTFChars(text, chars);
	}
	env->DeleteLocalRef(text);
	return result;
}

std::vector<std::string> AutoEvade::GetChatLines(int maxCount)
{
	JNIEnv* env = Java::env;
	if (!env || !SDK::minecraft)
		return {};

	jobject mc = SDK::minecraft->GetInstance();
	if (!mc)
		return {};

	// java.util.List accessors, resolved once (method IDs stay valid).
	static jmethodID listSize = nullptr;
	static jmethodID listGet = nullptr;
	if (!listSize || !listGet)
	{
		jclass listClass = env->FindClass("java/util/List");
		if (!listClass)
		{
			Java::ClearException();
			return {};
		}
		listSize = env->GetMethodID(listClass, "size", "()I");
		listGet = env->GetMethodID(listClass, "get", "(I)Ljava/lang/Object;");
		env->DeleteLocalRef(listClass);
		if (!listSize || !listGet)
		{
			Java::ClearException();
			return {};
		}
	}

	jobject ingameGui = env->GetObjectField(mc, StrayCache::minecraft_ingameGUI);
	if (env->ExceptionCheck() || !ingameGui)
	{
		Java::ClearException();
		if (ingameGui) env->DeleteLocalRef(ingameGui);
		return {};
	}

	jobject chatGui = env->CallObjectMethod(ingameGui, StrayCache::guiIngame_getChatGUI);
	env->DeleteLocalRef(ingameGui);
	if (env->ExceptionCheck() || !chatGui)
	{
		Java::ClearException();
		if (chatGui) env->DeleteLocalRef(chatGui);
		return {};
	}

	jobject lines = env->GetObjectField(chatGui, StrayCache::guiNewChat_chatLines);
	env->DeleteLocalRef(chatGui);
	if (env->ExceptionCheck() || !lines)
	{
		Java::ClearException();
		if (lines) env->DeleteLocalRef(lines);
		return {};
	}

	const jint size = env->CallIntMethod(lines, listSize);
	if (env->ExceptionCheck() || size <= 0)
	{
		Java::ClearException();
		env->DeleteLocalRef(lines);
		return {};
	}

	std::vector<std::string> result;
	const int count = size < maxCount ? (int)size : maxCount;
	result.reserve(count);

	// Index 0 holds the newest received line.
	for (int i = 0; i < count; ++i)
	{
		jobject line = env->CallObjectMethod(lines, listGet, i);
		if (env->ExceptionCheck() || !line)
		{
			Java::ClearException();
			if (line) env->DeleteLocalRef(line);
			break;
		}
		result.push_back(ExtractChatLineText(env, line));
	}

	env->DeleteLocalRef(lines);
	return result;
}

static std::string ChatSnapshot(const std::vector<std::string>& lines)
{
	std::string snapshot;
	snapshot.reserve(256);
	for (const std::string& line : lines)
	{
		snapshot += line;
		snapshot += '\n';
	}
	return snapshot;
}

AutoEvade::ChatEvent AutoEvade::PollChatEvent()
{
	// Only need the newest few lines; 4 is enough for Evade verdicts.
	std::vector<std::string> lines = GetChatLines(4);
	if (lines.empty() || lines[0].empty())
		return ChatEvent::NONE;

	const std::string snapshot = ChatSnapshot(lines);
	if (!m_chatPrimed)
	{
		// First successful read: whatever is on top is history from before we
		// started watching. Store it so it is never acted on.
		m_chatPrimed = true;
		m_lastChatLine = lines[0];
		m_lastChatSnapshot = snapshot;
		return ChatEvent::NONE;
	}

	if (snapshot == m_lastChatSnapshot)
		return ChatEvent::NONE;

	// Everything above the previously seen newest line is new. Identical
	// repeats (same water message again) still change the snapshot because
	// the previous newest line is pushed down.
	size_t newCount = 0;
	while (newCount < lines.size() && lines[newCount] != m_lastChatLine)
		++newCount;
	if (newCount == 0)
		newCount = 1;
	m_lastChatLine = lines[0];
	m_lastChatSnapshot = snapshot;

	ChatEvent found = ChatEvent::NONE;
	for (size_t i = 0; i < newCount; ++i)
	{
		const std::string clean = StripColorCodes(lines[i]);
		// Water blocks Evade entirely — cancel before other verdicts.
		if (clean.find("You cannot use Evade in water") != std::string::npos)
			return ChatEvent::IN_WATER;
		if (found != ChatEvent::NONE)
			continue;
		if (clean.find("You prepared to Evade") != std::string::npos)
			found = ChatEvent::PREPARED;
		else if (clean.find("You used Evade") != std::string::npos)
			found = ChatEvent::USED;
		else if (clean.find("You failed to Evade") != std::string::npos)
			found = ChatEvent::FAILED;
	}
	return found;
}

bool AutoEvade::IsLeatherPiece(CItemStack& stack, int expectedId)
{
	if (!stack.GetInstance())
		return false;

	CItem item = stack.GetItem();
	if (!item.GetInstance())
		return false;

	// ID check only — string unlocalized-name work was a stutter source.
	return item.GetID() == expectedId;
}

bool AutoEvade::IsSelfWearingFullLeather()
{
	CInventoryPlayer inventory = SDK::minecraft->thePlayer->GetInventory();
	if (!inventory.GetInstance())
		return false;

	std::vector<CItemStack> armor = inventory.GetArmorInventory();
	if (armor.size() < 4)
		return false;

	// [0]=boots, [1]=leggings, [2]=chestplate, [3]=helmet
	return IsLeatherPiece(armor[3], LEATHER_HELMET_ID)
		&& IsLeatherPiece(armor[2], LEATHER_CHESTPLATE_ID)
		&& IsLeatherPiece(armor[1], LEATHER_LEGGINGS_ID)
		&& IsLeatherPiece(armor[0], LEATHER_BOOTS_ID);
}

bool AutoEvade::IsHoldingWeapon()
{
	return MinecraftUtils::IsWeapon(SDK::minecraft->thePlayer->GetInventory().GetCurrentItem());
}

bool AutoEvade::IsAttackerFacingMe(const Vector3& attackerEye, const Vector2& attackerAngles, const Vector3& myCenter)
{
	Vector2 toMe = Math::GetAngles(attackerEye, myCenter);
	Vector2 difference = Math::WrapAngleTo180(attackerAngles.Invert() - toMe.Invert());

	if (difference.x < 0) difference.x = -difference.x;
	if (difference.y < 0) difference.y = -difference.y;

	return difference.x <= settings::AutoE_Fov && difference.y <= settings::AutoE_Fov;
}

void AutoEvade::SetBlockHeld(bool held)
{
	SetBlockHeld(Java::env, held);
}

void AutoEvade::SetBlockHeld(JNIEnv* env, bool held)
{
	if (!env || !SDK::minecraft)
		return;

	bool usedKey = false;
	if (settings::AutoE_FastInput && SDK::minecraft->gameSettings)
	{
		try
		{
			usedKey = SDK::minecraft->gameSettings->SetUseItemPressed(env, held);
		}
		catch (...)
		{
			usedKey = false;
		}
	}

	if (usedKey)
	{
		m_useKeyHeld = held;
		return;
	}

	if (!Menu::handleWindow)
		return;

	POINT cursor{};
	GetCursorPos(&cursor);
	if (held)
		PostMessage(Menu::handleWindow, WM_RBUTTONDOWN, MK_RBUTTON, MAKELPARAM(cursor.x, cursor.y));
	else
		PostMessage(Menu::handleWindow, WM_RBUTTONUP, 0, MAKELPARAM(cursor.x, cursor.y));
	m_useKeyHeld = false;
}

void AutoEvade::StartBlock()
{
	if (m_blocking)
		return;

	SetBlockHeld(true);
	m_blocking = true;
}

void AutoEvade::StopBlock()
{
	if (!m_blocking && !m_useKeyHeld)
		return;

	SetBlockHeld(false);
	m_blocking = false;
	m_useKeyHeld = false;
}

void AutoEvade::ReleaseBlock()
{
	if (!s_instance)
		return;

	s_instance->StopBlock();
	s_instance->m_prepared = false;
	s_instance->m_blockUntil = 0;
	s_instance->m_firstEvadePendingUntil = 0;
	s_instance->m_threatTracks.clear();
}

void AutoEvade::TickDisabled()
{
	if (settings::AutoE_Enabled || !s_instance)
		return;

	if (s_instance->m_blocking || s_instance->m_useKeyHeld || s_instance->m_prepared)
		ReleaseBlock();
}

bool AutoEvade::LookOnlyMode() const
{
	return settings::AutoE_PredictiveEnabled
		&& settings::AutoE_SuccessPredEnabled
		&& m_successfulEvades >= settings::AutoE_SuccessPredCount;
}

void AutoEvade::OnEvadeSuccess()
{
	++m_successfulEvades;
	m_lookOnlyActive = LookOnlyMode();
	for (auto& kv : m_threatTracks)
	{
		kv.second.hitCount = 0;
		// Require a brand-new swing (fresh edge) before the next evade can arm.
		// Marking wasSwinging=true means a swing still in progress from before
		// this evade cannot re-trigger; only a new swing start counts.
		kv.second.lastSwingEdgeAt = 0;
		kv.second.wasSwinging = true;
	}
}

void AutoEvade::OnEvadeFailed()
{
	// Failed evade resets the success streak so look-only doesn't stick forever.
	m_successfulEvades = 0;
	m_lookOnlyActive = false;
	for (auto& kv : m_threatTracks)
	{
		kv.second.hitCount = 0;
		kv.second.lastSwingEdgeAt = 0;
		kv.second.walkbackSince = 0;
		kv.second.lastWalkbackAt = 0;
		kv.second.walkbackBait = false;
	}
}

bool AutoEvade::ScanCombatThreats(long long now, bool tookDamageRecently)
{
	m_qualifyingAttackers = 0;
	m_nearbyChecked = 0;
	m_rapidHitPeak = 0;
	m_baitingAttackers = 0;
	m_lookOnlyActive = LookOnlyMode();

	if (!CommonData::dataUpdated || !Java::env)
		return false;

	const bool predictive = settings::AutoE_PredictiveEnabled;
	const Vector3 localPos = CommonData::playerPos;
	const Vector3 myCenter = localPos + Vector3(0.f, 0.9f, 0.f);
	const float rangeSq = settings::AutoE_Range * settings::AutoE_Range;
	const bool noDamageHits = !tookDamageRecently
		&& (m_lastDamageAt == 0 || (now - m_lastDamageAt) >= NO_DAMAGE_WINDOW_MS);

	bool shouldEvade = false;
	std::unordered_map<std::string, bool> seen;
	seen.reserve(m_threatTracks.size() + 4);

	for (CommonData::PlayerData& player : CommonData::nativePlayerList)
	{
		if (!player.obj.GetInstance())
			continue;

		if (!CommonData::playerName.empty() && player.name == CommonData::playerName)
			continue;

		const float dx = player.pos.x - localPos.x;
		const float dy = player.pos.y - localPos.y;
		const float dz = player.pos.z - localPos.z;
		const float distSq = dx * dx + dy * dy + dz * dz;
		if (distSq > rangeSq)
			continue;

		++m_nearbyChecked;

		if (settings::AutoE_IgnoreFriends && configmanager::IsFriend(player.name))
			continue;

		float height = player.height;
		if (!(height > 0.5f && height < 3.5f))
			height = 1.8f;
		const Vector3 eye(player.pos.x, player.pos.y + height * 0.85f, player.pos.z);

		Vector2 angles{};
		try
		{
			angles = player.obj.GetAngles();
		}
		catch (...)
		{
			continue;
		}
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			continue;
		}

		const bool facing = IsAttackerFacingMe(eye, angles, myCenter);
		bool swinging = false;
		try
		{
			swinging = player.obj.IsSwingInProgress();
		}
		catch (...)
		{
			swinging = false;
		}
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			swinging = false;
		}

		ThreatTrack& track = m_threatTracks[player.name];
		seen[player.name] = true;

		// --- Swing tracking: one edge = one attack attempt aimed at us ---
		const bool swingEdge = swinging && !track.wasSwinging;
		track.wasSwinging = swinging;

		if (swingEdge && facing)
		{
			track.lastSwingEdgeAt = now;
			if (track.lastHitAt != 0 && (now - track.lastHitAt) > HIT_DECAY_MS)
				track.hitCount = 0;
			++track.hitCount;
			track.lastHitAt = now;
		}
		if (track.lastHitAt != 0 && (now - track.lastHitAt) > HIT_DECAY_MS)
			track.hitCount = 0;

		if (track.hitCount > m_rapidHitPeak)
			m_rapidHitPeak = track.hitCount;

		// --- Anti-Walkback: judged purely on the OPPONENT's own movement.
		// S-key bait = they keep looking at us while moving opposite to where
		// they are looking (backpedal). Independent of how we move ourselves.
		if (predictive && settings::AutoE_AntiWalkbackEnabled)
		{
			const float mdx = player.pos.x - player.lastPos.x;
			const float mdz = player.pos.z - player.lastPos.z;
			const float moveLen = std::sqrt(mdx * mdx + mdz * mdz);
			if (moveLen > WALKBACK_MIN_MOVE)
			{
				const float yawRad = Math::DegToRadiants(angles.x);
				const float lookX = -std::sin(yawRad);
				const float lookZ = std::cos(yawRad);
				const float moveDot = (mdx / moveLen) * lookX + (mdz / moveLen) * lookZ;

				if (facing && moveDot <= WALKBACK_BACKPEDAL_DOT)
				{
					// Backpedaling while staring at us.
					if (track.walkbackSince == 0)
						track.walkbackSince = now;
					track.lastWalkbackAt = now;
				}
				else if (!facing || moveDot >= WALKBACK_ADVANCE_DOT)
				{
					// Clearly advancing at us (or disengaged) — bait is over.
					track.walkbackSince = 0;
					track.walkbackBait = false;
				}
				// Sideways strafing keeps the current state (gap tolerance below).
			}

			// Standing still / brief strafe breaks are tolerated; longer than
			// WALKBACK_GAP_MS without a backpedal observation ends the streak.
			if (track.walkbackSince != 0 && (now - track.lastWalkbackAt) > WALKBACK_GAP_MS)
			{
				track.walkbackSince = 0;
				track.walkbackBait = false;
			}
			if (track.walkbackSince != 0 && (now - track.walkbackSince) >= settings::AutoE_AntiWalkbackMs)
				track.walkbackBait = true;
		}
		else
		{
			track.walkbackSince = 0;
			track.lastWalkbackAt = 0;
			track.walkbackBait = false;
		}

		if (track.walkbackBait)
		{
			++m_baitingAttackers;
			continue; // baiting — never arm an evade off this player
		}

		// --- Threat decision ---
		bool threat = false;

		if (predictive && m_lookOnlyActive)
		{
			// After N successful evades: re-arm the moment they attack again —
			// a fresh swing started while they are looking at us.
			threat = facing
				&& track.lastSwingEdgeAt != 0
				&& (now - track.lastSwingEdgeAt) <= SWING_FRESH_MS;
		}
		else if (predictive && settings::AutoE_RapidHitsEnabled)
		{
			const int need = settings::AutoE_RapidHits <= 0 ? 1 : settings::AutoE_RapidHits;
			// Hits are being sent (swing streak) but we are not taking damage.
			threat = facing && noDamageHits && track.hitCount >= need;
		}
		else
		{
			// Predictive off (or no sub-feature applies): any facing swing.
			threat = facing && swinging;
		}

		if (threat)
		{
			++m_qualifyingAttackers;
			shouldEvade = true;
		}
	}

	for (auto it = m_threatTracks.begin(); it != m_threatTracks.end(); )
	{
		if (seen.find(it->first) == seen.end())
			it = m_threatTracks.erase(it);
		else
			++it;
	}

	return shouldEvade;
}

void AutoEvade::Update()
{
	m_qualifyingAttackers = 0;
	m_nearbyChecked = 0;

	if (!settings::AutoE_Enabled)
	{
		ReleaseBlock();
		m_chatPrimed = false;
		m_lastChatSnapshot.clear();
		m_nextChatPoll = 0;
		m_nextSelfGearCheck = 0;
		return;
	}

	try
	{
	// Leave-world / main menu first — never call IsInGuiState without a live MC instance.
	if (!CommonData::SanityCheck() || !SDK::minecraft || !SDK::minecraft->theWorld || !SDK::minecraft->thePlayer)
	{
		ReleaseBlock();
		m_cooldownUntil = 0;
		m_lastPos = Vector3();
		return;
	}

	// Never fight the user's menu / inventory interactions.
	if (Menu::open || SDK::minecraft->IsInGuiState())
	{
		StopBlock();
		m_prepared = false;
		m_blockUntil = 0;
		m_lastPos = Vector3();
		return;
	}

	const long long now = NowMillis();
	const bool chatOk = ChatMonitoringAvailable();

	if (chatOk && (m_blocking || m_prepared || now >= m_nextChatPoll))
	{
		m_nextChatPoll = now + CHAT_POLL_MS;

		const ChatEvent event = PollChatEvent();
		if (event != ChatEvent::NONE)
			m_lastChatEvent = event;

		switch (event)
		{
		case ChatEvent::PREPARED:
			// Only base the window on the FIRST prepare of this block. Once we
			// are already holding, the server re-prints "You prepared to Evade"
			// every time the evade recharges — extending the deadline on those
			// would keep the block held forever and stop us from releasing to
			// re-arm the next evade.
			if (!m_prepared)
			{
				m_prepared = true;
				m_blockUntil = now + settings::AutoE_BlockDuration + CHAT_GRACE_MS;
			}
			break;
		case ChatEvent::USED:
			m_lastResult = EvadeResult::SUCCESS;
			OnEvadeSuccess();
			m_prepared = false;
			StopBlock();
			m_blockUntil = 0;
			// Look-only mode re-arms off the opponent's next swing, so only the
			// server recharge applies — the Re-arm Gap timer is bypassed.
			m_cooldownUntil = now + (m_lookOnlyActive ? EVADE_RECHARGE_MS : settings::AutoE_ReleaseGap);
			break;
		case ChatEvent::FAILED:
			m_lastResult = EvadeResult::FAILED;
			OnEvadeFailed();
			m_prepared = false;
			StopBlock();
			m_blockUntil = 0;
			m_cooldownUntil = now + settings::AutoE_FailCooldown;
			break;
		case ChatEvent::IN_WATER:
			// Not a failed Evade — cancel the hold and wait before retrying.
			m_prepared = false;
			StopBlock();
			m_blockUntil = 0;
			m_firstEvadePendingUntil = 0;
			m_cooldownUntil = now + settings::AutoE_WaterRetryMs;
			break;
		default:
			break;
		}
	}

	if (now >= m_nextSelfGearCheck)
	{
		m_nextSelfGearCheck = now + SELF_GEAR_CACHE_MS;
		m_cachedSelfLeather = !settings::AutoE_RequireLeather || IsSelfWearingFullLeather();
		m_cachedHoldingWeapon = !settings::AutoE_RequireWeapon || IsHoldingWeapon();
	}

	if (settings::AutoE_RequireLeather && !m_cachedSelfLeather)
	{
		StopBlock();
		m_prepared = false;
		m_blockUntil = 0;
		m_lastPos = Vector3();
		return;
	}

	if (settings::AutoE_RequireWeapon && !m_cachedHoldingWeapon)
	{
		StopBlock();
		m_prepared = false;
		m_blockUntil = 0;
		m_lastPos = Vector3();
		return;
	}

	const Vector3 localPos = CommonData::playerPos;

	float movedDistance = 0.f;
	if (!std::isnan(m_lastPos.x))
		movedDistance = localPos.Distance(m_lastPos);
	m_lastPos = localPos;

	int hurtResistant = m_lastHurtResistant;
	if (SDK::minecraft->thePlayer->GetInstance())
		hurtResistant = SDK::minecraft->thePlayer->GetHurtResistantTime();
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		hurtResistant = m_lastHurtResistant;
	}
	const bool tookDamage = hurtResistant > m_lastHurtResistant;
	m_lastHurtResistant = hurtResistant;
	if (tookDamage)
		m_lastDamageAt = now;

	bool qualifying = false;
	// Keep scanning during cooldowns too: swing edges and walkback streaks that
	// happen inside the re-arm gap must still be observed so prediction can act
	// on them the moment the recharge ends.
	const bool needThreatScan = !m_blocking && now >= m_nextThreatScan;

	if (needThreatScan)
	{
		m_nextThreatScan = now + THREAT_SCAN_MS;
		qualifying = ScanCombatThreats(now, tookDamage);
		// Drop a pending first-evade wait only when a real scan says no threat.
		if (!qualifying)
			m_firstEvadePendingUntil = 0;
	}

	if (m_blocking)
	{
		if (chatOk)
		{
			if (movedDistance > TELEPORT_DISTANCE)
			{
				m_lastResult = EvadeResult::SUCCESS;
				OnEvadeSuccess();
				m_prepared = false;
				StopBlock();
				m_blockUntil = 0;
				m_cooldownUntil = now + (m_lookOnlyActive ? EVADE_RECHARGE_MS : settings::AutoE_ReleaseGap);
			}
			else if (now >= m_blockUntil)
			{
				// Window elapsed with no teleport and no explicit "used"/"failed"
				// from the server. Don't self-score a fail here: that would burn
				// the long fail cooldown and freeze us mid-fight. A genuine miss
				// arrives as the "You failed to Evade" chat event (handled above),
				// so just release and let the next block arm normally.
				StopBlock();
				m_prepared = false;
				m_blockUntil = 0;
				m_cooldownUntil = now + settings::AutoE_ReleaseGap;
			}
			return;
		}

		if (movedDistance > TELEPORT_DISTANCE)
		{
			m_lastResult = EvadeResult::SUCCESS;
			OnEvadeSuccess();
			StopBlock();
			m_blockUntil = 0;
			m_cooldownUntil = now + (m_lookOnlyActive ? EVADE_RECHARGE_MS : settings::AutoE_ReleaseGap);
		}
		else if (tookDamage)
		{
			m_lastResult = EvadeResult::FAILED;
			OnEvadeFailed();
			StopBlock();
			m_blockUntil = 0;
			m_cooldownUntil = now + settings::AutoE_FailCooldown;
		}
		else if (now >= m_blockUntil)
		{
			m_lastResult = EvadeResult::FAILED;
			OnEvadeFailed();
			StopBlock();
			m_blockUntil = 0;
			m_cooldownUntil = now + settings::AutoE_FailCooldown;
		}
		return;
	}

	if (now < m_cooldownUntil)
	{
		m_firstEvadePendingUntil = 0;
		return;
	}

	// After 5s idle, treat the next evade as first again (offset applies).
	if (m_evadeCounter > 0 && m_lastEvadeAt > 0 && (now - m_lastEvadeAt) >= FIRST_EVADE_RESET_MS)
	{
		m_evadeCounter = 0;
		m_firstEvadePendingUntil = 0;
	}

	// Fire on this scan's threat, or finish a first-evade wait started on an earlier scan.
	const bool threatReady = qualifying || (m_firstEvadePendingUntil > 0 && now >= m_firstEvadePendingUntil);
	if (threatReady)
	{
		// First-Evade-offset: delay only the first evade in a burst; later ones fire immediately.
		const bool applyFirstOffset = m_evadeCounter == 0 && settings::AutoE_FirstEvadeOffset > 0;
		if (applyFirstOffset)
		{
			if (m_firstEvadePendingUntil == 0)
				m_firstEvadePendingUntil = now + settings::AutoE_FirstEvadeOffset;
			if (now < m_firstEvadePendingUntil)
				return;
		}

		m_firstEvadePendingUntil = 0;
		StartBlock();
		++m_evadeCounter;
		m_lastEvadeAt = now;
		m_blockUntil = now + settings::AutoE_BlockDuration + (chatOk ? CHAT_GRACE_MS : 0);
	}
	}
	catch (...)
	{
		if (Java::env && Java::env->ExceptionCheck())
			Java::ClearException();
		StopBlock();
		m_prepared = false;
	}
}

void AutoEvade::RenderMenu()
{
	Menu::BoldText("Auto Evade", FontSize::SIZE_22);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.f);

	Menu::ToggleWithKeybind(&settings::AutoE_Enabled, settings::AutoE_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AutoE_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Text("Auto-Evade for Mineplex", FontSize::SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AutoE_Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Range", &settings::AutoE_Range, 1.0f, 8.0f);
	Menu::Slider("Attacker FOV", &settings::AutoE_Fov, 5.0f, 180.0f);
	Menu::Slider("Evade Window (ms)", &settings::AutoE_BlockDuration, 250, 3000);
	Menu::Slider("Re-arm Gap (ms)", &settings::AutoE_ReleaseGap, 50, 1000);
	Menu::Slider("Fail Cooldown (ms)", &settings::AutoE_FailCooldown, 0, 30000);
	Menu::Slider("Water Retry (ms)", &settings::AutoE_WaterRetryMs, 1000, 30000);
	Menu::Text("If chat says you cannot Evade in water, cancel and wait this long.", FontSize::SIZE_14);
	Menu::Text("Still in water after the wait: wait the timer again.", FontSize::SIZE_14);
	Menu::Slider("First-Evade-offset (ms)", &settings::AutoE_FirstEvadeOffset, 0, 1000);
	Menu::Text("Delays only the first evade; later ones are instant. Resets after 5s idle.", FontSize::SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AutoE_Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Require Full Leather", &settings::AutoE_RequireLeather);
	Menu::Checkbox("Require Weapon", &settings::AutoE_RequireWeapon);
	Menu::Checkbox("Ignore Friends", &settings::AutoE_IgnoreFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AutoE_SepFast");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Predictive", &settings::AutoE_PredictiveEnabled);
	if (settings::AutoE_PredictiveEnabled)
	{
		Menu::Checkbox("Rapid Hits Till Evade", &settings::AutoE_RapidHitsEnabled);
		if (settings::AutoE_RapidHitsEnabled)
		{
			Menu::Slider("Opponent Hits", &settings::AutoE_RapidHits, 0, 5);
			Menu::Text("Count their swings at you with no damage, then evade.", FontSize::SIZE_14);
		}

		Menu::Checkbox("Successful Evade Prediction", &settings::AutoE_SuccessPredEnabled);
		if (settings::AutoE_SuccessPredEnabled)
		{
			Menu::Slider("Successful Evades", &settings::AutoE_SuccessPredCount, 0, 20);
			Menu::Text("After N successes: evade when they swing while looking", FontSize::SIZE_14);
			Menu::Text("at you. Skips the Re-arm Gap timer (server 250ms only).", FontSize::SIZE_14);
		}

		Menu::Checkbox("Anti-Walkback", &settings::AutoE_AntiWalkbackEnabled);
		if (settings::AutoE_AntiWalkbackEnabled)
		{
			Menu::Slider("Walkback Time (ms)", &settings::AutoE_AntiWalkbackMs, 250, 5000);
			Menu::Text("Ignore bait: they backpedal while staring at you.", FontSize::SIZE_14);
		}
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8.f);
	Menu::Checkbox("Fast Input", &settings::AutoE_FastInput);
	Menu::Checkbox("Fast Loop", &settings::AutoE_FastLoop);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AutoE_Sep4");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	const bool mappingOk = StrayCache::entityLivingBase_isSwingInProgress != nullptr;
	Menu::TextColored(
		mappingOk ? "Swing detection: OK" : "Swing detection: MISSING",
		mappingOk ? ImVec4(0.3f, 1.f, 0.3f, 1.f) : ImVec4(1.f, 0.3f, 0.3f, 1.f),
		FontSize::SIZE_16);

	const bool chatOk = ChatMonitoringAvailable();
	Menu::TextColored(
		chatOk ? "Chat monitor: OK" : "Chat monitor: MISSING (fallback detection)",
		chatOk ? ImVec4(0.3f, 1.f, 0.3f, 1.f) : ImVec4(1.f, 0.6f, 0.2f, 1.f),
		FontSize::SIZE_16);

	const bool useKeyOk = StrayCache::gameSettings_keyBindUseItem && StrayCache::keyBinding_pressed;
	Menu::TextColored(
		useKeyOk ? "Fast input: OK" : "Fast input: FALLBACK (SendMessage)",
		useKeyOk ? ImVec4(0.3f, 1.f, 0.3f, 1.f) : ImVec4(1.f, 0.6f, 0.2f, 1.f),
		FontSize::SIZE_16);

	Menu::TextColored("Swing hook: disabled (stability)", ImVec4(0.7f, 0.7f, 0.7f, 1.f), FontSize::SIZE_16);

	const char* result = "-";
	if (m_lastResult == EvadeResult::SUCCESS) result = "SUCCESS";
	else if (m_lastResult == EvadeResult::FAILED) result = "failed";

	const char* chatEvent = "-";
	if (m_lastChatEvent == ChatEvent::PREPARED) chatEvent = "prepared";
	else if (m_lastChatEvent == ChatEvent::USED) chatEvent = "used";
	else if (m_lastChatEvent == ChatEvent::FAILED) chatEvent = "failed";
	else if (m_lastChatEvent == ChatEvent::IN_WATER) chatEvent = "in water";

	const long long now = NowMillis();
	const int cooldownLeft = m_cooldownUntil > now ? (int)(m_cooldownUntil - now) : 0;

	char status[288];
	std::snprintf(status, sizeof(status),
		"Blocking: %s%s | Nearby: %d | Threats: %d | Bait: %d | Hits: %d | Success: %d%s | Evades: %d | Last: %s | Cd: %dms",
		m_blocking ? "YES" : "no", m_prepared ? " (prepared)" : "",
		m_nearbyChecked, m_qualifyingAttackers, m_baitingAttackers, m_rapidHitPeak, m_successfulEvades,
		m_lookOnlyActive ? " (LOOK)" : "",
		m_evadeCounter, result, cooldownLeft);
	Menu::Text(status, FontSize::SIZE_14);
	char chatStatus[64];
	std::snprintf(chatStatus, sizeof(chatStatus), "Chat: %s", chatEvent);
	Menu::Text(chatStatus, FontSize::SIZE_14);
}
