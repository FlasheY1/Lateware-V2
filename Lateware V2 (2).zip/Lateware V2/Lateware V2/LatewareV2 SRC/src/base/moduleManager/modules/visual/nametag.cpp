#include "nametag.h"

#include <chrono>
#include <cmath>
#include <cstdio>

#include "configManager/configManager.h"
#include "java/java.h"
#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "sdk/net/minecraft/item/ItemStack.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "util/math/camera.h"
#include "util/render/itemIcons.h"
#include "util/render/render.h"

namespace
{
	long long NowMs()
	{
		return std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::steady_clock::now().time_since_epoch()).count();
	}

	Vector3 RelHead(const Vector3& pos, const Vector3& last, const Vector3& camera, float pt)
	{
		constexpr float headY = 1.72f;
		const float ix = last.x + (pos.x - last.x) * pt;
		const float iy = last.y + (pos.y - last.y) * pt;
		const float iz = last.z + (pos.z - last.z) * pt;
		return Vector3{ ix - camera.x, iy + headY - camera.y, iz - camera.z };
	}

	bool SafeIsInvisible(jobject entity, jobject viewer)
	{
		if (!settings::NT_DisplayInvisible)
			return false;
		if (!StrayCache::entity_isInvisibleToPlayer || !entity || !viewer || !Java::env)
			return false;

		const jboolean result = Java::env->CallBooleanMethod(
			entity, StrayCache::entity_isInvisibleToPlayer, viewer);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			return false;
		}
		return result == JNI_TRUE;
	}

	bool ReadItemId(CItemStack& stack, int& outId, int& outCount)
	{
		outId = -1;
		outCount = 0;
		if (!stack.GetInstance() || !Java::env)
			return false;

		CItem item = stack.GetItem();
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			return false;
		}
		if (!item.GetInstance())
			return false;

		const int id = item.GetID();
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			return false;
		}

		int count = 1;
		if (StrayCache::itemStack_stackSize)
		{
			count = stack.GetStackSize();
			if (Java::env->ExceptionCheck())
			{
				Java::ClearException();
				count = 1;
			}
			if (count < 1) count = 1;
		}

		outId = id;
		outCount = count;
		return true;
	}

	void DrawOutlined(ImFont* font, float size, ImVec2 pos, ImColor col, ImColor outline, const char* text, bool outlineOn)
	{
		if (outlineOn)
			Render::DrawOutlinedText(font, size, pos, col, outline, text);
		else
			ImGui::GetWindowDrawList()->AddText(font, size, pos, col, text);
	}
}

void Nametag::Update()
{
	if (!settings::NT_Enabled)
	{
		NativeGuard lock(m_mutex);
		m_nametagData.clear();
		m_gearCache.clear();
		return;
	}

	if (!CommonData::SanityCheck() || !CommonData::dataUpdated || !Java::env)
		return;

	try
	{
		const Vector3 camera = CommonData::renderPos;
		const Vector3 localPos = CommonData::playerPos;
		const float pt = CommonData::renderPartialTicks;
		jobject localPlayer = SDK::minecraft->thePlayer ? SDK::minecraft->thePlayer->GetInstance() : nullptr;
		const long long now = NowMs();
		const bool wantGear = settings::NT_DisplayArmor || settings::NT_DisplayHeldItem;

		std::vector<Data> newData;
		newData.reserve(CommonData::nativePlayerList.size());

		for (CommonData::PlayerData& entity : CommonData::nativePlayerList)
		{
			if (!entity.obj.GetInstance())
				continue;

			if (!CommonData::playerName.empty() && entity.name == CommonData::playerName)
				continue;

			if (entity.name.empty())
				continue;

			if (settings::NT_IgnoreFriends && configmanager::IsFriend(entity.name))
				continue;

			const float dx = localPos.x - entity.pos.x;
			const float dy = localPos.y - entity.pos.y;
			const float dz = localPos.z - entity.pos.z;
			const float distSq = dx * dx + dy * dy + dz * dz;

			constexpr float kMaxDist = 128.f;
			if (distSq > kMaxDist * kMaxDist)
				continue;

			const float dist = std::sqrt(distSq);
			if (dist < settings::NT_TextUnrenderDistance)
				continue;

			float fade = 1.f;
			if ((dist - 1.f) <= settings::NT_FadeDistance && settings::NT_FadeDistance > 0.f)
				fade = (dist - 1.f) / settings::NT_FadeDistance;
			if (fade < 0.f) fade = 0.f;
			if (fade > 1.f) fade = 1.f;

			Data d;
			d.headRel = RelHead(entity.pos, entity.lastPos, camera, pt);
			d.name = entity.name;
			d.dist = dist;
			d.opacityFadeFactor = fade;

			if (settings::NT_DisplayDistance)
			{
				char buf[24];
				std::snprintf(buf, sizeof(buf), "%.1fm", dist);
				d.distText = buf;
			}

			if (settings::NT_DisplayHealth
				&& entity.health > 0.f && entity.health < 1.0e6f
				&& entity.maxHealth > 0.f && entity.maxHealth < 1.0e6f)
			{
				char buf[40];
				std::snprintf(buf, sizeof(buf), "%.1f/%.1fhp", entity.health, entity.maxHealth);
				d.healthText = buf;
			}

			if (SafeIsInvisible(entity.obj.GetInstance(), localPlayer))
				d.invisibleText = "Invisible";

			if (wantGear)
			{
				GearCache* cache = nullptr;
				auto it = m_gearCache.find(entity.name);
				if (it != m_gearCache.end() && (now - it->second.checkedAt) < GEAR_CACHE_MS)
				{
					cache = &it->second;
				}
				else
				{
					GearCache fresh{};
					fresh.checkedAt = now;

					CInventoryPlayer inv = entity.obj.GetInventory();
					if (inv.GetInstance())
					{
						if (settings::NT_DisplayArmor)
						{
							std::vector<CItemStack> armor = inv.GetArmorInventory();
							// MC: [0]=boots [1]=legs [2]=chest [3]=helm -> display helm..boots
							const int map[4] = { 3, 2, 1, 0 };
							for (int i = 0; i < 4; ++i)
							{
								const int idx = map[i];
								int id = -1, count = 0;
								if (idx < (int)armor.size() && ReadItemId(armor[idx], id, count))
									fresh.armorIds[i] = id;
							}
						}

						if (settings::NT_DisplayHeldItem)
						{
							CItemStack held = inv.GetCurrentItem();
							int id = -1, count = 0;
							if (ReadItemId(held, id, count))
							{
								fresh.heldId = id;
								fresh.heldCount = count;
							}
						}
					}

					if (Java::env->ExceptionCheck())
						Java::ClearException();

					it = m_gearCache.insert_or_assign(entity.name, fresh).first;
					cache = &it->second;
				}

				if (cache)
				{
					if (settings::NT_DisplayArmor)
					{
						for (int i = 0; i < 4; ++i)
							d.armorIds[i] = cache->armorIds[i];
					}
					if (settings::NT_DisplayHeldItem)
					{
						d.heldId = cache->heldId;
						d.heldCount = cache->heldCount;
					}
				}
			}

			newData.push_back(std::move(d));
		}

		if (localPlayer)
			Java::env->DeleteLocalRef(localPlayer);

		if (m_gearCache.size() > 64)
		{
			for (auto it = m_gearCache.begin(); it != m_gearCache.end(); )
			{
				if (now - it->second.checkedAt > GEAR_CACHE_MS * 4)
					it = m_gearCache.erase(it);
				else
					++it;
			}
		}

		{
			NativeGuard lock(m_mutex);
			m_nametagData = std::move(newData);
		}
	}
	catch (...)
	{
		if (Java::env && Java::env->ExceptionCheck())
			Java::ClearException();
		NativeGuard lock(m_mutex);
		m_nametagData.clear();
	}
}

void Nametag::RenderOverlay()
{
	if (!settings::NT_Enabled || !CommonData::dataUpdated)
		return;

	ImFont* font = Menu::font ? Menu::font : ImGui::GetFont();
	if (!font)
		return;

	ImDrawList* draw = ImGui::GetWindowDrawList();
	if (!draw)
		return;

	const ImVec2 screenSize = ImGui::GetWindowSize();
	if (screenSize.x < 1.f || screenSize.y < 1.f)
		return;

	// Icon atlas upload is optional — never let GL/stbi failures kill the frame.
	if (settings::NT_DisplayArmor || settings::NT_DisplayHeldItem)
	{
		try { ItemIcons::EnsureLoaded(); }
		catch (...) {}
	}

	std::vector<Data> nametagData;
	{
		NativeGuard lock(m_mutex);
		nametagData = m_nametagData;
	}

	const float textSize = settings::NT_TextSize;
	const float iconSize = textSize + 4.f;
	const float padX = 7.f;
	const float padY = 4.f;
	const float round = 6.f;
	const float lift = 6.f;
	const float iconGap = 3.f;

	for (const Data& data : nametagData)
	{
		Vector2 screen;
		if (!CameraUtils::WorldToScreen(
			data.headRel, CommonData::modelView, CommonData::projection,
			(int)screenSize.x, (int)screenSize.y, screen))
			continue;

		if (screen.x < -screenSize.x || screen.x > screenSize.x * 2.f
			|| screen.y < -screenSize.y || screen.y > screenSize.y * 2.f)
			continue;

		const float a = data.opacityFadeFactor;
		if (a <= 0.01f)
			continue;

		const ImColor textCol(settings::NT_TextColor[0], settings::NT_TextColor[1], settings::NT_TextColor[2], settings::NT_TextColor[3] * a);
		const ImColor outlineCol(settings::NT_TextOutlineColor[0], settings::NT_TextOutlineColor[1], settings::NT_TextOutlineColor[2], settings::NT_TextOutlineColor[3] * a);
		const ImColor bgCol(settings::NT_BackgroundColor[0], settings::NT_BackgroundColor[1], settings::NT_BackgroundColor[2], settings::NT_BackgroundColor[3] * a);
		const ImColor bgOutlineCol(settings::NT_BackgroundOutlineColor[0], settings::NT_BackgroundOutlineColor[1], settings::NT_BackgroundOutlineColor[2], settings::NT_BackgroundOutlineColor[3] * a);

		auto drawPanel = [&](float posX, float posY, float textW, float textH)
		{
			if (!settings::NT_Background)
				return;
			const ImVec2 panelMin(posX - padX, posY - padY);
			const ImVec2 panelMax(posX + textW + padX, posY + textH + padY);
			draw->AddRectFilled(panelMin, panelMax, bgCol, round);
			if (settings::NT_BackgroundOutline)
				draw->AddRect(panelMin, panelMax, bgOutlineCol, round, 0, 1.0f);
		};

		float nameW = 0.f;
		float nameH = 0.f;
		std::string singleLine;
		const char* lines[4]{};
		ImVec2 lineSizes[4]{};
		int lineCount = 0;

		if (settings::NT_MultiLine)
		{
			if (!data.name.empty()) lines[lineCount++] = data.name.c_str();
			if (settings::NT_DisplayHealth && !data.healthText.empty()) lines[lineCount++] = data.healthText.c_str();
			if (settings::NT_DisplayDistance && !data.distText.empty()) lines[lineCount++] = data.distText.c_str();
			if (settings::NT_DisplayInvisible && !data.invisibleText.empty()) lines[lineCount++] = data.invisibleText.c_str();

			for (int i = 0; i < lineCount; ++i)
			{
				lineSizes[i] = font->CalcTextSizeA(textSize, FLT_MAX, 0.0f, lines[i]);
				nameH += lineSizes[i].y;
				if (lineSizes[i].x > nameW)
					nameW = lineSizes[i].x;
			}
		}
		else
		{
			singleLine = data.name;
			if (settings::NT_DisplayHealth && !data.healthText.empty())
				singleLine += " [" + data.healthText + "]";
			if (settings::NT_DisplayDistance && !data.distText.empty())
				singleLine += " " + data.distText;
			if (settings::NT_DisplayInvisible && !data.invisibleText.empty())
				singleLine += " " + data.invisibleText;

			const ImVec2 sz = font->CalcTextSizeA(textSize, FLT_MAX, 0.0f, singleLine.c_str());
			nameW = sz.x;
			nameH = sz.y;
		}

		if (nameW <= 0.f || nameH <= 0.f)
			continue;

		// Icon row: armor (4) + held
		int iconIds[5]{};
		int iconCounts[5]{};
		bool iconEmpty[5]{};
		int iconCount = 0;

		if (settings::NT_DisplayArmor)
		{
			for (int i = 0; i < 4; ++i)
			{
				iconIds[iconCount] = data.armorIds[i];
				iconCounts[iconCount] = 1;
				iconEmpty[iconCount] = (data.armorIds[i] < 0);
				++iconCount;
			}
		}
		if (settings::NT_DisplayHeldItem && data.heldId >= 0)
		{
			iconIds[iconCount] = data.heldId;
			iconCounts[iconCount] = data.heldCount;
			iconEmpty[iconCount] = false;
			++iconCount;
		}

		const float gearW = iconCount > 0
			? (iconCount * iconSize) + ((iconCount - 1) * iconGap)
				+ ((settings::NT_DisplayArmor && settings::NT_DisplayHeldItem && data.heldId >= 0) ? iconGap * 1.5f : 0.f)
			: 0.f;
		const float gearH = iconCount > 0 ? iconSize : 0.f;
		const float gearToName = iconCount > 0 ? 3.f : 0.f;
		const float totalH = nameH + gearH + gearToName;
		float cursorY = screen.y - totalH - lift;

		if (iconCount > 0)
		{
			float iconX = screen.x - (gearW * 0.5f);
			const int armorCount = settings::NT_DisplayArmor ? 4 : 0;
			for (int i = 0; i < iconCount; ++i)
			{
				if (i == armorCount && armorCount > 0)
					iconX += iconGap * 1.5f;

				const ImVec2 imin(iconX, cursorY);
				const ImVec2 imax(iconX + iconSize, cursorY + iconSize);

				if (iconEmpty[i])
					ItemIcons::DrawEmptySlot(draw, imin, imax, a);
				else
					ItemIcons::DrawIcon(draw, iconIds[i], imin, imax, a);

				if (!iconEmpty[i] && iconCounts[i] > 1)
				{
					char countBuf[8];
					std::snprintf(countBuf, sizeof(countBuf), "%d", iconCounts[i]);
					const float csize = textSize * 0.65f;
					const ImVec2 csz = font->CalcTextSizeA(csize, FLT_MAX, 0.f, countBuf);
					const ImVec2 cpos(imax.x - csz.x - 1.f, imax.y - csz.y - 1.f);
					DrawOutlined(font, csize, cpos, textCol, outlineCol, countBuf, settings::NT_TextOutline);
				}

				iconX += iconSize + iconGap;
			}
			cursorY += gearH + gearToName;
		}

		const float nameX = screen.x - (nameW * 0.5f);
		drawPanel(nameX, cursorY, nameW, nameH);

		if (settings::NT_MultiLine)
		{
			float y = cursorY;
			for (int i = 0; i < lineCount; ++i)
			{
				DrawOutlined(font, textSize, ImVec2(nameX, y), textCol, outlineCol, lines[i], settings::NT_TextOutline);
				y += lineSizes[i].y;
			}
		}
		else
		{
			DrawOutlined(font, textSize, ImVec2(nameX, cursorY), textCol, outlineCol, singleLine.c_str(), settings::NT_TextOutline);
		}
	}
}

void Nametag::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::NT_Enabled, settings::NT_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Text Size", &settings::NT_TextSize, 8.f, 32.f);
	Menu::ColorEdit("Text Color", settings::NT_TextColor);
	Menu::Checkbox("Text Outline", &settings::NT_TextOutline);
	if (settings::NT_TextOutline)
		Menu::ColorEdit("Outline Color", settings::NT_TextOutlineColor);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Unrender Distance", &settings::NT_TextUnrenderDistance, 0.f, 50.f);
	Menu::Slider("Fade Distance", &settings::NT_FadeDistance, 0.f, 10.f);
	Menu::Checkbox("Background", &settings::NT_Background);
	if (settings::NT_Background)
	{
		Menu::ColorEdit("Background Color", settings::NT_BackgroundColor);
		Menu::Checkbox("Background Outline", &settings::NT_BackgroundOutline);
		if (settings::NT_BackgroundOutline)
			Menu::ColorEdit("BG Outline Color", settings::NT_BackgroundOutlineColor);
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Ignore Friends", &settings::NT_IgnoreFriends);
	Menu::Checkbox("Multi Line", &settings::NT_MultiLine);
	Menu::Checkbox("Display Health", &settings::NT_DisplayHealth);
	Menu::Checkbox("Display Distance", &settings::NT_DisplayDistance);
	Menu::Checkbox("Display Invisible", &settings::NT_DisplayInvisible);
	Menu::Checkbox("Display Armor", &settings::NT_DisplayArmor);
	Menu::Checkbox("Display Held Item", &settings::NT_DisplayHeldItem);
}
