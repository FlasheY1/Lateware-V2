#include "autoFlashStab.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <vector>

#include <Windows.h>

#include "configManager/configManager.h"
#include "menu/menu.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "util/math/math.h"

long long AutoFlashStab::NowMs()
{
	return std::chrono::duration_cast<std::chrono::milliseconds>(
		std::chrono::steady_clock::now().time_since_epoch()).count();
}

double AutoFlashStab::DistToBox(const Vector3& p, const BoundingBox& bb)
{
	const double cx = (p.x < bb.minX) ? bb.minX : (p.x > bb.maxX ? bb.maxX : p.x);
	const double cy = (p.y < bb.minY) ? bb.minY : (p.y > bb.maxY ? bb.maxY : p.y);
	const double cz = (p.z < bb.minZ) ? bb.minZ : (p.z > bb.maxZ ? bb.maxZ : p.z);
	const double dx = p.x - cx;
	const double dy = p.y - cy;
	const double dz = p.z - cz;
	return std::sqrt(dx * dx + dy * dy + dz * dz);
}

bool AutoFlashStab::IsAxeId(int id)
{
	return id == 271 || id == 275 || id == 258 || id == 279 || id == 286;
}

bool AutoFlashStab::IsLookingAt(const Vector3& eye, const Vector2& look, const Vector3& pos, float height) const
{
	const float h = (height > 0.f && height < 4.f) ? height : 1.8f;
	const Vector3 center = pos + Vector3(0.f, h * 0.5f, 0.f);
	Vector2 toTarget = Math::GetAngles(eye, center);
	Vector2 difference = Math::WrapAngleTo180(look.Invert() - toTarget.Invert());
	if (difference.x < 0) difference.x = -difference.x;
	if (difference.y < 0) difference.y = -difference.y;
	return difference.x <= settings::AFS_Fov && difference.y <= settings::AFS_Fov;
}

int AutoFlashStab::FindAxeHotbarSlot()
{
	try
	{
		CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
		if (!inv.GetInstance())
			return -1;

		std::vector<CItemStack> main = inv.GetMainInventory();
		const int n = static_cast<int>((std::min)(main.size(), static_cast<size_t>(9)));
		for (int i = 0; i < n; ++i)
		{
			if (!main[i].GetInstance())
				continue;
			CItem item = main[i].GetItem();
			if (!item.GetInstance())
				continue;
			const int id = item.GetID();
			if (Java::env->ExceptionCheck())
			{
				Java::ClearException();
				continue;
			}
			if (IsAxeId(id))
				return i;
		}
	}
	catch (...)
	{
	}
	return -1;
}

bool AutoFlashStab::FindTarget(std::string& nameOut, double& distOut)
{
	nameOut.clear();
	distOut = 0.0;

	const Vector3 myPos = CommonData::playerPos;
	const Vector3 eye = CommonData::playerEyePos;
	const Vector2 look = CommonData::playerAngles;

	auto distTo = [&](const Vector3& p) -> double
	{
		const double dx = myPos.x - p.x;
		const double dy = myPos.y - p.y;
		const double dz = myPos.z - p.z;
		return std::sqrt(dx * dx + dy * dy + dz * dz);
	};

	try
	{
		CEntity hit = SDK::minecraft->GetMouseOver().GetEntityHit();
		if (Java::env->ExceptionCheck())
			Java::ClearException();
		else if (hit.GetInstance())
		{
			for (CommonData::PlayerData& pl : CommonData::nativePlayerList)
			{
				if (!pl.obj.GetInstance())
					continue;
				if (!Java::env->IsSameObject(hit.GetInstance(), pl.obj.GetInstance()))
					continue;
				if (pl.health <= 0.f)
					break;
				if (settings::AFS_IgnoreFriends && configmanager::IsFriend(pl.name))
					break;
				const double d = distTo(pl.pos);
				if (d > settings::AFS_FlashRange)
					break;
				nameOut = pl.name;
				distOut = d;
				return true;
			}
		}
	}
	catch (...)
	{
	}

	CommonData::PlayerData* best = nullptr;
	double bestDist = static_cast<double>(settings::AFS_FlashRange);
	for (CommonData::PlayerData& pl : CommonData::nativePlayerList)
	{
		if (!pl.obj.GetInstance())
			continue;
		if (Java::env->IsSameObject(SDK::minecraft->thePlayer->GetInstance(), pl.obj.GetInstance()))
			continue;
		if (!pl.name.empty() && pl.name == CommonData::playerName)
			continue;
		if (pl.health <= 0.f)
			continue;
		if (settings::AFS_IgnoreFriends && configmanager::IsFriend(pl.name))
			continue;

		const double d = distTo(pl.pos);
		if (d > bestDist || d < 0.05)
			continue;
		if (!IsLookingAt(eye, look, pl.pos, pl.height))
			continue;

		bestDist = d;
		best = &pl;
	}

	if (!best)
		return false;

	nameOut = best->name;
	distOut = bestDist;
	return true;
}

double AutoFlashStab::LiveTargetDist()
{
	if (m_targetName.empty() || !SDK::minecraft->thePlayer)
		return -1.0;

	try
	{
		Vector3 myPos = SDK::minecraft->thePlayer->GetPos();
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			myPos = CommonData::playerPos;
		}

		for (CommonData::PlayerData& pl : CommonData::nativePlayerList)
		{
			if (pl.name != m_targetName || !pl.obj.GetInstance())
				continue;

			BoundingBox bb = pl.boundingBox;
			try
			{
				bb = pl.obj.GetBB().GetNativeBoundingBox();
				if (Java::env->ExceptionCheck())
				{
					Java::ClearException();
					bb = pl.boundingBox;
				}
			}
			catch (...)
			{
				bb = pl.boundingBox;
			}

			return DistToBox(myPos, bb);
		}
	}
	catch (...)
	{
	}
	return -1.0;
}

void AutoFlashStab::SelectHotbarSlot(int slot)
{
	if (slot < 0 || slot > 8)
		return;

	try
	{
		CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
		if (inv.GetInstance())
			inv.SetCurrentItemIndex(slot);
	}
	catch (...)
	{
	}

	if (!Menu::handleWindow)
		return;

	const WPARAM vk = static_cast<WPARAM>('1' + slot);
	PostMessage(Menu::handleWindow, WM_KEYDOWN, vk, 0);
	PostMessage(Menu::handleWindow, WM_KEYUP, vk, 0);
}

void AutoFlashStab::FlashDown()
{
	bool ok = false;
	if (SDK::minecraft->gameSettings)
	{
		try
		{
			ok = SDK::minecraft->gameSettings->SetUseItemPressed(true);
		}
		catch (...)
		{
			ok = false;
		}
	}
	m_flashKeyHeld = ok;

	if (!ok && Menu::handleWindow)
	{
		POINT cursor{};
		GetCursorPos(&cursor);
		ScreenToClient(Menu::handleWindow, &cursor);
		PostMessage(Menu::handleWindow, WM_RBUTTONDOWN, MK_RBUTTON, MAKELPARAM(cursor.x, cursor.y));
	}
}

void AutoFlashStab::FlashUp()
{
	if (m_flashKeyHeld && SDK::minecraft->gameSettings)
	{
		try
		{
			SDK::minecraft->gameSettings->SetUseItemPressed(false);
		}
		catch (...)
		{
		}
		m_flashKeyHeld = false;
		return;
	}

	m_flashKeyHeld = false;
	if (!Menu::handleWindow)
		return;

	POINT cursor{};
	GetCursorPos(&cursor);
	ScreenToClient(Menu::handleWindow, &cursor);
	PostMessage(Menu::handleWindow, WM_RBUTTONUP, 0, MAKELPARAM(cursor.x, cursor.y));
}

void AutoFlashStab::AttackClick()
{
	if (StrayCache::minecraft_clickMouse && SDK::minecraft->GetInstance())
	{
		try
		{
			SDK::minecraft->ClickMouse();
			if (Java::env->ExceptionCheck())
				Java::ClearException();
		}
		catch (...)
		{
		}
	}

	if (!Menu::handleWindow)
		return;

	POINT cursor{};
	GetCursorPos(&cursor);
	ScreenToClient(Menu::handleWindow, &cursor);
	const LPARAM lp = MAKELPARAM(cursor.x, cursor.y);
	PostMessage(Menu::handleWindow, WM_LBUTTONDOWN, MK_LBUTTON, lp);
	PostMessage(Menu::handleWindow, WM_LBUTTONUP, 0, lp);
}

bool AutoFlashStab::FireKeyPressedOnce()
{
	if (settings::AFS_Key == 0)
		return false;

	const bool down = (GetAsyncKeyState(settings::AFS_Key) & 0x8000) != 0;
	const bool pressed = down && !m_fireKeyWasDown;
	m_fireKeyWasDown = down;
	return pressed;
}

void AutoFlashStab::AbortCombo(const char* reason)
{
	if (m_flashKeyHeld)
		FlashUp();

	const int restore = m_restoreSlot;
	m_phase = Phase::Idle;
	m_nextPhaseAt = 0;
	m_flashArmedAt = 0;
	m_triggerUntil = 0;
	m_axeSlot = -1;
	m_restoreSlot = -1;
	m_preFlashDist = 0.0;
	m_closestDist = 999.0;
	m_targetName.clear();
	m_flashKeyHeld = false;
	m_status = "ready";

	if (reason)
		m_lastResult = reason;

	if (settings::AFS_RestoreSlot && restore >= 0 && restore <= 8
		&& CommonData::SanityCheck())
	{
		SelectHotbarSlot(restore);
	}
}

void AutoFlashStab::FinishCombo()
{
	m_phase = Phase::Idle;
	m_nextPhaseAt = 0;
	m_flashArmedAt = 0;
	m_triggerUntil = 0;
	m_axeSlot = -1;
	m_restoreSlot = -1;
	m_preFlashDist = 0.0;
	m_targetName.clear();
	m_flashKeyHeld = false;
	m_status = "ready";
	m_cooldownUntil = NowMs() + COOLDOWN_MS;
}

void AutoFlashStab::StartCombo()
{
	const long long now = NowMs();
	if (now < m_cooldownUntil)
	{
		m_lastResult = "cooldown";
		return;
	}

	std::string name;
	double dist = 0.0;
	if (!FindTarget(name, dist))
	{
		m_lastResult = "no target (look at them)";
		return;
	}

	const int axe = FindAxeHotbarSlot();
	if (axe < 0)
	{
		m_lastResult = "no axe in hotbar";
		return;
	}

	int prev = 0;
	try
	{
		CInventoryPlayer inv = SDK::minecraft->thePlayer->GetInventory();
		prev = inv.GetCurrentItemIndex();
	}
	catch (...)
	{
		prev = 0;
	}

	m_restoreSlot = prev;
	m_axeSlot = axe;
	m_targetName = name;
	m_preFlashDist = dist;
	m_closestDist = 999.0;
	m_lastResult = "running vs " + name;
	m_status = "switching axe";

	SelectHotbarSlot(axe);

	m_phase = Phase::SwitchAxe;
	m_nextPhaseAt = now + SLOT_MS;
}

void AutoFlashStab::TickCombo(long long now)
{
	switch (m_phase)
	{
	case Phase::SwitchAxe:
		if (now < m_nextPhaseAt)
			return;
		SelectHotbarSlot(m_axeSlot);
		m_status = "flashing + triggerbot";
		FlashDown();
		// Arm triggerbot immediately — flash travel time varies, so we click
		// the first moment we're inside their hitbox, not on a fixed delay.
		m_flashArmedAt = now + settings::AFS_MinArm;
		m_triggerUntil = now + settings::AFS_Timeout;
		m_phase = Phase::FlashPress;
		m_nextPhaseAt = now + FLASH_HOLD_MS;
		break;

	case Phase::FlashPress:
		// Keep polling proximity while RMB is down — teleport can land mid-hold.
		if (now >= m_flashArmedAt)
		{
			const double d = LiveTargetDist();
			if (d >= 0.0 && d < m_closestDist)
				m_closestDist = d;
			if (d >= 0.0 && d <= static_cast<double>(settings::AFS_HitProximity))
			{
				FlashUp();
				AttackClick();
				char buf[96];
				std::snprintf(buf, sizeof(buf), "hit %s @ %.2f", m_targetName.c_str(), d);
				m_lastResult = buf;
				m_status = settings::AFS_RestoreSlot ? "restoring slot" : "done";
				m_phase = Phase::RestoreSlot;
				m_nextPhaseAt = now + HIT_SETTLE_MS;
				return;
			}
		}

		if (now < m_nextPhaseAt)
			return;

		FlashUp();
		m_status = "triggerbot (inside them)";
		m_phase = Phase::TriggerBot;
		break;

	case Phase::TriggerBot:
	{
		if (now > m_triggerUntil)
		{
			char buf[96];
			std::snprintf(buf, sizeof(buf), "timeout (closest %.2f)", m_closestDist);
			AbortCombo(buf);
			m_cooldownUntil = now + COOLDOWN_MS;
			return;
		}

		if (now < m_flashArmedAt)
			return;

		const double d = LiveTargetDist();
		if (d < 0.0)
		{
			AbortCombo("target lost");
			return;
		}
		if (d < m_closestDist)
			m_closestDist = d;

		char status[64];
		std::snprintf(status, sizeof(status), "triggerbot dist %.2f", d);
		m_status = status;

		// Inside / overlapping their BB → flashstab hit.
		if (d <= static_cast<double>(settings::AFS_HitProximity))
		{
			AttackClick();
			char buf[96];
			std::snprintf(buf, sizeof(buf), "hit %s @ %.2f", m_targetName.c_str(), d);
			m_lastResult = buf;
			m_status = settings::AFS_RestoreSlot ? "restoring slot" : "done";
			m_phase = Phase::RestoreSlot;
			m_nextPhaseAt = now + HIT_SETTLE_MS;
		}
		break;
	}

	case Phase::RestoreSlot:
		if (now < m_nextPhaseAt)
			return;
		if (settings::AFS_RestoreSlot && m_restoreSlot >= 0 && m_restoreSlot <= 8)
			SelectHotbarSlot(m_restoreSlot);
		FinishCombo();
		break;

	default:
		AbortCombo("bad phase");
		break;
	}
}

void AutoFlashStab::Update()
{
	if (!settings::AFS_Enabled)
	{
		if (m_phase != Phase::Idle)
			AbortCombo("disabled");
		m_fireKeyWasDown = false;
		return;
	}

	if (!CommonData::SanityCheck())
	{
		if (m_phase != Phase::Idle)
			AbortCombo("not in world");
		return;
	}

	try
	{
		const long long now = NowMs();

		if (Menu::open || SDK::minecraft->IsInGuiState())
		{
			if (m_phase != Phase::Idle)
				AbortCombo("gui open");
			m_fireKeyWasDown = false;
			return;
		}

		if (m_phase != Phase::Idle)
		{
			TickCombo(now);
			return;
		}

		if (FireKeyPressedOnce())
			StartCombo();
	}
	catch (...)
	{
		if (Java::env && Java::env->ExceptionCheck())
			Java::ClearException();
		AbortCombo("exception");
	}
}

void AutoFlashStab::RenderMenu()
{
	Menu::BoldText("Auto-Flash Stab", FontSize::SIZE_22);
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.f);

	Menu::Checkbox("Enabled", &settings::AFS_Enabled);
	Menu::KeybindButton("Flashstab Key (press once)", settings::AFS_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AFS_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Text("Press once: switch axe -> right-click Flash, then a", FontSize::SIZE_14);
	Menu::Text("triggerbot left-clicks the moment you are inside them", FontSize::SIZE_14);
	Menu::Text("(~0.1 blocks). Timing is proximity, not a fixed delay.", FontSize::SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AFS_Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Flash Range", &settings::AFS_FlashRange, 1.0f, 6.0f);
	Menu::Slider("FOV", &settings::AFS_Fov, 5.0f, 120.0f);
	Menu::Slider("Hit Proximity", &settings::AFS_HitProximity, 0.05f, 0.75f);
	Menu::Slider("Min Arm (ms)", &settings::AFS_MinArm, 0, 100);
	Menu::Slider("Timeout (ms)", &settings::AFS_Timeout, 200, 2000);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AFS_Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Restore Hotbar Slot", &settings::AFS_RestoreSlot);
	Menu::Checkbox("Ignore Friends", &settings::AFS_IgnoreFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("AFS_Sep4");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::TextColored(m_status.c_str(),
		m_phase == Phase::Idle ? ImVec4(0.7f, 0.7f, 0.7f, 1.f) : ImVec4(0.3f, 1.f, 0.3f, 1.f),
		FontSize::SIZE_16);

	if (!m_lastResult.empty())
		Menu::Text(m_lastResult.c_str(), FontSize::SIZE_14);

	if (m_phase == Phase::TriggerBot || m_phase == Phase::FlashPress)
	{
		char buf[64];
		std::snprintf(buf, sizeof(buf), "Closest this flash: %.2f", m_closestDist);
		Menu::Text(buf, FontSize::SIZE_14);
	}
}
