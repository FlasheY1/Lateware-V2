#pragma once

#include <string>

#include "moduleManager/moduleBase.h"

// Auto-uses a hotbar water bottle when selected debuffs are active.
// Mineplex bottles share a ~5s cooldown after use. Silence is chat-detected.
// Anti-Void Mage skips bottling while Slowness III + Invisibility II (void mode).
class AutoBottle : public ModuleBase
{
public:
	void Update() override;
	void RenderOverlay() override {};
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::AB_Key; }

	bool IsEnabled() override { return settings::AB_Enabled; }
	void SetEnabled(bool enabled) override { settings::AB_Enabled = enabled; }
	void Toggle() override { settings::AB_Enabled = !settings::AB_Enabled; }

private:
	enum class Phase
	{
		Idle,
		Press,
		Hold,
		Release
	};

	bool NeedsBottle();
	void RefreshVoidMode(); // cheat-thread only — never call from RenderMenu
	bool PollSilenceFromChat();
	int FindWaterBottleSlot();
	bool IsWaterBottle(class CItemStack& stack);
	void StartUse(int slot);
	void TickUse();

	std::string m_name = "Auto Bottle";
	std::string m_category = "Combat";

	Phase m_phase = Phase::Idle;
	long long m_cooldownUntil = 0;
	long long m_holdUntil = 0;
	long long m_silenceUntil = 0;
	int m_prevSlot = 0;
	int m_bottleSlot = -1;

	// Cached on Update thread — RenderMenu must only read this (no JNI).
	bool m_voidMode = false;

	std::string m_lastChatLine;
	bool m_chatPrimed = false;

	// Vanilla 1.8 potion IDs
	static constexpr int POTION_SLOWNESS = 2;
	static constexpr int POTION_INVISIBILITY = 14;
	static constexpr int POTION_POISON = 19;
	static constexpr int POTION_BLINDNESS = 15;
	static constexpr int POTION_WITHER = 20;
	static constexpr int ITEM_POTION = 373;

	// Amplifiers are 0-indexed (I=0, II=1, III=2)
	static constexpr int AMP_SLOWNESS_III = 2;
	static constexpr int AMP_INVISIBILITY_II = 1;

	static constexpr long long SILENCE_ACTIVE_MS = 6000;
	static constexpr long long HOLD_MS = 120;
};
