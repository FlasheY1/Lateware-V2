#include "smokeBombEsp.h"

#include <cmath>
#include <vector>

#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "sdk/net/minecraft/client/particle/EffectRenderer.h"
#include "util/math/camera.h"

namespace
{
	// Vanilla player AABB (F3+B): 0.6 x 1.8, origin at feet.
	constexpr float kHalfW = 0.3f;
	constexpr float kMinY = 0.0f;
	constexpr float kMaxY = 1.8f;

	// Group nearby EntitySmokeFX into one cloud / one hitbox.
	constexpr float kClusterRadius = 2.0f;
	constexpr int kMinParticles = 3;
	constexpr int kMaxParticleAge = 12;
	constexpr int kMaxParticles = 256;

	const ImColor kHitboxRed(1.f, 0.f, 0.f, 1.f);
	constexpr float kLineThickness = 1.5f;

	float DistSq(const Vector3& a, const Vector3& b)
	{
		const float dx = a.x - b.x;
		const float dy = a.y - b.y;
		const float dz = a.z - b.z;
		return dx * dx + dy * dy + dz * dz;
	}

	struct SmokeCloud
	{
		Vector3 feet{};
	};

	std::vector<SmokeCloud> ClusterSmoke(const std::vector<Vector3>& smoke)
	{
		std::vector<SmokeCloud> clouds;
		std::vector<char> used(smoke.size(), 0);
		const float rSq = kClusterRadius * kClusterRadius;

		for (size_t i = 0; i < smoke.size(); ++i)
		{
			if (used[i])
				continue;

			float sumX = 0.f, sumZ = 0.f, minY = smoke[i].y;
			int count = 0;

			for (size_t j = i; j < smoke.size(); ++j)
			{
				if (used[j])
					continue;
				if (DistSq(smoke[i], smoke[j]) > rSq)
					continue;

				used[j] = 1;
				sumX += smoke[j].x;
				sumZ += smoke[j].z;
				minY = fminf(minY, smoke[j].y);
				++count;
			}

			if (count < kMinParticles)
				continue;

			SmokeCloud c{};
			c.feet = Vector3{ sumX / (float)count, minY, sumZ / (float)count };
			clouds.push_back(c);
		}
		return clouds;
	}

	void FillPlayerHitbox(const Vector3& feet, const Vector3& camera, Vector3 out[8])
	{
		const float x = feet.x - camera.x;
		const float y = feet.y - camera.y;
		const float z = feet.z - camera.z;

		out[0] = Vector3{ x - kHalfW, y + kMinY, z - kHalfW };
		out[1] = Vector3{ x - kHalfW, y + kMaxY, z - kHalfW };
		out[2] = Vector3{ x + kHalfW, y + kMaxY, z - kHalfW };
		out[3] = Vector3{ x + kHalfW, y + kMinY, z - kHalfW };
		out[4] = Vector3{ x - kHalfW, y + kMinY, z + kHalfW };
		out[5] = Vector3{ x - kHalfW, y + kMaxY, z + kHalfW };
		out[6] = Vector3{ x + kHalfW, y + kMaxY, z + kHalfW };
		out[7] = Vector3{ x + kHalfW, y + kMinY, z + kHalfW };
	}
}

void SmokeBombEsp::Update()
{
	if (!settings::SBESP_Enabled)
	{
		NativeGuard lock(m_mutex);
		m_renderData.clear();
		return;
	}

	if (!CommonData::SanityCheck() || !CommonData::dataUpdated)
		return;

	try
	{
		const Vector3 camera = CommonData::renderPos;
		const Vector3 localPos = CommonData::playerPos;
		const float maxDistSq = settings::SBESP_MaxDistance * settings::SBESP_MaxDistance;

		const std::vector<Vector3> smoke = CEffectRenderer::GetSmokePositions(kMaxParticleAge, kMaxParticles);
		const std::vector<SmokeCloud> clouds = ClusterSmoke(smoke);

		std::vector<RenderData> newRender;
		newRender.reserve(clouds.size());

		for (const SmokeCloud& cloud : clouds)
		{
			if (DistSq(localPos, cloud.feet) > maxDistSq)
				continue;

			RenderData data{};
			FillPlayerHitbox(cloud.feet, camera, data.corners);
			newRender.push_back(data);
		}

		NativeGuard lock(m_mutex);
		m_renderData = std::move(newRender);
	}
	catch (...)
	{
		NativeGuard lock(m_mutex);
		m_renderData.clear();
	}
}

void SmokeBombEsp::RenderOverlay()
{
	if (!settings::SBESP_Enabled || !CommonData::dataUpdated)
		return;

	ImDrawList* draw = ImGui::GetWindowDrawList();
	if (!draw)
		return;

	const ImVec2 screenSize = ImGui::GetWindowSize();
	if (screenSize.x < 1.f || screenSize.y < 1.f)
		return;

	std::vector<RenderData> renderData;
	{
		NativeGuard lock(m_mutex);
		renderData = m_renderData;
	}

	static const int edges[][2] = {
		{0,1},{1,2},{2,3},{3,0},
		{4,5},{5,6},{6,7},{7,4},
		{0,4},{1,5},{2,6},{3,7},
	};

	for (const RenderData& data : renderData)
	{
		Vector2 projected[8]{};
		bool ok[8]{};

		for (int i = 0; i < 8; ++i)
		{
			Vector2 p;
			if (!CameraUtils::WorldToScreen(data.corners[i], CommonData::modelView, CommonData::projection,
				(int)screenSize.x, (int)screenSize.y, p))
				continue;
			ok[i] = true;
			projected[i] = p;
		}

		// ImGui overlay has no depth test, so the box is visible through walls.
		for (const auto& e : edges)
		{
			if (!ok[e[0]] || !ok[e[1]])
				continue;
			draw->AddLine(
				ImVec2(projected[e[0]].x, projected[e[0]].y),
				ImVec2(projected[e[1]].x, projected[e[1]].y),
				kHitboxRed, kLineThickness);
		}
	}
}

void SmokeBombEsp::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::SBESP_Enabled, settings::SBESP_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("SBESP_Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Max Distance", &settings::SBESP_MaxDistance, 10.f, 128.f);
}
