#pragma once

#include "util/nativeLock.h"
#include <string>
#include <vector>

#include "moduleManager/moduleBase.h"
#include "util/math/geometry.h"

// Trace Mineplex Assassin Smoke Bomb particles with a vanilla player hitbox (red, through walls).
class SmokeBombEsp : public ModuleBase
{
public:
	void Update() override;

	void RenderOverlay() override;
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::SBESP_Key; }

	bool IsEnabled() override { return settings::SBESP_Enabled; }
	void SetEnabled(bool enabled) override { settings::SBESP_Enabled = enabled; }
	void Toggle() override { settings::SBESP_Enabled = !settings::SBESP_Enabled; }

private:
	std::string m_name = "SmokeBomb ESP";
	std::string m_category = "Visual";

	struct RenderData
	{
		Vector3 corners[8]{}; // vanilla player AABB, camera-relative
	};

	NativeLock m_mutex;
	std::vector<RenderData> m_renderData;
};
