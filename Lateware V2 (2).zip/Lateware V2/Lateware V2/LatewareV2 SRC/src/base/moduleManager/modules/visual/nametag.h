#pragma once

#include "util/nativeLock.h"
#include <string>
#include <unordered_map>
#include <vector>

#include "moduleManager/moduleBase.h"
#include "util/math/geometry.h"

class Nametag : public ModuleBase
{
public:
	void Update() override;

	void RenderOverlay() override;
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::NT_Key; }

	bool IsEnabled() override { return settings::NT_Enabled; }
	void SetEnabled(bool enabled) override { settings::NT_Enabled = enabled; }
	void Toggle() override { settings::NT_Enabled = !settings::NT_Enabled; }

private:
	std::string m_name = "Nametags";
	std::string m_category = "Visual";

	struct Data
	{
		Vector3 headRel;
		std::string name;
		std::string distText;
		std::string healthText;
		std::string invisibleText;
		float dist = 0.f;
		float opacityFadeFactor = 1.f;

		// Display order: helm, chest, legs, boots. -1 = empty.
		int armorIds[4]{ -1, -1, -1, -1 };
		int heldId = -1;
		int heldCount = 0;
	};

	struct GearCache
	{
		int armorIds[4]{ -1, -1, -1, -1 };
		int heldId = -1;
		int heldCount = 0;
		long long checkedAt = 0;
	};

	NativeLock m_mutex;
	std::vector<Data> m_nametagData;
	std::unordered_map<std::string, GearCache> m_gearCache;

	static constexpr long long GEAR_CACHE_MS = 300;
};
