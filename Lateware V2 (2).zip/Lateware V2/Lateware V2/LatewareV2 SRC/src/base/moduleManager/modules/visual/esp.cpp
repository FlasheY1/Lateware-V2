#include "esp.h"

#include <cfloat>
#include <cmath>

#include "moduleManager/commonData.h"
#include "sdk/sdk.h"
#include "util/math/camera.h"
#include "menu/menu.h"
#include "configManager/configManager.h"

namespace
{
	// Camera-relative interpolated point: (last + (pos-last)*pt) - camera
	Vector3 Rel(const Vector3& pos, const Vector3& last, const Vector3& camera, float pt, float ox, float oy, float oz)
	{
		const float ix = last.x + (pos.x - last.x) * pt;
		const float iy = last.y + (pos.y - last.y) * pt;
		const float iz = last.z + (pos.z - last.z) * pt;
		return Vector3{ ix + ox - camera.x, iy + oy - camera.y, iz + oz - camera.z };
	}
}

void Esp::Update()
{
	if (!settings::ESP_Enabled) return;
	if (!CommonData::SanityCheck()) return;

	std::vector<CommonData::PlayerData> playerList = CommonData::nativePlayerList;
	if (playerList.empty()) return;

	// Raw RenderManager camera — no invented Y bias.
	const Vector3 camera = CommonData::renderPos;
	const Vector3 localPos = CommonData::playerPos;
	const float pt = CommonData::renderPartialTicks;

	std::vector<Data> newData;
	newData.reserve(playerList.size());
	for (const CommonData::PlayerData& entity : playerList)
	{
		if (!CommonData::playerName.empty() && entity.name == CommonData::playerName)
			continue;

		const Vector3 pos = entity.pos;
		const Vector3 last = entity.lastPos;

		const float dx = localPos.x - pos.x;
		const float dy = localPos.y - pos.y;
		const float dz = localPos.z - pos.z;
		const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
		if (dist > 300.f)
			continue;

		// Player hitbox extents (Dope / vanilla-ish)
		constexpr float halfW = 0.4f;
		constexpr float minY = -0.1f;
		constexpr float maxY = 1.72f;

		// 8 AABB corners in camera-relative space
		std::vector<Vector3> boundingBoxVerticies{
			Rel(pos, last, camera, pt, -halfW, minY, -halfW),
			Rel(pos, last, camera, pt, -halfW, maxY, -halfW),
			Rel(pos, last, camera, pt,  halfW, maxY, -halfW),
			Rel(pos, last, camera, pt,  halfW, minY, -halfW),
			Rel(pos, last, camera, pt, -halfW, minY,  halfW),
			Rel(pos, last, camera, pt, -halfW, maxY,  halfW),
			Rel(pos, last, camera, pt,  halfW, maxY,  halfW),
			Rel(pos, last, camera, pt,  halfW, minY,  halfW),
		};

		// Corner-2D uses a diamond of midpoints around the same AABB
		const float midY = (minY + maxY) * 0.5f;
		std::vector<Vector3> boxVerticies{
			Rel(pos, last, camera, pt, 0.f, minY, 0.f),          // feet
			Rel(pos, last, camera, pt, 0.f, maxY, 0.f),          // head
			Rel(pos, last, camera, pt, -halfW, midY, 0.f),
			Rel(pos, last, camera, pt,  halfW, midY, 0.f),
			Rel(pos, last, camera, pt, 0.f, midY, -halfW),
			Rel(pos, last, camera, pt, 0.f, midY,  halfW),
			Rel(pos, last, camera, pt, -halfW * 0.72f, midY, -halfW * 0.72f),
			Rel(pos, last, camera, pt,  halfW * 0.72f, midY,  halfW * 0.72f),
			Rel(pos, last, camera, pt,  halfW * 0.72f, midY, -halfW * 0.72f),
			Rel(pos, last, camera, pt, -halfW * 0.72f, midY,  halfW * 0.72f),
		};

		float fadeFactor = 1.0f;
		if ((dist - 1.f) <= settings::ESP_FadeDistance)
			fadeFactor = (dist - 1.f) / settings::ESP_FadeDistance;
		if (fadeFactor < 0.f) fadeFactor = 0.f;
		if (fadeFactor > 1.f) fadeFactor = 1.f;

		char distC[32];
		std::snprintf(distC, sizeof(distC), "%.1f", dist);

		newData.push_back(Data{
			std::move(boxVerticies),
			entity.name,
			std::string(distC) + "m",
			dist,
			fadeFactor,
			entity.health,
			entity.maxHealth,
			std::move(boundingBoxVerticies),
		});
	}
	{
		NativeGuard lock(m_mutex);
		m_renderData = std::move(newData);
	}
}

void Esp::RenderOverlay()
{
	if (!settings::ESP_Enabled || !CommonData::dataUpdated) return;

	std::vector<Data> renderData;
	{
		NativeGuard lock(m_mutex);
		renderData = m_renderData;
	}
	ImDrawList* draw = ImGui::GetWindowDrawList();
	if (!draw) return;

	const ImVec2 screenSize = ImGui::GetWindowSize();
	if (screenSize.x < 1.f || screenSize.y < 1.f) return;

	for (const Data& data : renderData)
	{
		float left = FLT_MAX;
		float top = FLT_MAX;
		float right = -FLT_MAX;
		float bottom = -FLT_MAX;
		int projected = 0;
		std::vector<Vector2> boxCorners;

		const std::vector<Vector3>& verts = (settings::ESP_BoxType == 0) ? data.boxVerticies : data.boundingBoxVerticies;

		for (const Vector3& position : verts)
		{
			Vector2 p;
			if (!CameraUtils::WorldToScreen(position, CommonData::modelView, CommonData::projection,
				(int)screenSize.x, (int)screenSize.y, p))
				continue;

			projected++;
			if (settings::ESP_BoxType == 1)
				boxCorners.push_back(p);
			left = fmin(p.x, left);
			top = fmin(p.y, top);
			right = fmax(p.x, right);
			bottom = fmax(p.y, bottom);
		}

		if (projected < 2 || !(left < right) || !(top < bottom))
			continue;

		// Reject nonsense screen boxes (projection garbage)
		const float boxW = right - left;
		const float boxH = bottom - top;
		if (boxW < 2.f || boxH < 2.f || boxW > screenSize.x * 1.5f || boxH > screenSize.y * 1.5f)
			continue;

		const bool IsFriend = configmanager::IsFriend(data.name) && settings::ESP_HighlightFriends;
		const float a = data.opacityFadeFactor;

		if (settings::ESP_BoxType == 0)
		{
			if (settings::ESP_FilledBox)
			{
				ImColor bottomColor = ImColor(settings::ESP_SecondFilledBoxColor[0], settings::ESP_SecondFilledBoxColor[1], settings::ESP_SecondFilledBoxColor[2], settings::ESP_SecondFilledBoxColor[3] * a);
				ImColor bottomColorFriend = ImColor(settings::ESP_FriendSecondFilledBoxColor[0], settings::ESP_FriendSecondFilledBoxColor[1], settings::ESP_FriendSecondFilledBoxColor[2], settings::ESP_FriendSecondFilledBoxColor[3] * a);
				ImColor topColor = ImColor(settings::ESP_FilledBoxColor[0], settings::ESP_FilledBoxColor[1], settings::ESP_FilledBoxColor[2], settings::ESP_FilledBoxColor[3] * a);
				ImColor topColorFriend = ImColor(settings::ESP_FriendFilledBoxColor[0], settings::ESP_FriendFilledBoxColor[1], settings::ESP_FriendFilledBoxColor[2], settings::ESP_FriendFilledBoxColor[3] * a);

				draw->AddRectFilledMultiColor(
					ImVec2(left, top), ImVec2(right, bottom),
					IsFriend ? topColorFriend : topColor,
					IsFriend ? topColorFriend : topColor,
					IsFriend ? bottomColorFriend : bottomColor,
					IsFriend ? bottomColorFriend : bottomColor);
			}

			if (settings::ESP_Box || settings::ESP_Outline)
			{
				ImColor boxCol = ImColor(settings::ESP_BoxColor[0], settings::ESP_BoxColor[1], settings::ESP_BoxColor[2], settings::ESP_BoxColor[3] * a);
				ImColor boxColFriend = ImColor(settings::ESP_FriendBoxColor[0], settings::ESP_FriendBoxColor[1], settings::ESP_FriendBoxColor[2], settings::ESP_FriendBoxColor[3] * a);
				ImColor outlineCol = ImColor(settings::ESP_OutlineColor[0], settings::ESP_OutlineColor[1], settings::ESP_OutlineColor[2], settings::ESP_OutlineColor[3] * a);
				ImColor outlineColFriend = ImColor(settings::ESP_FriendOutlineColor[0], settings::ESP_FriendOutlineColor[1], settings::ESP_FriendOutlineColor[2], settings::ESP_FriendOutlineColor[3] * a);

				const ImU32 col = IsFriend ? (ImU32)boxColFriend : (ImU32)boxCol;
				const ImU32 outline = IsFriend ? (ImU32)outlineColFriend : (ImU32)outlineCol;

				float corner = (boxW < boxH ? boxW : boxH) * 0.22f;
				if (corner < 6.f) corner = 6.f;
				if (corner > 14.f) corner = 14.f;
				const float thickness = 1.6f;

				auto drawCorner = [&](float x1, float y1, float x2, float y2, float x3, float y3)
				{
					if (settings::ESP_Outline)
					{
						draw->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), outline, thickness + 2.f);
						draw->AddLine(ImVec2(x2, y2), ImVec2(x3, y3), outline, thickness + 2.f);
					}
					if (settings::ESP_Box)
					{
						draw->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), col, thickness);
						draw->AddLine(ImVec2(x2, y2), ImVec2(x3, y3), col, thickness);
					}
				};

				drawCorner(left, top + corner, left, top, left + corner, top);
				drawCorner(right - corner, top, right, top, right, top + corner);
				drawCorner(left, bottom - corner, left, bottom, left + corner, bottom);
				drawCorner(right - corner, bottom, right, bottom, right, bottom - corner);
			}
		}
		else if (boxCorners.size() == 8)
		{
			if (settings::ESP_Outline)
			{
				ImColor colorOutline = ImColor(settings::ESP_OutlineColor[0], settings::ESP_OutlineColor[1], settings::ESP_OutlineColor[2], settings::ESP_OutlineColor[3] * a);
				ImColor colorOutlineFriend = ImColor(settings::ESP_FriendOutlineColor[0], settings::ESP_FriendOutlineColor[1], settings::ESP_FriendOutlineColor[2], settings::ESP_FriendOutlineColor[3] * a);
				const ImU32 c = IsFriend ? (ImU32)colorOutlineFriend : (ImU32)colorOutline;

				const int edges[][2] = {
					{0,1},{1,2},{2,3},{3,0},
					{4,5},{5,6},{6,7},{7,4},
					{0,4},{1,5},{2,6},{3,7},
				};
				for (const auto& e : edges)
					draw->AddLine(ImVec2(boxCorners[e[0]].x, boxCorners[e[0]].y), ImVec2(boxCorners[e[1]].x, boxCorners[e[1]].y), c, settings::ESP_3DBoxThickness);
			}

			if (settings::ESP_FilledBox)
			{
				ImColor colorFilledBox = ImColor(settings::ESP_FilledBoxColor[0], settings::ESP_FilledBoxColor[1], settings::ESP_FilledBoxColor[2], settings::ESP_FilledBoxColor[3] * a);
				ImColor colorFilledBoxFriend = ImColor(settings::ESP_FriendFilledBoxColor[0], settings::ESP_FriendFilledBoxColor[1], settings::ESP_FriendFilledBoxColor[2], settings::ESP_FriendFilledBoxColor[3] * a);
				const ImU32 c = IsFriend ? (ImU32)colorFilledBoxFriend : (ImU32)colorFilledBox;

				ImVec2 faceTop[] = { ImVec2(boxCorners[1].x, boxCorners[1].y), ImVec2(boxCorners[2].x, boxCorners[2].y), ImVec2(boxCorners[6].x, boxCorners[6].y), ImVec2(boxCorners[5].x, boxCorners[5].y) };
				ImVec2 faceBottom[] = { ImVec2(boxCorners[0].x, boxCorners[0].y), ImVec2(boxCorners[3].x, boxCorners[3].y), ImVec2(boxCorners[7].x, boxCorners[7].y), ImVec2(boxCorners[4].x, boxCorners[4].y) };
				draw->AddConvexPolyFilled(faceTop, 4, c);
				draw->AddConvexPolyFilled(faceBottom, 4, c);
			}
		}

		if (settings::ESP_HealthBar && data.maxHealth > 0.f)
		{
			float health = data.health;
			if (health < 0.f) health = 0.f;

			float scaleFactor = health / data.maxHealth;
			if (scaleFactor < 0.f) scaleFactor = 0.f;
			if (scaleFactor > 1.f) scaleFactor = 1.f;

			const float barLeft = left - 5.f;
			const float barRight = left - 2.f;
			const float height = bottom - top;

			draw->AddRectFilled(ImVec2(barLeft, top), ImVec2(barRight, bottom), ImColor(0.f, 0.f, 0.f, 0.45f * a), 2.f);
			const float filledTop = bottom - (height * scaleFactor);
			float r = 1.f - scaleFactor;
			float g = scaleFactor * 0.85f + 0.15f;
			draw->AddRectFilled(ImVec2(barLeft, filledTop), ImVec2(barRight, bottom), ImColor(r, g, 0.18f, a), 2.f);
		}
	}
}

void Esp::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::ESP_Enabled, settings::ESP_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Fade Distance", &settings::ESP_FadeDistance, 0.0f, 10.0f);
	Menu::Checkbox("Show Healthbar", &settings::ESP_HealthBar);
	Menu::Checkbox("Highlight Friends", &settings::ESP_HighlightFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Filled Box", &settings::ESP_FilledBox);
	if (settings::ESP_FilledBox)
	{
		Menu::ColorEdit("Filled Box Color", settings::ESP_FilledBoxColor);
		if (settings::ESP_BoxType == 0)
			Menu::ColorEdit("Second Filled Box Color", settings::ESP_SecondFilledBoxColor);
		if (settings::ESP_HighlightFriends)
		{
			Menu::ColorEdit("Friend Filled Box Color", settings::ESP_FriendFilledBoxColor);
			if (settings::ESP_BoxType == 0)
				Menu::ColorEdit("Friend Second Filled Box Color", settings::ESP_FriendSecondFilledBoxColor);
		}
	}
	Menu::Checkbox("Outline", &settings::ESP_Outline);
	if (settings::ESP_Outline)
	{
		Menu::ColorEdit("Outline Color", settings::ESP_OutlineColor);
		if (settings::ESP_HighlightFriends)
			Menu::ColorEdit("Friend Outline Color", settings::ESP_FriendOutlineColor);
	}
	Menu::Dropdown("Box Type", settings::ESP_BoxTypeList, &settings::ESP_BoxType, 2);
	if (settings::ESP_BoxType == 0)
	{
		Menu::Checkbox("Box", &settings::ESP_Box);
		if (settings::ESP_Box)
		{
			Menu::ColorEdit("Box Color", settings::ESP_BoxColor);
			if (settings::ESP_HighlightFriends)
				Menu::ColorEdit("Friend Box Color", settings::ESP_FriendBoxColor);
		}
	}
	else if (settings::ESP_BoxType == 1)
	{
		Menu::Slider("Box Thickness", &settings::ESP_3DBoxThickness, 0.5f, 5.0f);
	}
}
