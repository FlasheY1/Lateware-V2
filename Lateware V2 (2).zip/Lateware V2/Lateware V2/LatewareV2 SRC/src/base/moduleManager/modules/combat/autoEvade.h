#pragma once

#include <atomic>
#include <string>
#include <unordered_map>
#include <vector>

#include "moduleManager/moduleBase.h"
#include "sdk/net/minecraft/item/ItemStack.h"
#include "util/math/geometry.h"

// Automates Mineplex Assassin Evade from nearby threats + server chat.
class AutoEvade : public ModuleBase
{
public:
	AutoEvade();

	void Update() override;
	void RenderOverlay() override {};
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::AutoE_Key; }

	bool IsEnabled() override { return settings::AutoE_Enabled; }
	void SetEnabled(bool enabled) override
	{
		settings::AutoE_Enabled = enabled;
		if (!enabled) ReleaseBlock();
	}
	void Toggle() override
	{
		settings::AutoE_Enabled = !settings::AutoE_Enabled;
		if (!settings::AutoE_Enabled) ReleaseBlock();
	}

	static bool ShouldPauseClicker();
	static void ReleaseBlock();
	static void TickDisabled();
	static bool ShouldUseFastLoop();

private:
	enum class EvadeResult { NONE, SUCCESS, FAILED };
	enum class ChatEvent { NONE, PREPARED, USED, FAILED, IN_WATER };

	bool IsLeatherPiece(CItemStack& stack, int expectedId);
	bool IsSelfWearingFullLeather();
	bool IsHoldingWeapon();
	bool IsAttackerFacingMe(const Vector3& attackerEye, const Vector2& attackerAngles, const Vector3& myCenter);

	static bool ChatMonitoringAvailable();
	static std::vector<std::string> GetChatLines(int maxCount);
	ChatEvent PollChatEvent();

	void StartBlock();
	void StopBlock();
	void SetBlockHeld(bool held);
	void SetBlockHeld(JNIEnv* env, bool held);

	// Prediction scan: rapid hits / look-only after successes / anti-walkback.
	bool ScanCombatThreats(long long now, bool tookDamageRecently);
	bool LookOnlyMode() const;

	void OnEvadeSuccess();
	void OnEvadeFailed();

	std::string m_name = "Auto Evade";
	std::string m_category = "Combat";

	bool m_blocking = false;
	bool m_prepared = false;
	bool m_useKeyHeld = false;
	long long m_blockUntil = 0;
	long long m_cooldownUntil = 0;
	int m_lastHurtResistant = 0;
	long long m_lastDamageAt = 0;
	Vector3 m_lastPos = Vector3();

	std::string m_lastChatLine;
	std::string m_lastChatSnapshot;
	bool m_chatPrimed = false;
	long long m_nextChatPoll = 0;
	long long m_nextThreatScan = 0;

	bool m_cachedSelfLeather = false;
	bool m_cachedHoldingWeapon = false;
	long long m_nextSelfGearCheck = 0;

	struct ThreatTrack
	{
		bool wasSwinging = false;
		int hitCount = 0;               // opponent swing edges while facing us
		long long lastHitAt = 0;
		long long lastSwingEdgeAt = 0;  // last fresh attack (swing start while facing us)
		long long walkbackSince = 0;    // 0 = opponent not currently backpedaling at us
		long long lastWalkbackAt = 0;   // last scan where backpedal was observed
		bool walkbackBait = false;
	};
	std::unordered_map<std::string, ThreatTrack> m_threatTracks;

	int m_successfulEvades = 0;
	int m_evadeCounter = 0;            // 0 = next evade is "first" (gets First-Evade-offset)
	long long m_lastEvadeAt = 0;       // last StartBlock time; used to reset first-evade window
	long long m_firstEvadePendingUntil = 0; // deadline while waiting out First-Evade-offset
	int m_qualifyingAttackers = 0;
	int m_nearbyChecked = 0;
	int m_rapidHitPeak = 0;            // menu debug
	int m_baitingAttackers = 0;        // menu debug
	bool m_lookOnlyActive = false;
	EvadeResult m_lastResult = EvadeResult::NONE;
	ChatEvent m_lastChatEvent = ChatEvent::NONE;

	static inline AutoEvade* s_instance = nullptr;

	static constexpr int LEATHER_HELMET_ID = 298;
	static constexpr int LEATHER_CHESTPLATE_ID = 299;
	static constexpr int LEATHER_LEGGINGS_ID = 300;
	static constexpr int LEATHER_BOOTS_ID = 301;
	static constexpr float TELEPORT_DISTANCE = 2.0f;
	static constexpr long long CHAT_GRACE_MS = 750;
	static constexpr long long CHAT_POLL_MS = 50;
	static constexpr long long SELF_GEAR_CACHE_MS = 250;
	static constexpr long long THREAT_SCAN_MS = 12;
	static constexpr long long HIT_DECAY_MS = 900;      // reset hit streak if idle
	static constexpr long long NO_DAMAGE_WINDOW_MS = 350; // "hits sent but not taking damage"
	static constexpr long long SWING_FRESH_MS = 300;    // swing edge this recent = live attack
	static constexpr long long EVADE_RECHARGE_MS = 250; // Mineplex server-side success recharge
	static constexpr long long FIRST_EVADE_RESET_MS = 5000; // idle time before next evade is "first" again
	static constexpr float WALKBACK_MIN_MOVE = 0.015f;  // min blocks/tick to count as moving
	static constexpr float WALKBACK_BACKPEDAL_DOT = -0.35f; // moving opposite to own look = S-key
	static constexpr float WALKBACK_ADVANCE_DOT = 0.35f;    // moving with own look = advancing
	static constexpr long long WALKBACK_GAP_MS = 300;   // tolerated pause inside a walkback streak
};
