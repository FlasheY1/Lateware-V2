#pragma once

#include <string>

#include "moduleManager/commonData.h"
#include "moduleManager/moduleBase.h"
#include "util/math/geometry.h"

// Press-once Mineplex flashstab:
//   axe -> RMB Flash -> proximity triggerbot (click while inside them) -> restore.
// Hit timing is NOT a fixed delay — flash travel varies, so we triggerbot on range.
class AutoFlashStab : public ModuleBase
{
public:
	void Update() override;
	void RenderOverlay() override {};
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return 0; }

	bool IsEnabled() override { return settings::AFS_Enabled; }
	void SetEnabled(bool enabled) override
	{
		settings::AFS_Enabled = enabled;
		if (!enabled) AbortCombo("disabled");
	}
	void Toggle() override
	{
		settings::AFS_Enabled = !settings::AFS_Enabled;
		if (!settings::AFS_Enabled) AbortCombo("disabled");
	}

private:
	enum class Phase
	{
		Idle,
		SwitchAxe,
		FlashPress,   // RMB held; triggerbot already armed
		TriggerBot,   // watch live distance, click when inside them
		RestoreSlot,
	};

	static bool IsAxeId(int id);
	static long long NowMs();
	static double DistToBox(const Vector3& p, const BoundingBox& bb);

	int FindAxeHotbarSlot();
	bool FindTarget(std::string& nameOut, double& distOut);
	bool IsLookingAt(const Vector3& eye, const Vector2& look, const Vector3& pos, float height) const;
	// Live distance to tracked target hitbox (JNI), -1 if lost.
	double LiveTargetDist();

	void SelectHotbarSlot(int slot);
	void FlashDown();
	void FlashUp();
	void AttackClick();

	void StartCombo();
	void TickCombo(long long now);
	void FinishCombo();
	void AbortCombo(const char* reason);

	bool FireKeyPressedOnce();

	std::string m_name = "Auto-Flash Stab";
	std::string m_category = "Combat";

	Phase m_phase = Phase::Idle;
	long long m_nextPhaseAt = 0;
	long long m_flashArmedAt = 0;   // triggerbot can fire after MinArm
	long long m_triggerUntil = 0;   // timeout
	long long m_cooldownUntil = 0;

	int m_axeSlot = -1;
	int m_restoreSlot = -1;
	double m_preFlashDist = 0.0;
	double m_closestDist = 999.0;
	std::string m_targetName;

	bool m_flashKeyHeld = false;
	bool m_fireKeyWasDown = false;

	std::string m_status = "ready";
	std::string m_lastResult;

	static constexpr long long SLOT_MS = 50;
	static constexpr long long FLASH_HOLD_MS = 50;
	static constexpr long long HIT_SETTLE_MS = 30;
	static constexpr long long COOLDOWN_MS = 450;
};
