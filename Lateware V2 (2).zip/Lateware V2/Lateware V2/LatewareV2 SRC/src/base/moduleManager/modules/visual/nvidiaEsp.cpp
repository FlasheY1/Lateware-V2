#include "nvidiaEsp.h"

#include <cfloat>
#include <cmath>
#include <cstdio>

#include "configManager/configManager.h"
#include "configManager/settings.h"
#include "menu/menu.h"
#include "moduleManager/commonData.h"
#include "util/math/camera.h"
#include "util/render/nvidiaOverlay.h"

namespace
{
	Vector3 Rel(const Vector3& pos, const Vector3& last, const Vector3& camera, float pt, float ox, float oy, float oz)
	{
		const float ix = last.x + (pos.x - last.x) * pt;
		const float iy = last.y + (pos.y - last.y) * pt;
		const float iz = last.z + (pos.z - last.z) * pt;
		return Vector3{ ix + ox - camera.x, iy + oy - camera.y, iz + oz - camera.z };
	}

	NvidiaOverlay::Color Col(const float* c, float aMul)
	{
		return NvidiaOverlay::Color{ c[0], c[1], c[2], c[3] * aMul };
	}
}

void NvidiaEsp::SetEnabled(bool enabled)
{
	settings::DESP_Enabled = enabled;
	if (!enabled && m_wasEnabled)
	{
		NvidiaOverlay::RequestClear();
		m_wasEnabled = false;
	}
}

void NvidiaEsp::Toggle()
{
	SetEnabled(!settings::DESP_Enabled);
}

void NvidiaEsp::Update()
{
	if (!settings::DESP_Enabled)
	{
		NativeGuard lock(m_mutex);
		m_renderData.clear();
		return;
	}
	if (!CommonData::SanityCheck())
		return;

	const std::vector<CommonData::PlayerData> playerList = CommonData::nativePlayerList;
	if (playerList.empty())
	{
		NativeGuard lock(m_mutex);
		m_renderData.clear();
		return;
	}

	const Vector3 camera = CommonData::renderPos;
	const Vector3 localPos = CommonData::playerPos;
	const float pt = CommonData::renderPartialTicks;

	std::vector<Data> newData;
	newData.reserve(playerList.size());

	for (const CommonData::PlayerData& entity : playerList)
	{
		if (!CommonData::playerName.empty() && entity.name == CommonData::playerName)
			continue;
		if (entity.name.empty())
			continue;
		if (settings::DESP_IgnoreFriends && configmanager::IsFriend(entity.name))
			continue;

		const Vector3 pos = entity.pos;
		const Vector3 last = entity.lastPos;

		const float dx = localPos.x - pos.x;
		const float dy = localPos.y - pos.y;
		const float dz = localPos.z - pos.z;
		const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
		if (dist > settings::DESP_MaxDistance)
			continue;

		// 8 AABB corners only — enough for 2D bounds, cheaper than the old 10-point set.
		constexpr float halfW = 0.4f;
		constexpr float minY = -0.1f;
		constexpr float maxY = 1.72f;

		std::vector<Vector3> boxVerticies{
			Rel(pos, last, camera, pt, -halfW, minY, -halfW),
			Rel(pos, last, camera, pt, -halfW, maxY, -halfW),
			Rel(pos, last, camera, pt,  halfW, maxY, -halfW),
			Rel(pos, last, camera, pt,  halfW, minY, -halfW),
			Rel(pos, last, camera, pt, -halfW, minY,  halfW),
			Rel(pos, last, camera, pt, -halfW, maxY,  halfW),
			Rel(pos, last, camera, pt,  halfW, maxY,  halfW),
			Rel(pos, last, camera, pt,  halfW, minY,  halfW),
		};

		float fade = 1.f;
		if (settings::DESP_FadeDistance > 0.f && (dist - 1.f) <= settings::DESP_FadeDistance)
			fade = (dist - 1.f) / settings::DESP_FadeDistance;
		if (fade < 0.f) fade = 0.f;
		if (fade > 1.f) fade = 1.f;

		char distC[32];
		std::snprintf(distC, sizeof(distC), "%.1fm", dist);

		Data d;
		d.boxVerticies = std::move(boxVerticies);
		d.name = entity.name;
		d.distText = distC;
		d.dist = dist;
		d.opacityFadeFactor = fade;
		d.health = entity.health;
		d.maxHealth = entity.maxHealth;
		newData.push_back(std::move(d));
	}

	{
		NativeGuard lock(m_mutex);
		m_renderData = std::move(newData);
	}
}

void NvidiaEsp::RenderOverlay()
{
	if (!settings::DESP_Enabled)
	{
		if (m_wasEnabled)
		{
			NvidiaOverlay::RequestClear();
			m_wasEnabled = false;
		}
		return;
	}

	m_wasEnabled = true;

	if (!CommonData::dataUpdated || !Menu::handleWindow)
		return;

	// Cap how often we even build a draw list on the game thread.
	if (!NvidiaOverlay::ShouldSubmitFrame(settings::DESP_OverlayFps))
		return;

	RECT client{};
	if (!GetClientRect(Menu::handleWindow, &client))
		return;

	POINT tl{ client.left, client.top };
	POINT br{ client.right, client.bottom };
	ClientToScreen(Menu::handleWindow, &tl);
	ClientToScreen(Menu::handleWindow, &br);

	const int screenW = br.x - tl.x;
	const int screenH = br.y - tl.y;
	if (screenW < 2 || screenH < 2)
		return;

	std::vector<Data> renderData;
	{
		NativeGuard lock(m_mutex);
		renderData = m_renderData;
	}

	NvidiaOverlay::FrameSubmit frame;
	frame.gameHwnd = Menu::handleWindow;
	frame.screenX = tl.x;
	frame.screenY = tl.y;
	frame.width = screenW;
	frame.height = screenH;
	frame.maxFps = settings::DESP_OverlayFps;
	frame.cmds.reserve(renderData.size() * 3);

	const bool highlightFriends = settings::DESP_HighlightFriends;
	const float fontSize = 8.f * (settings::DESP_TextScale < 1 ? 1 : settings::DESP_TextScale);

	for (const Data& data : renderData)
	{
		float left = FLT_MAX;
		float top = FLT_MAX;
		float right = -FLT_MAX;
		float bottom = -FLT_MAX;
		int projected = 0;

		for (const Vector3& position : data.boxVerticies)
		{
			Vector2 p;
			if (!CameraUtils::WorldToScreen(position, CommonData::modelView, CommonData::projection,
				screenW, screenH, p))
				continue;

			projected++;
			left = fmin(p.x, left);
			top = fmin(p.y, top);
			right = fmax(p.x, right);
			bottom = fmax(p.y, bottom);
		}

		if (projected < 2 || !(left < right) || !(top < bottom))
			continue;

		const float boxW = right - left;
		const float boxH = bottom - top;
		if (boxW < 2.f || boxH < 2.f || boxW > screenW * 1.5f || boxH > screenH * 1.5f)
			continue;

		const float a = data.opacityFadeFactor;
		if (a <= 0.01f)
			continue;

		const bool isFriend = highlightFriends && configmanager::IsFriend(data.name);
		const float* boxColF = isFriend ? settings::DESP_FriendBoxColor : settings::DESP_BoxColor;
		const float* fillColF = isFriend ? settings::DESP_FriendFilledBoxColor : settings::DESP_FilledBoxColor;
		const float* nameColF = isFriend ? settings::DESP_FriendNameColor : settings::DESP_NameColor;

		if (settings::DESP_FilledBox)
		{
			NvidiaOverlay::DrawCmd fill{};
			fill.type = NvidiaOverlay::DrawCmd::Type::FillRect;
			fill.x0 = left; fill.y0 = top; fill.x1 = right; fill.y1 = bottom;
			fill.color = Col(fillColF, a);
			frame.cmds.push_back(std::move(fill));
		}

		if (settings::DESP_Box)
		{
			NvidiaOverlay::DrawCmd box{};
			box.type = NvidiaOverlay::DrawCmd::Type::CornerBox;
			box.x0 = left; box.y0 = top; box.x1 = right; box.y1 = bottom;
			box.thickness = 1.6f;
			box.color = Col(boxColF, a);
			box.hasOutline = settings::DESP_Outline;
			box.colorSecondary = NvidiaOverlay::Color{ 0.f, 0.f, 0.f, 0.75f * a };
			frame.cmds.push_back(std::move(box));
		}

		if (settings::DESP_HealthBar && data.maxHealth > 0.f)
		{
			float health = data.health;
			if (health < 0.f) health = 0.f;
			float scale = health / data.maxHealth;
			if (scale < 0.f) scale = 0.f;
			if (scale > 1.f) scale = 1.f;

			NvidiaOverlay::DrawCmd bar{};
			bar.type = NvidiaOverlay::DrawCmd::Type::HealthBar;
			bar.x0 = left - 5.f;
			bar.y0 = top;
			bar.x1 = left - 2.f;
			bar.y1 = bottom;
			bar.health01 = scale;
			bar.colorSecondary = NvidiaOverlay::Color{ 0.f, 0.f, 0.f, 0.55f * a };
			bar.color = NvidiaOverlay::Color{ 1.f - scale, scale * 0.85f + 0.15f, 0.18f, a };
			frame.cmds.push_back(std::move(bar));
		}

		if (settings::DESP_Nametags)
		{
			std::string label = data.name;
			if (settings::DESP_ShowDistance && !data.distText.empty())
				label += " " + data.distText;
			if (settings::DESP_ShowHealth && data.maxHealth > 0.f)
			{
				char hp[40];
				std::snprintf(hp, sizeof(hp), " [%.0f/%.0f]", data.health, data.maxHealth);
				label += hp;
			}

			NvidiaOverlay::DrawCmd tag{};
			tag.type = NvidiaOverlay::DrawCmd::Type::Nametag;
			tag.x0 = (left + right) * 0.5f;
			tag.y0 = top - (fontSize + 2.f) - 6.f;
			tag.fontSize = fontSize;
			tag.color = Col(nameColF, a);
			tag.hasBackground = settings::DESP_NameBackground;
			tag.bg = Col(settings::DESP_NameBackgroundColor, a);
			tag.text = std::move(label);
			frame.cmds.push_back(std::move(tag));
		}
	}

	// Non-blocking: worker thread owns D2D + UpdateLayeredWindow.
	NvidiaOverlay::SubmitFrame(std::move(frame));
}

void NvidiaEsp::RenderMenu()
{
	Menu::ToggleWithKeybind(&settings::DESP_Enabled, settings::DESP_Key);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("SepConn");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	if (NvidiaOverlay::IsConnected())
		Menu::TextColored("NVIDIA Overlay: Connected", ImVec4(0.35f, 0.95f, 0.55f, 1.f), SIZE_16);
	else
		Menu::TextColored("NVIDIA Overlay: Waiting / not found", ImVec4(1.f, 0.75f, 0.35f, 1.f), SIZE_16);

	Menu::Text("Drawing runs on a background thread so game FPS stays high.", SIZE_14);
	Menu::Slider("Overlay FPS Cap", &settings::DESP_OverlayFps, 15, 120);
	Menu::Text("Lower = more game FPS. 30 is recommended for high-refresh setups.", SIZE_14);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep1");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Checkbox("Boxes", &settings::DESP_Box);
	Menu::Checkbox("Filled Box", &settings::DESP_FilledBox);
	Menu::Checkbox("Outline", &settings::DESP_Outline);
	Menu::Checkbox("Health Bar", &settings::DESP_HealthBar);
	Menu::Checkbox("Nametags", &settings::DESP_Nametags);
	if (settings::DESP_Nametags)
	{
		Menu::Checkbox("Show Distance", &settings::DESP_ShowDistance);
		Menu::Checkbox("Show Health", &settings::DESP_ShowHealth);
		Menu::Checkbox("Name Background", &settings::DESP_NameBackground);
		Menu::Slider("Text Scale", &settings::DESP_TextScale, 1, 4);
	}

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep2");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::Slider("Max Distance", &settings::DESP_MaxDistance, 10.f, 300.f);
	Menu::Slider("Fade Distance", &settings::DESP_FadeDistance, 0.f, 20.f);
	Menu::Checkbox("Ignore Friends", &settings::DESP_IgnoreFriends);
	Menu::Checkbox("Highlight Friends", &settings::DESP_HighlightFriends);

	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);
	Menu::HorizontalSeparator("Sep3");
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.f);

	Menu::ColorEdit("Box Color", settings::DESP_BoxColor);
	Menu::ColorEdit("Filled Box Color", settings::DESP_FilledBoxColor);
	Menu::ColorEdit("Name Color", settings::DESP_NameColor);
	if (settings::DESP_NameBackground)
		Menu::ColorEdit("Name BG Color", settings::DESP_NameBackgroundColor);
	if (settings::DESP_HighlightFriends)
	{
		Menu::ColorEdit("Friend Box Color", settings::DESP_FriendBoxColor);
		Menu::ColorEdit("Friend Filled Color", settings::DESP_FriendFilledBoxColor);
		Menu::ColorEdit("Friend Name Color", settings::DESP_FriendNameColor);
	}
}
