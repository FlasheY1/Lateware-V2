#pragma once

#include "util/nativeLock.h"
#include <string>
#include <vector>

#include "moduleManager/moduleBase.h"
#include "util/math/geometry.h"

// Player boxes + nametags drawn on the NVIDIA GeForce Overlay window (D2D).
class NvidiaEsp : public ModuleBase
{
public:
	void Update() override;

	void RenderOverlay() override;
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::DESP_Key; }

	bool IsEnabled() override { return settings::DESP_Enabled; }
	bool AlwaysRenderOverlay() override { return true; }
	void SetEnabled(bool enabled) override;
	void Toggle() override;

private:
	std::string m_name = "NVIDIA ESP";
	std::string m_category = "Visual";

	struct Data
	{
		std::vector<Vector3> boxVerticies;
		std::string name;
		std::string distText;
		float dist = 0.f;
		float opacityFadeFactor = 1.f;
		float health = 0.f;
		float maxHealth = 0.f;
	};

	NativeLock m_mutex;
	std::vector<Data> m_renderData;
	bool m_wasEnabled = false;
};
