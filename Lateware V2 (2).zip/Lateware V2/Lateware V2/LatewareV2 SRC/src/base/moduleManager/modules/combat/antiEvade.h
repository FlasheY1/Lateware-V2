#pragma once

#include <string>
#include <unordered_map>

#include "moduleManager/moduleBase.h"
#include "sdk/net/minecraft/entity/player/EntityPlayer.h"
#include "sdk/net/minecraft/item/ItemStack.h"
#include "util/math/geometry.h"

// Pauses Left Auto Clicker while a nearby full-leather player is blocking
// during their ~1s Evade window. Friends are ignored.
class AntiEvade : public ModuleBase
{
public:
	AntiEvade();

	void Update() override;
	void RenderOverlay() override {};
	void RenderHud() override {};
	void RenderMenu() override;

	std::string GetName() override { return m_name; }
	std::string GetCategory() override { return m_category; }
	int GetKey() override { return settings::AE_Key; }

	bool IsEnabled() override { return settings::AE_Enabled; }
	void SetEnabled(bool enabled) override { settings::AE_Enabled = enabled; }
	void Toggle() override { settings::AE_Enabled = !settings::AE_Enabled; }

	static bool ShouldPauseClicker();

private:
	bool IsLeatherPiece(CItemStack& stack, int expectedId);
	bool IsWearingFullLeather(CEntityPlayer& entity);
	bool GetCachedFullLeather(const std::string& name, CEntityPlayer& entity, long long now);
	bool IsFacingPlayer(const Vector3& targetPos, float targetHeight, const Vector3& eyePos, const Vector2& lookAngles);

	std::string m_name = "Anti Evade";
	std::string m_category = "Combat";

	bool m_shouldPause = false;
	int m_blockingNearby = 0;
	int m_expiredBlockers = 0;
	int m_candidatesChecked = 0;

	std::unordered_map<std::string, long long> m_blockStart;

	struct LeatherCacheEntry
	{
		bool fullLeather = false;
		long long checkedAt = 0;
	};
	std::unordered_map<std::string, LeatherCacheEntry> m_leatherCache;

	static inline AntiEvade* s_instance = nullptr;

	static constexpr int LEATHER_HELMET_ID = 298;
	static constexpr int LEATHER_CHESTPLATE_ID = 299;
	static constexpr int LEATHER_LEGGINGS_ID = 300;
	static constexpr int LEATHER_BOOTS_ID = 301;

	// Armor rarely changes mid-fight; refresh every half-second.
	static constexpr long long LEATHER_CACHE_MS = 500;
};
