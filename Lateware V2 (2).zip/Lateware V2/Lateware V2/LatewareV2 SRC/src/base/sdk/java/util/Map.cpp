#include "Map.h"

#include "java/java.h"

template class Map<int, int>;
template class Map<std::string, int>;
template class Map<std::string, float>;

template<typename K, typename V>
Map<K, V>::Map(jobject jMap)
{
	this->instance = jMap;
	this->clazz = Java::class_Map;
	this->entrySet = nullptr;
	this->setClass = nullptr;
	this->iterator = nullptr;
	this->iteratorClass = nullptr;
	this->entrySetMethod = nullptr;
	this->iteratorMethod = nullptr;
	this->hasNextMethod = nullptr;
	this->nextMethod = nullptr;

	if (!Java::env || !jMap)
		return;

    entrySetMethod = Java::mid_Map_entrySet;
    if (!entrySetMethod && this->clazz)
        entrySetMethod = Java::env->GetMethodID(this->clazz, "entrySet", "()Ljava/util/Set;");
	if (!entrySetMethod)
		return;

    entrySet = Java::env->CallObjectMethod(jMap, entrySetMethod);
	if (Java::env->ExceptionCheck() || !entrySet)
	{
		Java::ClearException();
		entrySet = nullptr;
		return;
	}

    setClass = Java::env->GetObjectClass(entrySet);
    iteratorMethod = Java::env->GetMethodID(setClass, "iterator", "()Ljava/util/Iterator;");
    iterator = Java::env->CallObjectMethod(entrySet, iteratorMethod);
	if (Java::env->ExceptionCheck() || !iterator)
	{
		Java::ClearException();
		iterator = nullptr;
		return;
	}

    iteratorClass = Java::env->GetObjectClass(iterator);
    hasNextMethod = Java::env->GetMethodID(iteratorClass, "hasNext", "()Z");
    nextMethod = Java::env->GetMethodID(iteratorClass, "next", "()Ljava/lang/Object;");
}

template<typename K, typename V>
Map<K, V>::~Map()
{
    // clazz is a cached global ref
    Java::DeleteLocal(setClass);
    Java::DeleteLocal(iteratorClass);
    Java::DeleteLocal(entrySet);
    Java::DeleteLocal(iterator);
}

template<typename K, typename V>
jclass Map<K, V>::GetClass()
{
    return this->clazz;
}

template<typename K, typename V>
jobject Map<K, V>::GetInstance()
{
    return this->instance;
}

template<typename K, typename V>
std::map<K, V> Map<K, V>::ToMap()
{
    std::map<K, V> cppMap;
	if (!Java::env || !iterator || !hasNextMethod || !nextMethod)
		return cppMap;

    jclass entryClass = nullptr;
    jmethodID getKeyMethod = nullptr;
    jmethodID getValueMethod = nullptr;

    while (Java::env->CallBooleanMethod(iterator, hasNextMethod))
    {
        jobject entry = Java::env->CallObjectMethod(iterator, nextMethod);

        if (!entryClass)
        {
            entryClass = Java::env->GetObjectClass(entry);
            getKeyMethod = Java::env->GetMethodID(entryClass, "getKey", "()Ljava/lang/Object;");
            getValueMethod = Java::env->GetMethodID(entryClass, "getValue", "()Ljava/lang/Object;");
        }

        jobject key = Java::env->CallObjectMethod(entry, getKeyMethod);
        jobject value = Java::env->CallObjectMethod(entry, getValueMethod);

        cppMap[Java::Convert<K>(key)] = Java::Convert<V>(value);

        Java::env->DeleteLocalRef(entry);
        Java::env->DeleteLocalRef(key);
        Java::env->DeleteLocalRef(value);
    }

    if (entryClass) Java::env->DeleteLocalRef(entryClass);

    return cppMap;
}