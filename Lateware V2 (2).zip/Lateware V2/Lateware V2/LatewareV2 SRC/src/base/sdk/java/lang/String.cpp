#include "String.h"

#include "java/java.h"

String::String(jobject instance)
{
	this->clazz = Java::class_String;
	this->instance = instance;
}

String::~String()
{
	// clazz is a cached global ref
}

String::String(std::string text)
{
	this->clazz = Java::class_String;
	this->instance = Java::env ? (jobject)Java::env->NewStringUTF(text.c_str()) : nullptr;
}

jclass String::GetClass()
{
	return this->clazz;
}

jobject String::GetInstance()
{
	return this->instance;
}

std::string String::ToString()
{
	return Java::JStringToStd((jstring)this->instance);
}
