#include "List.h"

#include "java/java.h"

List::List(jobject jlist)
{
	this->instance = jlist;
	this->clazz = Java::class_List;
	toArrayId = Java::mid_List_toArray;
}

List::~List()
{
	// clazz is a cached global ref
}

jclass List::GetClass()
{
	return this->clazz;
}

jobject List::GetInstance()
{
	return this->instance;
}

jobjectArray List::toArray()
{
	if (!Java::env || !this->instance || !toArrayId)
		return nullptr;

	jobjectArray arr = (jobjectArray)Java::env->CallObjectMethod(this->GetInstance(), toArrayId);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return arr;
}
