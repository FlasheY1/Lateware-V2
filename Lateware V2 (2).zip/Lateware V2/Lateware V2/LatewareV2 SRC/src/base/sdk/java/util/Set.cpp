#include "Set.h"

#include "java/java.h"

Set::Set(jobject jset)
{
	this->instance = jset;
	this->clazz = Java::class_Set;
	toArrayId = Java::mid_Set_toArray;
}

Set::~Set()
{
	// clazz is a cached global ref
}

jclass Set::GetClass()
{
	return this->clazz;
}

jobject Set::GetInstance()
{
	return this->instance;
}

jobjectArray Set::toArray()
{
	if (!Java::env || !this->instance || !toArrayId)
		return nullptr;

	jobjectArray arr = (jobjectArray)Java::env->CallObjectMethod(this->instance, toArrayId);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return arr;
}
