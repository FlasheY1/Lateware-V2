#include "sdk.h"

#include "util/logger.h"
#include "java/java.h"
#include "strayCache.h"

void SDK::Init()
{
	StrayCache::Init();
	Java::ClearException();
	LOG_INFO("Stray cache initialized");

	if (!StrayCache::minecraft_class || !StrayCache::minecraft_getMinecraft)
	{
		LOG_ERROR("Critical Minecraft JNI mappings missing — aborting SDK init");
		Java::ClearException();
		SDK::minecraft = nullptr;
		return;
	}

	SDK::minecraft = new CMinecraft();
	LOG_INFO("Initialized Minecraft");
}

void SDK::Shutdown()
{
	if (SDK::minecraft)
	{
		if (jobject mc = SDK::minecraft->GetInstance())
		{
			if (Java::env)
				Java::env->DeleteGlobalRef(mc);
		}
		delete SDK::minecraft;
		SDK::minecraft = nullptr;
	}
	StrayCache::DeleteRefs();
}
