#include "WorldClient.h"

#include "sdk/sdk.h"
#include "sdk/java/util/Set.h"
#include "java/java.h"
#include "util/logger.h"

CWorldClient::CWorldClient()
{
	this->clazz = StrayCache::worldClient_class;
}

jclass CWorldClient::GetClass()
{
	return this->clazz;
}

jobject CWorldClient::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;
	jobject mc = SDK::minecraft->GetInstance();
	if (!mc || !StrayCache::minecraft_theWorld)
		return nullptr;
	jobject world = Java::env->GetObjectField(mc, StrayCache::minecraft_theWorld);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return world;
}

std::vector<CEntity> CWorldClient::GetEntityList()
{
	std::vector<CEntity> finalList;
	jobject world = this->GetInstance();
	if (!world || !Java::env || !StrayCache::worldClient_entityList)
		return finalList;

	jobject playerEntitiesList = Java::env->GetObjectField(world, StrayCache::worldClient_entityList);
	Java::DeleteLocal(world);
	if (Java::env->ExceptionCheck() || !playerEntitiesList)
	{
		Java::ClearException();
		return finalList;
	}

	jobjectArray playerEntities = Set(playerEntitiesList).toArray();
	Java::DeleteLocal(playerEntitiesList);
	if (!playerEntities)
		return finalList;

	const int size = Java::env->GetArrayLength(playerEntities);
	const std::string localName = SDK::minecraft->thePlayer ? SDK::minecraft->thePlayer->GetName() : "";
	for (int i = 0; i < size; i++)
	{
		jobject obj_player = Java::env->GetObjectArrayElement(playerEntities, i);
		if (!obj_player)
			continue;

		CEntity player = CEntity(obj_player);
		if (player.GetName().compare(localName))
			finalList.push_back(player);
		else
			Java::DeleteLocal(obj_player);
	}

	Java::DeleteLocal(playerEntities);
	return finalList;
}