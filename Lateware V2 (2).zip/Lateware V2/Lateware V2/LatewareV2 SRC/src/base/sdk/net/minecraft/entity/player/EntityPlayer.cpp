#include "EntityPlayer.h"

#include "java/java.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include <sdk/java/util/List.h>
#include <sdk/java/lang/String.h>

CEntityPlayer::CEntityPlayer()
{
	this->clazz = StrayCache::entityPlayer_class;
}

CEntityPlayer::CEntityPlayer(jobject instance) : CEntityPlayer()
{
	this->instance = instance;
}


jclass CEntityPlayer::GetClass()
{
	return this->clazz;
}

jobject CEntityPlayer::GetInstance()
{
	return this->instance;
}

CInventoryPlayer CEntityPlayer::GetInventory()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::entityPlayer_inventory)
		return CInventoryPlayer(nullptr);

	jobject inv = Java::env->GetObjectField(this->GetInstance(), StrayCache::entityPlayer_inventory);
	if (Java::env->ExceptionCheck() || !inv)
	{
		Java::ClearException();
		return CInventoryPlayer(nullptr);
	}
	return CInventoryPlayer(inv);
}

bool CEntityPlayer::IsBlocking()
{
	if (!this->GetInstance())
		return false;

	// Prefer EntityLivingBase mapping (1.8.x); fall back to EntityPlayer (1.7.x).
	jmethodID mid = StrayCache::entityLivingBase_isBlocking
		? StrayCache::entityLivingBase_isBlocking
		: StrayCache::entityPlayer_isBlocking;

	if (!mid)
		return false;

	jboolean result = Java::env->CallBooleanMethod(this->GetInstance(), mid);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}

	return result == JNI_TRUE;
}

int CEntityPlayer::GetPing()
{
	if (!Java::env || !SDK::minecraft || !StrayCache::minecraft_getNetHandler)
		return -1;

	jobject mc = SDK::minecraft->GetInstance();
	if (!mc)
		return -1;

	jobject netHandlerPlayClient = Java::env->CallObjectMethod(mc, StrayCache::minecraft_getNetHandler);
	if (Java::env->ExceptionCheck() || !netHandlerPlayClient)
	{
		Java::ClearException();
		return -1;
	}

	int ping = -1;
	if (Java::version == MinecraftVersion::LUNAR_1_8_9 || Java::version == MinecraftVersion::VANILLA_1_8_9 || Java::version == MinecraftVersion::FORGE_1_8_9)
	{
		const std::string name = this->GetName();
		jstring playerName = Java::env->NewStringUTF(name.c_str());
		jobject networkPlayerInfo = Java::env->CallObjectMethod(netHandlerPlayClient, StrayCache::netHandlerPlayClient_getPlayerInfo, playerName);
		Java::DeleteLocal(playerName);

		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			networkPlayerInfo = nullptr;
		}

		if (networkPlayerInfo != nullptr)
		{
			ping = Java::env->CallIntMethod(networkPlayerInfo, StrayCache::networkPlayerInfo_getResponseTime);
			if (Java::env->ExceptionCheck())
			{
				Java::ClearException();
				ping = -1;
			}
			Java::DeleteLocal(networkPlayerInfo);
		}
	}
	else
	{
		jobject playerInfoList = Java::env->GetObjectField(netHandlerPlayClient, StrayCache::netHandlerPlayClient_playerInfoList);
		if (Java::env->ExceptionCheck() || !playerInfoList)
		{
			Java::ClearException();
			Java::DeleteLocal(netHandlerPlayClient);
			return -1;
		}

		jobjectArray playerInfoVector = List(playerInfoList).toArray();
		Java::DeleteLocal(playerInfoList);
		if (!playerInfoVector)
		{
			Java::DeleteLocal(netHandlerPlayClient);
			return -1;
		}

		const std::string selfName = this->GetName();
		const int len = Java::env->GetArrayLength(playerInfoVector);
		for (int i = 0; i < len; i++)
		{
			jobject guiPlayerInfo = Java::env->GetObjectArrayElement(playerInfoVector, i);
			if (!guiPlayerInfo)
				continue;

			jobject playerNameObj = Java::env->GetObjectField(guiPlayerInfo, StrayCache::guiPlayerInfo_name);
			std::string playerName = String(playerNameObj).ToString();
			Java::DeleteLocal(playerNameObj);

			if (playerName == selfName)
			{
				ping = Java::env->GetIntField(guiPlayerInfo, StrayCache::guiPlayerInfo_responseTime);
				Java::DeleteLocal(guiPlayerInfo);
				break;
			}
			Java::DeleteLocal(guiPlayerInfo);
		}

		Java::DeleteLocal(playerInfoVector);
	}

	Java::DeleteLocal(netHandlerPlayClient);
	return ping;
}
