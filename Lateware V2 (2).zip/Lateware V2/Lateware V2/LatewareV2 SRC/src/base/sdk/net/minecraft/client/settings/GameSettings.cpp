#include "GameSettings.h"

#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "java/java.h"

CGameSettings::CGameSettings()
{
	this->clazz = StrayCache::gameSettings_class;
}

jclass CGameSettings::GetClass()
{
	return this->clazz;
}

jobject CGameSettings::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;
	jobject mc = SDK::minecraft->GetInstance();
	if (!mc || !StrayCache::minecraft_gameSettings)
		return nullptr;
	jobject gs = Java::env->GetObjectField(mc, StrayCache::minecraft_gameSettings);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return gs;
}

float CGameSettings::GetFOV()
{
	jobject instance = GetInstance();
	if (!instance || !StrayCache::gameSettings_fovSetting)
		return 0.f;
	const float v = Java::env->GetFloatField(instance, StrayCache::gameSettings_fovSetting);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		Java::DeleteLocal(instance);
		return 0.f;
	}
	Java::DeleteLocal(instance);
	return v;
}

void CGameSettings::SetFullscreenKeyToNull()
{
	jobject instance = this->GetInstance();
	Java::env->CallVoidMethod(instance, StrayCache::gameSettings_setOptionKeyBinding, Java::env->GetObjectField(instance, StrayCache::gameSettings_keyBindFullscreen), 0);
}

void CGameSettings::RestoreFullscreenKey()
{
	jobject instance = this->GetInstance();
	Java::env->CallVoidMethod(instance, StrayCache::gameSettings_setOptionKeyBinding, Java::env->GetObjectField(instance, StrayCache::gameSettings_keyBindFullscreen), 87);
}


int CGameSettings::GetThirdPersonView()
{
	jobject instance = GetInstance();
	if (!instance || !StrayCache::gameSettings_thirdPersonView)
		return 0;
	const int v = Java::env->GetIntField(instance, StrayCache::gameSettings_thirdPersonView);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		Java::DeleteLocal(instance);
		return 0;
	}
	Java::DeleteLocal(instance);
	return v;
}

bool CGameSettings::SetUseItemPressed(bool pressed)
{
	return SetUseItemPressed(Java::env, pressed);
}

bool CGameSettings::SetUseItemPressed(JNIEnv* env, bool pressed)
{
	if (!env || !StrayCache::gameSettings_keyBindUseItem || !StrayCache::keyBinding_pressed)
		return false;
	if (!SDK::minecraft || !SDK::minecraft->GetInstance())
		return false;

	jobject mc = SDK::minecraft->GetInstance();
	jobject instance = env->GetObjectField(mc, StrayCache::minecraft_gameSettings);
	if (env->ExceptionCheck() || !instance)
	{
		if (env->ExceptionCheck()) env->ExceptionClear();
		if (instance) env->DeleteLocalRef(instance);
		return false;
	}

	jobject bind = env->GetObjectField(instance, StrayCache::gameSettings_keyBindUseItem);
	env->DeleteLocalRef(instance);
	if (env->ExceptionCheck() || !bind)
	{
		if (env->ExceptionCheck()) env->ExceptionClear();
		if (bind) env->DeleteLocalRef(bind);
		return false;
	}

	env->SetBooleanField(bind, StrayCache::keyBinding_pressed, pressed ? JNI_TRUE : JNI_FALSE);
	env->DeleteLocalRef(bind);
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return false;
	}
	return true;
}

