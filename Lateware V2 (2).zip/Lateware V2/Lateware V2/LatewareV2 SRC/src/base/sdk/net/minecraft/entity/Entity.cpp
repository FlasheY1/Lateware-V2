#include "Entity.h"

#include "java/java.h"
#include "sdk/sdk.h"
#include "sdk/java/lang/String.h"
#include "sdk/strayCache.h"
#include "util/logger.h"

CEntity::CEntity()
{
	this->clazz = StrayCache::entity_class;
}

CEntity::CEntity(jobject instance) : CEntity()
{
	this->instance = instance;
}

jclass CEntity::GetClass()
{
	return this->clazz;
}

jobject CEntity::GetInstance()
{
	return this->instance;
}

std::string CEntity::GetName()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entity_getName)
		return {};

	jstring jstr = (jstring)Java::env->CallObjectMethod(inst, StrayCache::entity_getName);
	if (Java::env->ExceptionCheck() || !jstr)
	{
		Java::ClearException();
		Java::DeleteLocal(jstr);
		return {};
	}

	std::string result = Java::JStringToStd(jstr);
	Java::DeleteLocal(jstr);
	return result;
}

static bool IsLocalPlayerEntity(jobject entity)
{
	if (!entity || !SDK::minecraft || !SDK::minecraft->thePlayer || !Java::env)
		return false;

	jobject local = SDK::minecraft->thePlayer->GetInstance();
	if (!local)
		return false;

	const jboolean same = Java::env->IsSameObject(entity, local);
	Java::DeleteLocal(local);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}
	return same == JNI_TRUE;
}

static bool Is1710()
{
	return Java::version == MinecraftVersion::LUNAR_1_7_10
		|| Java::version == MinecraftVersion::VANILLA_1_7_10
		|| Java::version == MinecraftVersion::FORGE_1_7_10;
}

Vector3 CEntity::GetPos()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst)
		return Vector3{};

	if (Is1710() && IsLocalPlayerEntity(inst))
	{
		// In 1.7.10, the entity position is the "eye" position, so we need to subtract the eye height to get the actual position. But only for the main player entity (work)
		CAxisAlignedBB bb = this->GetBB();
		const double minY = bb.GetNativeBoundingBox().minY;
		Java::DeleteLocal(bb.GetInstance());
		return Vector3{
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posX),
			(float)minY,
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posZ)
		};
	}

	return Vector3{
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posX),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posY),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posZ)
	};
}

Vector3 CEntity::GetEyePos()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst)
		return Vector3{};

	Vector3 pos = GetPos();
	if (Is1710() && IsLocalPlayerEntity(inst))
	{
		return Vector3{
			pos.x,
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posY),
			pos.z
		};
	}

	return Vector3{
		pos.x,
		(float)(double)(pos.y + this->GetEyeHeight()),
		pos.z
	};
}

Vector3 CEntity::GetLastTickPos()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst)
		return Vector3{};

	if (Is1710() && IsLocalPlayerEntity(inst))
	{
		// In 1.7.10, the entity position is the "eye" position, so we need to subtract the eye height to get the actual position. But only for the main player entity

		// Calculate the height diff using the current Y and bounding box min, then subtract that from the pos.
		float currentY = (float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_posY);
		CAxisAlignedBB bb = this->GetBB();
		double bbMinY = bb.GetNativeBoundingBox().minY;
		Java::DeleteLocal(bb.GetInstance());
		float heightDiff = abs(bbMinY - currentY);

		return Vector3{
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosX),
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosY) - heightDiff,
			(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosZ)
		};
	}

	return Vector3{
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosX),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosY),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_lastTickPosZ)
	};
}

float CEntity::GetEyeHeight()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entity_getEyeHeight)
		return 0.f;

	const float v = Java::env->CallFloatMethod(inst, StrayCache::entity_getEyeHeight);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return 0.f;
	}
	return v;
}

Vector3 CEntity::GetMotion()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst)
		return Vector3{};

	return Vector3{
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_motionX),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_motionY),
		(float)(double)Java::env->GetDoubleField(inst, StrayCache::entity_motionZ)
	};
}

bool CEntity::IsSneaking()
{
	return Java::env->CallBooleanMethod(this->GetInstance(), StrayCache::entity_isSneaking);
}

bool CEntity::IsSprinting()
{
	return Java::env->CallBooleanMethod(this->GetInstance(), StrayCache::entity_isSprinting);
}

void CEntity::SetSprinting(bool sprinting)
{
	Java::env->CallVoidMethod(this->GetInstance(), StrayCache::entity_setSprinting, sprinting);
}

bool CEntity::IsInvisibleToPlayer(jobject player)
{
	if (!StrayCache::entity_isInvisibleToPlayer || !this->GetInstance() || !player || !Java::env)
		return false;

	const jboolean result = Java::env->CallBooleanMethod(this->GetInstance(), StrayCache::entity_isInvisibleToPlayer, player);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}
	return result == JNI_TRUE;
}

float CEntity::GetHeight()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entity_height)
		return 0.f;
	return Java::env->GetFloatField(inst, StrayCache::entity_height);
}

float CEntity::GetWidth()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entity_width)
		return 0.f;
	return Java::env->GetFloatField(inst, StrayCache::entity_width);
}

float CEntity::GetDistanceWalkedModified()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_distanceWalkedModified);
}

float CEntity::GetPrevDistanceWalkedModified()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_prevDistanceWalkedModified);
}

float CEntity::GetRotationYaw()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_rotationYaw);
}

float CEntity::GetRotationPitch()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_rotationPitch);
}

float CEntity::GetPrevRotationYaw()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_prevRotationYaw);
}

float CEntity::GetPrevRotationPitch()
{
	return Java::env->GetFloatField(this->GetInstance(), StrayCache::entity_prevRotationPitch);
}

Vector2 CEntity::GetAngles()
{
	return Vector2(CEntity::GetRotationYaw(), CEntity::GetRotationPitch());
}

Vector2 CEntity::GetPrevAngles()
{
	return Vector2(CEntity::GetPrevRotationYaw(), CEntity::GetPrevRotationPitch());
}

void CEntity::SetAngles(Vector2 angles) 
{
	Java::env->SetFloatField(this->GetInstance(), StrayCache::entity_rotationYaw, angles.x);
	Java::env->SetFloatField(this->GetInstance(), StrayCache::entity_rotationPitch, angles.y);
};

void CEntity::SetPrevAngles(Vector2 angles)
{
	Java::env->SetFloatField(this->GetInstance(), StrayCache::entity_prevRotationYaw, angles.x);
	Java::env->SetFloatField(this->GetInstance(), StrayCache::entity_prevRotationPitch, angles.y);
};

CAxisAlignedBB CEntity::GetBB()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entity_boundingBox)
		return CAxisAlignedBB(nullptr);

	jobject bb = Java::env->GetObjectField(inst, StrayCache::entity_boundingBox);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return CAxisAlignedBB(nullptr);
	}
	return CAxisAlignedBB(bb);
}

void CEntity::SetBB(BoundingBox bb)
{
	this->GetBB().SetBoundingBox(bb);
}

int CEntity::GetHurtResistantTime()
{
	return Java::env->GetIntField(this->GetInstance(), StrayCache::entity_hurtResistantTime);
}
