#include "EntityLivingBase.h"

#include "java/java.h"
#include "sdk/strayCache.h"

CEntityLivingBase::CEntityLivingBase()
{
	this->clazz = StrayCache::entityLivingBase_class;
}

jclass CEntityLivingBase::GetClass()
{
	return this->clazz;
}

jobject CEntityLivingBase::GetInstance()
{
	return this->instance;
}

float CEntityLivingBase::GetHealth()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entityLivingBase_getHealth)
		return 0.f;

	const float v = Java::env->CallFloatMethod(inst, StrayCache::entityLivingBase_getHealth);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return 0.f;
	}
	return v;
}

float CEntityLivingBase::GetMaxHealth()
{
	jobject inst = this->GetInstance();
	if (!Java::env || !inst || !StrayCache::entityLivingBase_getMaxHealth)
		return 0.f;

	const float v = Java::env->CallFloatMethod(inst, StrayCache::entityLivingBase_getMaxHealth);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return 0.f;
	}
	return v;
}

bool CEntityLivingBase::CanEntityBeSeen(jobject entity) 
{
	return Java::env->CallBooleanMethod(this->GetInstance(), StrayCache::entityLivingBase_canEntityBeSeen, entity);
}

bool CEntityLivingBase::IsSwingInProgress()
{
	if (!this->GetInstance() || !StrayCache::entityLivingBase_isSwingInProgress)
		return false;

	jboolean result = Java::env->GetBooleanField(this->GetInstance(), StrayCache::entityLivingBase_isSwingInProgress);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}

	return result == JNI_TRUE;
}

bool CEntityLivingBase::IsPotionActive(int potionId)
{
	if (!this->GetInstance() || !StrayCache::entityLivingBase_isPotionActive || !Java::env)
		return false;

	const jboolean result = Java::env->CallBooleanMethod(
		this->GetInstance(), StrayCache::entityLivingBase_isPotionActive, (jint)potionId);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}
	return result == JNI_TRUE;
}

int CEntityLivingBase::GetPotionAmplifier(int potionId)
{
	if (!this->GetInstance() || !Java::env
		|| !StrayCache::entityLivingBase_getActivePotionEffect
		|| !StrayCache::potion_class || !StrayCache::potion_potionTypes
		|| !StrayCache::potionEffect_getAmplifier)
		return -1;

	JNIEnv* env = Java::env;
	jobjectArray types = (jobjectArray)env->GetStaticObjectField(StrayCache::potion_class, StrayCache::potion_potionTypes);
	if (env->ExceptionCheck() || !types)
	{
		Java::ClearException();
		if (types) env->DeleteLocalRef(types);
		return -1;
	}

	const jsize len = env->GetArrayLength(types);
	if (potionId < 0 || potionId >= (int)len)
	{
		env->DeleteLocalRef(types);
		return -1;
	}

	jobject potion = env->GetObjectArrayElement(types, (jsize)potionId);
	env->DeleteLocalRef(types);
	if (env->ExceptionCheck() || !potion)
	{
		Java::ClearException();
		if (potion) env->DeleteLocalRef(potion);
		return -1;
	}

	jobject effect = env->CallObjectMethod(
		this->GetInstance(), StrayCache::entityLivingBase_getActivePotionEffect, potion);
	env->DeleteLocalRef(potion);
	if (env->ExceptionCheck() || !effect)
	{
		Java::ClearException();
		if (effect) env->DeleteLocalRef(effect);
		return -1;
	}

	const jint amp = env->CallIntMethod(effect, StrayCache::potionEffect_getAmplifier);
	env->DeleteLocalRef(effect);
	if (env->ExceptionCheck())
	{
		Java::ClearException();
		return -1;
	}
	return (int)amp;
}