#include "InventoryPlayer.h"

#include "java/java.h"
#include "sdk/strayCache.h"

CInventoryPlayer::CInventoryPlayer()
{
	this->clazz = StrayCache::inventoryPlayer_class;
}

CInventoryPlayer::CInventoryPlayer(jobject instance) : CInventoryPlayer()
{
	this->instance = instance;
}

jclass CInventoryPlayer::GetClass()
{
	return this->clazz;
}

jobject CInventoryPlayer::GetInstance()
{
	return this->instance;
}

CItemStack CInventoryPlayer::GetCurrentItem()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::inventoryPlayer_getCurrentItem)
		return CItemStack(nullptr);

	jobject stack = Java::env->CallObjectMethod(this->GetInstance(), StrayCache::inventoryPlayer_getCurrentItem);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return CItemStack(nullptr);
	}
	return CItemStack(stack);
}

int CInventoryPlayer::GetCurrentItemIndex()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::inventoryPlayer_currentItem)
		return 0;

	const jint idx = Java::env->GetIntField(this->GetInstance(), StrayCache::inventoryPlayer_currentItem);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return 0;
	}
	return idx;
}

void CInventoryPlayer::SetCurrentItemIndex(int index)
{
	if (!Java::env || !this->GetInstance() || !StrayCache::inventoryPlayer_currentItem)
		return;

	Java::env->SetIntField(this->GetInstance(), StrayCache::inventoryPlayer_currentItem, index);
	if (Java::env->ExceptionCheck())
		Java::ClearException();
}

std::vector<CItemStack> CInventoryPlayer::GetMainInventory()
{
	std::vector<CItemStack> mainInventoryVector;
	if (!Java::env || !this->GetInstance() || !StrayCache::inventoryPlayer_mainInventory)
		return mainInventoryVector;

	jobject mainInventory = Java::env->GetObjectField(this->GetInstance(), StrayCache::inventoryPlayer_mainInventory);
	if (Java::env->ExceptionCheck() || !mainInventory)
	{
		Java::ClearException();
		return mainInventoryVector;
	}

	jobjectArray mainInventoryArray = (jobjectArray)mainInventory;
	const jsize len = Java::env->GetArrayLength(mainInventoryArray);
	if (Java::env->ExceptionCheck() || len <= 0)
	{
		Java::ClearException();
		Java::env->DeleteLocalRef(mainInventory);
		return mainInventoryVector;
	}

	mainInventoryVector.reserve((size_t)len);
	for (jsize i = 0; i < len; i++)
	{
		jobject mainItemStack = Java::env->GetObjectArrayElement(mainInventoryArray, i);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			continue;
		}
		mainInventoryVector.push_back(CItemStack(mainItemStack));
	}

	Java::env->DeleteLocalRef(mainInventory);
	return mainInventoryVector;
}

std::vector<CItemStack> CInventoryPlayer::GetArmorInventory()
{
	std::vector<CItemStack> armorInventoryVector;
	if (!Java::env || !this->GetInstance() || !StrayCache::inventoryPlayer_armorInventory)
		return armorInventoryVector;

	jobject armorInventory = Java::env->GetObjectField(this->GetInstance(), StrayCache::inventoryPlayer_armorInventory);
	if (Java::env->ExceptionCheck() || !armorInventory)
	{
		// Null armor array used to call GetArrayLength(nullptr) → hard JVM exit (code 1).
		Java::ClearException();
		return armorInventoryVector;
	}

	jobjectArray armorInventoryArray = (jobjectArray)armorInventory;
	const jsize len = Java::env->GetArrayLength(armorInventoryArray);
	if (Java::env->ExceptionCheck() || len <= 0)
	{
		Java::ClearException();
		Java::env->DeleteLocalRef(armorInventory);
		return armorInventoryVector;
	}

	armorInventoryVector.reserve((size_t)len);
	for (jsize i = 0; i < len; i++)
	{
		jobject armorItemStack = Java::env->GetObjectArrayElement(armorInventoryArray, i);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			continue;
		}
		armorInventoryVector.push_back(CItemStack(armorItemStack));
	}

	Java::env->DeleteLocalRef(armorInventory);
	return armorInventoryVector;
}
