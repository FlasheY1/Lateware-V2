#pragma once

#include "Entity.h"

struct CEntityLivingBase : CEntity
{
	CEntityLivingBase();

	jclass GetClass();
	jobject GetInstance();

	float GetHealth();
	float GetMaxHealth();
	bool CanEntityBeSeen(jobject entity);
	bool IsSwingInProgress();
	bool IsPotionActive(int potionId);
	// Returns amplifier (0 = I) or -1 if the effect is not active / unmapped.
	int GetPotionAmplifier(int potionId);
};

