#include "Container.h"

#include "java/java.h"
#include "sdk/strayCache.h"

CContainer::CContainer(jobject instance)
{
	this->instance = instance;
	this->clazz = (Java::env && instance) ? Java::env->GetObjectClass(instance) : nullptr;
}

jclass CContainer::GetClass()
{
	return this->clazz;
}

jobject CContainer::GetInstance()
{
	return this->instance;
}

int CContainer::GetWindowId()
{
	if (!Java::env || !this->GetInstance() || !this->GetClass() || !StrayCache::container_windowId_name)
		return -1;

	jfieldID windowIdFieldID = Java::env->GetFieldID(this->GetClass(), StrayCache::container_windowId_name, "I");
	if (!windowIdFieldID)
	{
		Java::ClearException();
		return -1;
	}

	const jint id = Java::env->GetIntField(this->GetInstance(), windowIdFieldID);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return -1;
	}
	return id;
}
