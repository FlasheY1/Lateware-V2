#include "IInventory.h"

#include "java/java.h"
#include "sdk/strayCache.h"
#include "util/logger.h"
#include "Container.h"

IInventory::IInventory(jobject instance)
{
	this->instance = instance;
	this->clazz = nullptr;
}

jclass IInventory::GetClass()
{
	return this->clazz;
}

jobject IInventory::GetInstance()
{
	return this->instance;
}

int IInventory::GetSizeInventory()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::iInventory_getSizeInventory)
		return 0;

	const jint size = Java::env->CallIntMethod(this->GetInstance(), StrayCache::iInventory_getSizeInventory);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return 0;
	}
	return size;
}

CItemStack IInventory::GetStackInSlot(int slot)
{
	if (!Java::env || !this->GetInstance() || !StrayCache::iInventory_getStackInSlot)
		return CItemStack(nullptr);

	jobject stackInSlot = Java::env->CallObjectMethod(this->GetInstance(), StrayCache::iInventory_getStackInSlot, slot);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return CItemStack(nullptr);
	}
	return CItemStack(stackInSlot);
}
