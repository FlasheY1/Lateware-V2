#include "Item.h"

#include "java/java.h"
#include "sdk/strayCache.h"

CItem::CItem()
{
	this->clazz = StrayCache::item_class;
}

CItem::CItem(jobject instance) : CItem()
{
	this->instance = instance;
}

jclass CItem::GetClass()
{
	return this->clazz;
}

jobject CItem::GetInstance()
{
	return this->instance;
}

std::string CItem::GetUnlocalizedName()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::item_getUnlocalizedName)
		return {};

	jstring jstr = (jstring)Java::env->CallObjectMethod(this->GetInstance(), StrayCache::item_getUnlocalizedName);
	if (Java::env->ExceptionCheck() || !jstr)
	{
		Java::ClearException();
		Java::DeleteLocal(jstr);
		return {};
	}

	std::string result = Java::JStringToStd(jstr);
	Java::DeleteLocal(jstr);
	return result;
}

int CItem::GetID()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::item_class || !StrayCache::item_getIdFromItem)
		return -1;

	const jint id = Java::env->CallStaticIntMethod(StrayCache::item_class, StrayCache::item_getIdFromItem, this->GetInstance());
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return -1;
	}
	return id;
}

int CItem::GetStackLimit()
{
	return Java::env->CallIntMethod(this->GetInstance(), StrayCache::item_getItemStackLimit);
}
