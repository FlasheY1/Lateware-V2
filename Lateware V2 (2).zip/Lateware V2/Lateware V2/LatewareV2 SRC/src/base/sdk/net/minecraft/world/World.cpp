#include "World.h"

#include "java/java.h"
#include "sdk/sdk.h"
#include "sdk/java/util/List.h"
#include "sdk/net/minecraft/util/Vec3.h"
#include "sdk/net/minecraft/util/MovingObjectPosition.h"
#include "util/logger.h"

CWorld::CWorld() 
{
	this->clazz = StrayCache::world_class;
}

jclass CWorld::GetClass()
{
	return this->clazz;
}

jobject CWorld::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;
	jobject mc = SDK::minecraft->GetInstance();
	if (!mc || !StrayCache::minecraft_theWorld)
		return nullptr;
	jobject world = Java::env->GetObjectField(mc, StrayCache::minecraft_theWorld);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return world;
}

std::vector<CEntityPlayer> CWorld::GetPlayerList()
{
	std::vector<CEntityPlayer> finalList;
	jobject world = this->GetInstance();
	if (!world || !Java::env || !StrayCache::world_playerEntities)
		return finalList;

	jobject playerEntitiesList = Java::env->GetObjectField(world, StrayCache::world_playerEntities);
	Java::DeleteLocal(world);
	if (Java::env->ExceptionCheck() || !playerEntitiesList)
	{
		Java::ClearException();
		return finalList;
	}

	jobjectArray playerEntities = List(playerEntitiesList).toArray();
	Java::DeleteLocal(playerEntitiesList);
	if (!playerEntities)
		return finalList;

	const int size = Java::env->GetArrayLength(playerEntities);
	if (size > 0)
		finalList.reserve((size_t)size);

	for (int i = 0; i < size; i++)
	{
		jobject obj_player = Java::env->GetObjectArrayElement(playerEntities, i);
		if (!obj_player)
			continue;

		finalList.push_back(CEntityPlayer(obj_player));
	}

	Java::DeleteLocal(playerEntities);
	return finalList;
}

bool CWorld::RayTraceBlocks(Vector3 from, Vector3 to, Vector3& result, bool stopOnLiquid, bool ignoreBlockWithoutBoundingBox, bool returnLastUncollidableBlock)
{
	// SPECIAL CASE
	jclass cls = StrayCache::vec3_class;
	if (!cls)
		Java::AssignClass(StrayCache::vec3_class_name, cls);
	if (!cls)
		return false;

	jmethodID init = Java::env->GetMethodID(cls, "<init>", "(DDD)V");
	jobject j_to = Java::env->NewObject(cls, init, (jdouble)(double)to.x, (jdouble)(double)to.y, (jdouble)(double)to.z);
	jobject j_from = Java::env->NewObject(cls, init, (jdouble)(double)from.x, (jdouble)(double)from.y, (jdouble)(double)from.z);

	jobject world = this->GetInstance();
	if (!world)
	{
		Java::DeleteLocal(j_to);
		Java::DeleteLocal(j_from);
		return false;
	}

	jobject movingObjPos_j = Java::env->CallObjectMethod(
		world,
		StrayCache::world_rayTraceBlocks,
		j_from,
		j_to,
		stopOnLiquid,
		ignoreBlockWithoutBoundingBox,
		returnLastUncollidableBlock
	);
	Java::DeleteLocal(world);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		movingObjPos_j = nullptr;
	}

	if (movingObjPos_j == nullptr)
	{
		Java::DeleteLocal(j_to);
		Java::DeleteLocal(j_from);
		return false;
	}

	CMovingObjectPosition movingObjPos = CMovingObjectPosition(movingObjPos_j);
	CVec3 a = movingObjPos.GetBlockPosition();
	result = a.GetNativeVector3();
	Java::DeleteLocal(j_to);
	Java::DeleteLocal(j_from);
	Java::DeleteLocal(movingObjPos_j);
	return true;
}

CBlock CWorld::GetBlock(int x, int y, int z)
{
	jobject world = this->GetInstance();
	if (!world || !Java::env)
		return CBlock(nullptr);

	CBlock result(nullptr);
	if (Java::version == MinecraftVersion::LUNAR_1_8_9 || Java::version == MinecraftVersion::VANILLA_1_8_9 || Java::version == MinecraftVersion::FORGE_1_8_9)
	{
		CBlockPos pos = CBlockPos(x, y, z);
		jobject stateObj = Java::env->CallObjectMethod(world, StrayCache::world_getBlockState, pos.GetInstance());
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			stateObj = nullptr;
		}
		CIBlockState state = CIBlockState(stateObj);
		result = state.GetBlock();
	}
	else
	{
		jobject blockObj = Java::env->CallObjectMethod(world, StrayCache::world_getBlock, x, y, z);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			blockObj = nullptr;
		}
		result = CBlock(blockObj);
	}

	Java::DeleteLocal(world);
	return result;
}
