#include "RenderManager.h"

#include "java/java.h"
#include "sdk/sdk.h"

CRenderManager::CRenderManager()
{
	this->clazz = StrayCache::renderManager_class;
}

Vector3 CRenderManager::RenderPos()
{
	if (!Java::env)
		return Vector3{};

	if (Java::version == MinecraftVersion::LUNAR_1_8_9 || Java::version == MinecraftVersion::VANILLA_1_8_9 || Java::version == MinecraftVersion::FORGE_1_8_9)
	{
		jobject instance = this->GetInstance();
		if (!instance || !StrayCache::renderManager_renderPosX)
			return Vector3{};

		Vector3 pos{
			(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_renderPosX),
			(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_renderPosY),
			(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_renderPosZ)
		};
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			Java::DeleteLocal(instance);
			return Vector3{};
		}
		Java::DeleteLocal(instance);
		return pos;
	}

	if (!this->GetClass() || !StrayCache::renderManager_renderPosX)
		return Vector3{};

	Vector3 pos{
		(float)(double)Java::env->GetStaticDoubleField(this->GetClass(), StrayCache::renderManager_renderPosX),
		(float)(double)Java::env->GetStaticDoubleField(this->GetClass(), StrayCache::renderManager_renderPosY),
		(float)(double)Java::env->GetStaticDoubleField(this->GetClass(), StrayCache::renderManager_renderPosZ)
	};
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return Vector3{};
	}
	return pos;
}

Vector3 CRenderManager::ViewerPos()
{
	if (!Java::env)
		return Vector3{};

	jobject instance = this->GetInstance();
	if (!instance || !StrayCache::renderManager_viewerPosX)
		return Vector3{};

	Vector3 pos{
		(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_viewerPosX),
		(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_viewerPosY),
		(float)(double)Java::env->GetDoubleField(instance, StrayCache::renderManager_viewerPosZ)
	};
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		Java::DeleteLocal(instance);
		return Vector3{};
	}
	Java::DeleteLocal(instance);
	return pos;
}

jclass CRenderManager::GetClass()
{
	return this->clazz;
}

jobject CRenderManager::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;

	if (Java::version == MinecraftVersion::LUNAR_1_8_9 || Java::version == MinecraftVersion::VANILLA_1_8_9 || Java::version == MinecraftVersion::FORGE_1_8_9)
	{
		jobject mc = SDK::minecraft->GetInstance();
		if (!mc || !StrayCache::minecraft_renderManager)
			return nullptr;
		jobject rm = Java::env->GetObjectField(mc, StrayCache::minecraft_renderManager);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			return nullptr;
		}
		return rm;
	}

	if (!this->GetClass() || !StrayCache::renderManager_instance)
		return nullptr;
	jobject rm = Java::env->GetStaticObjectField(this->GetClass(), StrayCache::renderManager_instance);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return rm;
}
