#include "GuiContainer.h"

#include "java/java.h"
#include "sdk/strayCache.h"

CGuiContainer::CGuiContainer(jobject instance)
{
	this->instance = instance;
	this->clazz = StrayCache::guiContainer_class;
}

jclass CGuiContainer::GetClass()
{
	return this->clazz;
}

jobject CGuiContainer::GetInstance()
{
	return this->instance;
}

CContainer CGuiContainer::GetContainer()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::guiContainer_inventorySlots)
		return CContainer(nullptr);

	jobject container = Java::env->GetObjectField(this->GetInstance(), StrayCache::guiContainer_inventorySlots);
	if (Java::env->ExceptionCheck() || !container)
	{
		Java::ClearException();
		return CContainer(nullptr);
	}
	return CContainer(container);
}