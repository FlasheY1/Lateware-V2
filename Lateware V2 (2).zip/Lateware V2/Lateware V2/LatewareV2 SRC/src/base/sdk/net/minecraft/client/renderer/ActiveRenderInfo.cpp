#include "ActiveRenderInfo.h"

#include "java/java.h"
#include "sdk/sdk.h"
#include "sdk/java/nio/FloatBuffer.h"
#include "util/logger.h"

CActiveRenderInfo::CActiveRenderInfo()
{
	this->clazz = StrayCache::activeRenderInfo_class;
}

jclass CActiveRenderInfo::GetClass()
{
	return this->clazz;
}

jobject CActiveRenderInfo::GetInstance()
{
	return nullptr;
}

Matrix CActiveRenderInfo::ProjectionMatrix()
{
	if (!Java::env || !this->GetClass() || !StrayCache::activeRenderInfo_PROJECTION)
		return Matrix{};
	jobject projection = Java::env->GetStaticObjectField(this->GetClass(), StrayCache::activeRenderInfo_PROJECTION);
	if (Java::env->ExceptionCheck() || !projection)
	{
		Java::ClearException();
		return Matrix{};
	}
	Matrix m = FloatBuffer::FloatBuffer(projection).GetMatrix();
	Java::env->DeleteLocalRef(projection);
	return m;
}

Matrix CActiveRenderInfo::ModelViewMatrix()
{
	if (!Java::env || !this->GetClass() || !StrayCache::activeRenderInfo_MODELVIEW)
		return Matrix{};
	jobject modelView = Java::env->GetStaticObjectField(this->GetClass(), StrayCache::activeRenderInfo_MODELVIEW);
	if (Java::env->ExceptionCheck() || !modelView)
	{
		Java::ClearException();
		return Matrix{};
	}
	Matrix m = FloatBuffer::FloatBuffer(modelView).GetMatrix();
	Java::env->DeleteLocalRef(modelView);
	return m;
}

