#include "EntityPlayerSP.h"

#include "sdk/sdk.h"
#include "java/java.h"
#include "util/logger.h"

CEntityPlayerSP::CEntityPlayerSP() : CEntityPlayer()
{
	this->clazz = StrayCache::entityPlayerSP_class;
}

jclass CEntityPlayerSP::GetClass()
{
	return this->clazz;
}

jobject CEntityPlayerSP::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;
	jobject mc = SDK::minecraft->GetInstance();
	if (!mc || !StrayCache::minecraft_thePlayer)
		return nullptr;
	jobject player = Java::env->GetObjectField(mc, StrayCache::minecraft_thePlayer);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return player;
}
