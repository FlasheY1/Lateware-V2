#include "Timer.h"

#include "java/java.h"
#include "sdk/sdk.h"

CTimer::CTimer()
{
	this->clazz = StrayCache::timer_class;
}

float CTimer::GetRenderPartialTicks()
{
	jobject instance = this->GetInstance();
	if (!instance || !Java::env || !StrayCache::timer_renderPartialTicks)
		return 0.f;
	const float v = Java::env->GetFloatField(instance, StrayCache::timer_renderPartialTicks);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		Java::DeleteLocal(instance);
		return 0.f;
	}
	Java::DeleteLocal(instance);
	return v;
}

jclass CTimer::GetClass()
{
	return this->clazz;
}

jobject CTimer::GetInstance()
{
	if (!Java::env || !SDK::minecraft)
		return nullptr;
	jobject mc = SDK::minecraft->GetInstance();
	if (!mc || !StrayCache::minecraft_timer)
		return nullptr;
	jobject timer = Java::env->GetObjectField(mc, StrayCache::minecraft_timer);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return nullptr;
	}
	return timer;
}