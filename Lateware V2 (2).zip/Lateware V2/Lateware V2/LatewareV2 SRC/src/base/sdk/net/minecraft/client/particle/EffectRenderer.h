#pragma once

#include <vector>

#include "util/math/geometry.h"

struct CEffectRenderer
{
	// Collects live EntitySmokeFX positions from Minecraft.effectRenderer.fxLayers.
	// Returns empty if particle mappings are unavailable for the current client.
	static std::vector<Vector3> GetSmokePositions(int maxAge = 12, int maxCount = 256);
	static bool IsAvailable();
};
