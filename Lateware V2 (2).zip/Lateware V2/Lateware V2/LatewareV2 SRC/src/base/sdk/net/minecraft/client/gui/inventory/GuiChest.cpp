#include "GuiChest.h"

#include "java/java.h"
#include "sdk/strayCache.h"
#include "util/logger.h"

CGuiChest::CGuiChest(jobject instance) : CGuiContainer(instance)
{
	this->instance = instance;
	this->clazz = StrayCache::guiChest_class;
}

jclass CGuiChest::GetClass()
{
	return this->clazz;
}

jobject CGuiChest::GetInstance()
{
	return this->instance;
}

IInventory CGuiChest::GetLowerChestInventory()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::guiChest_lowerChestInventory)
		return IInventory(nullptr);

	jobject lowerChestInventory = Java::env->GetObjectField(this->GetInstance(), StrayCache::guiChest_lowerChestInventory);
	if (Java::env->ExceptionCheck() || !lowerChestInventory)
	{
		Java::ClearException();
		return IInventory(nullptr);
	}
	return IInventory(lowerChestInventory);
}

IInventory CGuiChest::GetUpperChestInventory()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::guiChest_upperChestInventory)
		return IInventory(nullptr);

	jobject upperChestInventory = Java::env->GetObjectField(this->GetInstance(), StrayCache::guiChest_upperChestInventory);
	if (Java::env->ExceptionCheck() || !upperChestInventory)
	{
		Java::ClearException();
		return IInventory(nullptr);
	}
	return IInventory(upperChestInventory);
}

int CGuiChest::GetInventoryRows()
{
	return Java::env->GetIntField(this->GetInstance(), StrayCache::guiChest_inventoryRows);
}