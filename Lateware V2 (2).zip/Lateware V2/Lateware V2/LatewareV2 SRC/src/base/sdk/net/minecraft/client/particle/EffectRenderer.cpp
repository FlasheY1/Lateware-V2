#include "EffectRenderer.h"

#include "java/java.h"
#include "java/javahook.h"
#include "sdk/sdk.h"
#include "sdk/strayCache.h"
#include "sdk/java/util/List.h"

bool CEffectRenderer::IsAvailable()
{
	return Java::env
		&& SDK::minecraft
		&& SDK::minecraft->GetInstance()
		&& StrayCache::minecraft_effectRenderer
		&& StrayCache::effectRenderer_fxLayers
		&& StrayCache::entitySmokeFX_class
		&& StrayCache::entity_posX
		&& StrayCache::entity_posY
		&& StrayCache::entity_posZ;
}

namespace
{
	void CollectFromList(jobject listObj, int maxAge, int maxCount, std::vector<Vector3>& out)
	{
		if (!listObj || (int)out.size() >= maxCount)
			return;

		List list(listObj);
		jobjectArray arr = list.toArray();
		if (!arr)
			return;

		JavaHook::JNIFrame listFrame(Java::env, 256);
		const int size = Java::env->GetArrayLength(arr);
		for (int i = 0; i < size && (int)out.size() < maxCount; ++i)
		{
			jobject fx = Java::env->GetObjectArrayElement(arr, i);
			if (!fx)
				continue;

			if (!Java::env->IsInstanceOf(fx, StrayCache::entitySmokeFX_class))
			{
				Java::env->DeleteLocalRef(fx);
				continue;
			}

			if (StrayCache::entityFX_particleAge && maxAge >= 0)
			{
				const jint age = Java::env->GetIntField(fx, StrayCache::entityFX_particleAge);
				if (Java::env->ExceptionCheck())
				{
					Java::ClearException();
					Java::env->DeleteLocalRef(fx);
					continue;
				}
				if (age > maxAge)
				{
					Java::env->DeleteLocalRef(fx);
					continue;
				}
			}

			const double x = Java::env->GetDoubleField(fx, StrayCache::entity_posX);
			const double y = Java::env->GetDoubleField(fx, StrayCache::entity_posY);
			const double z = Java::env->GetDoubleField(fx, StrayCache::entity_posZ);
			if (Java::env->ExceptionCheck())
			{
				Java::ClearException();
				Java::env->DeleteLocalRef(fx);
				continue;
			}

			out.push_back(Vector3{ (float)x, (float)y, (float)z });
			Java::env->DeleteLocalRef(fx);
		}

		Java::env->DeleteLocalRef(arr);
	}
}

std::vector<Vector3> CEffectRenderer::GetSmokePositions(int maxAge, int maxCount)
{
	std::vector<Vector3> out;
	if (!IsAvailable())
		return out;

	try
	{
		jobject mc = SDK::minecraft->GetInstance();
		if (!mc)
			return out;

		jobject effectRenderer = Java::env->GetObjectField(mc, StrayCache::minecraft_effectRenderer);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			return out;
		}
		if (!effectRenderer)
			return out;

		jobject fxLayersObj = Java::env->GetObjectField(effectRenderer, StrayCache::effectRenderer_fxLayers);
		if (Java::env->ExceptionCheck())
		{
			Java::ClearException();
			Java::env->DeleteLocalRef(effectRenderer);
			return out;
		}

		if (fxLayersObj)
		{
			out.reserve((size_t)(maxCount < 64 ? maxCount : 64));
			jobjectArray outer = (jobjectArray)fxLayersObj;
			const int outerLen = Java::env->GetArrayLength(outer);

			if (StrayCache::effectRenderer_fxLayersIs2D)
			{
				// 1.8.9: List[][] fxLayers
				for (int i = 0; i < outerLen && (int)out.size() < maxCount; ++i)
				{
					jobjectArray inner = (jobjectArray)Java::env->GetObjectArrayElement(outer, i);
					if (!inner)
						continue;

					const int innerLen = Java::env->GetArrayLength(inner);
					for (int j = 0; j < innerLen && (int)out.size() < maxCount; ++j)
					{
						jobject listObj = Java::env->GetObjectArrayElement(inner, j);
						CollectFromList(listObj, maxAge, maxCount, out);
						if (listObj)
							Java::env->DeleteLocalRef(listObj);
					}
					Java::env->DeleteLocalRef(inner);
				}
			}
			else
			{
				// 1.7.10: List[] fxLayers
				for (int i = 0; i < outerLen && (int)out.size() < maxCount; ++i)
				{
					jobject listObj = Java::env->GetObjectArrayElement(outer, i);
					CollectFromList(listObj, maxAge, maxCount, out);
					if (listObj)
						Java::env->DeleteLocalRef(listObj);
				}
			}

			Java::env->DeleteLocalRef(fxLayersObj);
		}

		Java::env->DeleteLocalRef(effectRenderer);
	}
	catch (...)
	{
		if (Java::env && Java::env->ExceptionCheck())
			Java::ClearException();
		out.clear();
	}

	return out;
}
