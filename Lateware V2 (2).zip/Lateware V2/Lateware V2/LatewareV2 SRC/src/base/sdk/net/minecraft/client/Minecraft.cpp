#include "Minecraft.h"

#include "util/logger.h"
#include "java/java.h"
#include "sdk/net/minecraft/entity/EntityLivingBase.h"
#include "ClientBrandRetriever.h"

CMinecraft::CMinecraft()
{
	this->clazz = StrayCache::minecraft_class;

	if (!this->clazz || !StrayCache::minecraft_getMinecraft)
	{
		LOG_ERROR("Minecraft class/method missing");
		this->instance = nullptr;
		return;
	}

	jobject localMc = Java::env->CallStaticObjectMethod(this->GetClass(), StrayCache::minecraft_getMinecraft);
	if (Java::env->ExceptionCheck() || !localMc)
	{
		Java::ClearException();
		LOG_ERROR("getMinecraft() failed");
		this->instance = nullptr;
		return;
	}
	// Keep a global ref — a bare local from Init dies across JNI frames / GC pressure
	// and was a common main-menu crash after inject.
	this->instance = Java::env->NewGlobalRef(localMc);
	Java::env->DeleteLocalRef(localMc);
	if (!this->instance)
	{
		LOG_ERROR("NewGlobalRef(Minecraft) failed");
		return;
	}
	LOG_INFO("Created Minecraft instance");

	this->thePlayer = std::make_unique<CEntityPlayerSP>();
	LOG_INFO("Created Player instance");

	this->playerController = std::make_unique<CPlayerControllerMP>();
	LOG_INFO("Created PlayerController instance");

	this->theWorld = std::make_unique<CWorldClient>();
	LOG_INFO("Created World instance");

	this->activeRenderInfo = std::make_unique<CActiveRenderInfo>();
	LOG_INFO("Created ActiveRenderInfo instance");

	this->renderManager = std::make_unique<CRenderManager>();
	LOG_INFO("Created RenderManager instance");

	this->timer = std::make_unique<CTimer>();
	LOG_INFO("Created Timer instance");

	this->gameSettings = std::make_unique<CGameSettings>();
	LOG_INFO("Created GameSettings instance");

	this->enchantmentHelper = std::make_unique<CEnchantmentHelper>();
	LOG_INFO("Created EnchantmentHelper");

	if (StrayCache::clientBrandRetriever_class && StrayCache::clientBrandRetriever_getClientModName)
	{
		this->originalClientBrand = CClientBrandRetriever::GetClientModName();
		LOG_INFO("Created Original Client Brand: %s", this->originalClientBrand.c_str());
	}
	else
	{
		this->originalClientBrand = "vanilla";
		Java::ClearException();
		LOG_WARNING("ClientBrandRetriever unavailable, using fallback brand");
	}
}

jclass CMinecraft::GetClass()
{
	return this->clazz;
}

jobject CMinecraft::GetInstance()
{
	return this->instance;
}

CEntity CMinecraft::GetRenderViewEntity()
{
	return CEntity(Java::env->GetObjectField(this->GetInstance(), StrayCache::minecraft_renderViewEntity));
}

bool CMinecraft::IsInGuiState()
{
	if (!Java::env || !StrayCache::minecraft_currentScreen)
		return false;
	jobject mc = this->GetInstance();
	if (!mc)
		return false;
	jobject screen = Java::env->GetObjectField(mc, StrayCache::minecraft_currentScreen);
	if (Java::env->ExceptionCheck())
	{
		Java::ClearException();
		return false;
	}
	if (screen)
	{
		Java::env->DeleteLocalRef(screen);
		return true;
	}
	return false;
}

bool CMinecraft::IsInInventory()
{
	if (!Java::env || !StrayCache::minecraft_currentScreen)
		return false;
	jobject mc = this->GetInstance();
	if (!mc)
		return false;
	jobject screen = Java::env->GetObjectField(mc, StrayCache::minecraft_currentScreen);
	if (Java::env->ExceptionCheck() || !screen)
	{
		Java::ClearException();
		return false;
	}
	const bool isInv = Java::GetClazzName(screen) == StrayCache::inventory_class_name;
	Java::env->DeleteLocalRef(screen);
	return isInv;
}

bool CMinecraft::IsInChest()
{
	if (!Java::env || !StrayCache::minecraft_currentScreen)
		return false;
	jobject mc = this->GetInstance();
	if (!mc)
		return false;
	jobject screen = Java::env->GetObjectField(mc, StrayCache::minecraft_currentScreen);
	if (Java::env->ExceptionCheck() || !screen)
	{
		Java::ClearException();
		return false;
	}
	const bool isChest = Java::GetClazzName(screen) == StrayCache::chest_gui_class_name;
	Java::env->DeleteLocalRef(screen);
	return isChest;
}

void CMinecraft::ClickMouse()
{
	Java::env->CallVoidMethod(this->GetInstance(), StrayCache::minecraft_clickMouse);
}

CMovingObjectPosition CMinecraft::GetMouseOver()
{
	return CMovingObjectPosition(Java::env->GetObjectField(this->instance, StrayCache::minecraft_objectMouseOver));
}

int CMinecraft::GetFps()
{
	return Java::env->GetStaticIntField(this->GetClass(), StrayCache::minecraft_debugFPS);
}


CGuiChest CMinecraft::GetGuiChest()
{
	if (!Java::env || !this->GetInstance() || !StrayCache::minecraft_currentScreen)
		return CGuiChest(nullptr);

	jobject screen = Java::env->GetObjectField(this->GetInstance(), StrayCache::minecraft_currentScreen);
	if (Java::env->ExceptionCheck() || !screen)
	{
		Java::ClearException();
		return CGuiChest(nullptr);
	}
	return CGuiChest(screen);
}