from pathlib import Path

p = Path(__file__).resolve().parents[1] / "src" / "base" / "sdk" / "strayCache.h"
text = p.read_text(encoding="utf-8")

def repl(old: str, new: str, label: str) -> None:
    global text
    count = text.count(old)
    print(f"{label}: {count}")
    if count:
        text = text.replace(old, new)

repl(
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "keyBindFullscreen", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t}''',
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "keyBindFullscreen", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t\tgameSettings_keyBindUseItem = Java::env->GetFieldID(gameSettings_class, "keyBindUseItem", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindUseItem) { LOG_INFO("gameSettings_keyBindUseItem: %p", gameSettings_keyBindUseItem); Java::ClearException(); }
\t\t\t}

\t\t\tJava::AssignClass("net.minecraft.client.settings.KeyBinding", keyBinding_class);
\t\t\tif (keyBinding_class)
\t\t\t{
\t\t\t\tkeyBinding_pressed = Java::env->GetFieldID(keyBinding_class, "pressed", "Z");
\t\t\t\tif (!keyBinding_pressed) { LOG_INFO("keyBinding_pressed: %p", keyBinding_pressed); Java::ClearException(); }
\t\t\t}
\t\t\telse { keyBinding_pressed = nullptr; Java::ClearException(); }''',
    "MCP gameSettings",
)

repl(
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "field_152395_am", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t}''',
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "field_152395_am", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t\tgameSettings_keyBindUseItem = Java::env->GetFieldID(gameSettings_class, "field_74313_G", "Lnet/minecraft/client/settings/KeyBinding;");
\t\t\t\tif (!gameSettings_keyBindUseItem) { LOG_INFO("gameSettings_keyBindUseItem: %p", gameSettings_keyBindUseItem); Java::ClearException(); }
\t\t\t}

\t\t\tJava::AssignClass("net.minecraft.client.settings.KeyBinding", keyBinding_class);
\t\t\tif (keyBinding_class)
\t\t\t{
\t\t\t\tkeyBinding_pressed = Java::env->GetFieldID(keyBinding_class, "field_74513_e", "Z");
\t\t\t\tif (!keyBinding_pressed) { LOG_INFO("keyBinding_pressed: %p", keyBinding_pressed); Java::ClearException(); }
\t\t\t}
\t\t\telse { keyBinding_pressed = nullptr; Java::ClearException(); }''',
    "Forge gameSettings",
)

repl(
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "aq", "Lavb;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t}''',
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "aq", "Lavb;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t\tgameSettings_keyBindUseItem = Java::env->GetFieldID(gameSettings_class, "af", "Lavb;");
\t\t\t\tif (!gameSettings_keyBindUseItem) { LOG_INFO("gameSettings_keyBindUseItem: %p", gameSettings_keyBindUseItem); Java::ClearException(); }
\t\t\t}

\t\t\tJava::AssignClass("avb", keyBinding_class);
\t\t\tif (keyBinding_class)
\t\t\t{
\t\t\t\tkeyBinding_pressed = Java::env->GetFieldID(keyBinding_class, "h", "Z");
\t\t\t\tif (!keyBinding_pressed) { LOG_INFO("keyBinding_pressed: %p", keyBinding_pressed); Java::ClearException(); }
\t\t\t}
\t\t\telse { keyBinding_pressed = nullptr; Java::ClearException(); }''',
    "Notch18 gameSettings",
)

repl(
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "am", "Lbal;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t}''',
    '''\t\t\t\tgameSettings_keyBindFullscreen = Java::env->GetFieldID(gameSettings_class, "am", "Lbal;");
\t\t\t\tif (!gameSettings_keyBindFullscreen) LOG_INFO("gameSettings_keyBindFullscreen: %p", gameSettings_keyBindFullscreen);
\t\t\t\tgameSettings_keyBindUseItem = nullptr;
\t\t\t\tJava::ClearException();
\t\t\t}
\t\t\tkeyBinding_class = nullptr;
\t\t\tkeyBinding_pressed = nullptr;''',
    "Notch17 gameSettings",
)

repl(
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "isPotionActive", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "getActivePotionEffect", "(Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;");''',
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "isPotionActive", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_swingItem = Java::env->GetMethodID(entityLivingBase_class, "swingItem", "()V");
\t\t\t\tif (!entityLivingBase_swingItem) { LOG_INFO("entityLivingBase_swingItem: %p", entityLivingBase_swingItem); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "getActivePotionEffect", "(Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;");''',
    "MCP swingItem",
)

repl(
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "func_82165_m", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "func_70660_b", "(Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;");''',
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "func_82165_m", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_swingItem = Java::env->GetMethodID(entityLivingBase_class, "func_71038_i", "()V");
\t\t\t\tif (!entityLivingBase_swingItem) { LOG_INFO("entityLivingBase_swingItem: %p", entityLivingBase_swingItem); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "func_70660_b", "(Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;");''',
    "Forge swingItem",
)

repl(
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "k", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "a", "(Lpe;)Lpf;");''',
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "k", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_swingItem = Java::env->GetMethodID(entityLivingBase_class, "bw", "()V");
\t\t\t\tif (!entityLivingBase_swingItem) { LOG_INFO("entityLivingBase_swingItem: %p", entityLivingBase_swingItem); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = Java::env->GetMethodID(entityLivingBase_class, "a", "(Lpe;)Lpf;");''',
    "Notch18 swingItem",
)

repl(
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "k", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_getActivePotionEffect = nullptr; // amplifier lookup not mapped for 1.7.10 notch''',
    '''\t\t\t\tentityLivingBase_isPotionActive = Java::env->GetMethodID(entityLivingBase_class, "k", "(I)Z");
\t\t\t\tif (!entityLivingBase_isPotionActive) { LOG_INFO("entityLivingBase_isPotionActive: %p", entityLivingBase_isPotionActive); Java::ClearException(); }
\t\t\t\tentityLivingBase_swingItem = nullptr;
\t\t\t\tentityLivingBase_getActivePotionEffect = nullptr; // amplifier lookup not mapped for 1.7.10 notch''',
    "Notch17 swingItem",
)

# Move declaration next to entity living base if duplicated oddly — already declared near keybind, also add near living base
if "entityLivingBase_swingItem;" not in text.split("ENTITY LIVING BASE CLASS")[1][:800]:
    text = text.replace(
        "\tinline static jmethodID entityLivingBase_isPotionActive; // (I)Z\n",
        "\tinline static jmethodID entityLivingBase_isPotionActive; // (I)Z\n"
        "\tinline static jmethodID entityLivingBase_swingItem; // ()V\n",
        1,
    )
    # remove the earlier duplicate near KEY BINDING if both exist
    first = text.find("ENTITY LIVING BASE — swingItem")
    if first != -1:
        # remove the orphan block comment + duplicate mid near keybinding
        text = text.replace(
            "\n\t// ENTITY LIVING BASE — swingItem (animation / S0B path)\n\tinline static jmethodID entityLivingBase_swingItem;\n",
            "\n",
            1,
        )

p.write_text(text, encoding="utf-8")
print("wrote", p)
