"""Generate a simple PNG icon atlas for LateWare menu modules/categories."""
from PIL import Image, ImageDraw
import os
import sys

OUT_HDR = sys.argv[1] if len(sys.argv) > 1 else "menuIconAtlasData.h"
OUT_PNG = sys.argv[2] if len(sys.argv) > 2 else "menu_icons.png"

# name -> draw function key
ICONS = [
    "Combat", "Visual", "Movement", "Inventory", "Utility",
    "Friends", "Configs", "Settings",
    "Anti Evade", "Auto Evade", "Auto Bottle", "Aim Assist", "Reach",
    "Left Auto Clicker", "Right Auto Clicker",
    "ESP", "Radar", "Nametags",
    "Bridge Assist", "Velocity", "Sprint Reset", "Sprint",
    "Chest Stealer",
    "Array List", "Client Brand Changer", "Weapon",
    "General", "Style", "HUD",
]

TILE = 32
ACCENT = (255, 75, 120, 255)
WHITE = (245, 245, 250, 255)
MUTED = (180, 180, 190, 255)
BG = (18, 18, 22, 255)


def rounded_bg(draw, s=TILE):
    draw.rounded_rectangle([1, 1, s - 2, s - 2], radius=8, fill=BG)
    draw.rounded_rectangle([1, 1, s - 2, s - 2], radius=8, outline=(255, 255, 255, 28))


def make_icon(kind: str) -> Image.Image:
    im = Image.new("RGBA", (TILE, TILE), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    rounded_bg(d)
    c = TILE // 2

    if kind in ("Combat", "Aim Assist", "Reach", "Weapon", "Left Auto Clicker", "Right Auto Clicker"):
        # sword / crosshair
        d.line([(9, 23), (23, 9)], fill=ACCENT, width=3)
        d.ellipse([c - 5, c - 5, c + 5, c + 5], outline=WHITE, width=2)
        d.line([(c, 6), (c, 11)], fill=WHITE, width=2)
        d.line([(c, 21), (c, 26)], fill=WHITE, width=2)
        d.line([(6, c), (11, c)], fill=WHITE, width=2)
        d.line([(21, c), (26, c)], fill=WHITE, width=2)
    elif kind in ("Anti Evade", "Auto Evade"):
        # shield
        d.polygon([(c, 7), (24, 11), (24, 18), (c, 26), (8, 18), (8, 11)], outline=ACCENT, fill=(255, 75, 120, 40))
        d.line([(c, 12), (c, 20)], fill=WHITE, width=2)
    elif kind == "Auto Bottle":
        # potion bottle
        d.rectangle([13, 7, 19, 11], fill=MUTED)
        d.polygon([(11, 12), (21, 12), (20, 24), (12, 24)], fill=ACCENT)
        d.line([(12, 16), (20, 16)], fill=WHITE, width=1)
    elif kind in ("Visual", "ESP", "Nametags"):
        # eye
        d.ellipse([7, 11, 25, 21], outline=WHITE, width=2)
        d.ellipse([c - 3, c - 3, c + 3, c + 3], fill=ACCENT)
    elif kind == "Radar":
        d.ellipse([7, 7, 25, 25], outline=WHITE, width=2)
        d.ellipse([c - 2, c - 2, c + 2, c + 2], fill=ACCENT)
        d.line([(c, c), (c + 7, c - 7)], fill=ACCENT, width=2)
    elif kind in ("Movement", "Sprint", "Sprint Reset", "Velocity", "Bridge Assist"):
        # boot / arrow
        d.polygon([(10, 20), (14, 10), (18, 10), (22, 20), (20, 24), (12, 24)], fill=ACCENT)
        d.line([(8, 14), (24, 14)], fill=WHITE, width=2)
        d.polygon([(22, 11), (26, 14), (22, 17)], fill=WHITE)
    elif kind in ("Inventory", "Chest Stealer"):
        d.rounded_rectangle([8, 10, 24, 24], radius=3, outline=WHITE, width=2)
        d.rectangle([13, 8, 19, 12], outline=ACCENT, width=2)
        d.line([(8, 15), (24, 15)], fill=MUTED, width=1)
    elif kind in ("Utility", "Array List", "Client Brand Changer"):
        d.rectangle([9, 9, 14, 14], fill=ACCENT)
        d.rectangle([18, 9, 23, 14], fill=MUTED)
        d.rectangle([9, 18, 14, 23], fill=MUTED)
        d.rectangle([18, 18, 23, 23], fill=ACCENT)
    elif kind == "Friends":
        d.ellipse([9, 8, 17, 16], fill=WHITE)
        d.ellipse([15, 10, 23, 18], fill=ACCENT)
        d.ellipse([8, 17, 24, 26], outline=MUTED, width=2)
    elif kind == "Configs":
        d.rounded_rectangle([9, 8, 23, 24], radius=3, outline=WHITE, width=2)
        d.line([(12, 13), (20, 13)], fill=ACCENT, width=2)
        d.line([(12, 17), (20, 17)], fill=MUTED, width=2)
        d.line([(12, 21), (17, 21)], fill=MUTED, width=2)
    elif kind in ("Settings", "General", "Style", "HUD"):
        # gear teeth as circle + spokes
        d.ellipse([9, 9, 23, 23], outline=WHITE, width=2)
        d.ellipse([c - 3, c - 3, c + 3, c + 3], fill=ACCENT)
        for ang in range(0, 360, 45):
            import math
            r1, r2 = 10, 13
            rad = math.radians(ang)
            x1, y1 = c + r1 * math.cos(rad), c + r1 * math.sin(rad)
            x2, y2 = c + r2 * math.cos(rad), c + r2 * math.sin(rad)
            d.line([(x1, y1), (x2, y2)], fill=WHITE, width=2)
    else:
        d.ellipse([10, 10, 22, 22], fill=ACCENT)

    return im


cols = 8
rows = (len(ICONS) + cols - 1) // cols
atlas = Image.new("RGBA", (cols * TILE, rows * TILE), (0, 0, 0, 0))
entries = []
for idx, name in enumerate(ICONS):
    icon = make_icon(name)
    x = (idx % cols) * TILE
    y = (idx // cols) * TILE
    atlas.paste(icon, (x, y))
    entries.append((name, idx, x, y))

os.makedirs(os.path.dirname(OUT_PNG) or ".", exist_ok=True)
atlas.save(OUT_PNG, format="PNG")
data = open(OUT_PNG, "rb").read()

# Escape names for C string
def cstr(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'

lines = [
    "#pragma once",
    "// Auto-generated menu icon atlas.",
    "#include <cstddef>",
    "",
    f"static constexpr int MENU_ICON_ATLAS_W = {cols * TILE};",
    f"static constexpr int MENU_ICON_ATLAS_H = {rows * TILE};",
    f"static constexpr int MENU_ICON_TILE = {TILE};",
    f"static constexpr int MENU_ICON_COUNT = {len(entries)};",
    "",
    "struct MenuIconEntry { const char* name; int index; int x; int y; };",
    "static constexpr MenuIconEntry MENU_ICON_ENTRIES[] = {",
]
for name, idx, x, y in entries:
    lines.append(f"    {{ {cstr(name)}, {idx}, {x}, {y} }},")
lines += [
    "};",
    "",
    f"static constexpr size_t MENU_ICON_ATLAS_PNG_SIZE = {len(data)};",
    "static constexpr unsigned char MENU_ICON_ATLAS_PNG[] = {",
]
for i in range(0, len(data), 16):
    chunk = data[i:i + 16]
    lines.append("    " + ", ".join(f"0x{b:02X}" for b in chunk) + ",")
lines.append("};")

os.makedirs(os.path.dirname(OUT_HDR) or ".", exist_ok=True)
open(OUT_HDR, "w", newline="\n").write("\n".join(lines) + "\n")
print(f"wrote {len(entries)} icons, {len(data)} bytes")
