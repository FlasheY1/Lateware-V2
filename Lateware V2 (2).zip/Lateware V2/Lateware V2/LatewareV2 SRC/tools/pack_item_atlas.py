from PIL import Image
import os
import sys

items_dir = sys.argv[1]
out_hdr = sys.argv[2]
out_png = sys.argv[3]

# itemId -> texture filename (no extension)
ID_MAP = {
    298: "leather_helmet", 299: "leather_chestplate", 300: "leather_leggings", 301: "leather_boots",
    302: "chainmail_helmet", 303: "chainmail_chestplate", 304: "chainmail_leggings", 305: "chainmail_boots",
    306: "iron_helmet", 307: "iron_chestplate", 308: "iron_leggings", 309: "iron_boots",
    310: "diamond_helmet", 311: "diamond_chestplate", 312: "diamond_leggings", 313: "diamond_boots",
    314: "gold_helmet", 315: "gold_chestplate", 316: "gold_leggings", 317: "gold_boots",
    268: "wood_sword", 272: "stone_sword", 267: "iron_sword", 276: "diamond_sword", 283: "gold_sword",
    271: "wood_axe", 275: "stone_axe", 258: "iron_axe", 279: "diamond_axe", 286: "gold_axe",
    261: "bow_standby", 368: "ender_pearl", 322: "apple_golden", 373: "potion_bottle_drinkable",
    332: "snowball", 344: "egg", 346: "fishing_rod_uncast", 280: "stick", 262: "arrow", 259: "flint_and_steel",
    46: "tnt_side", 49: "obsidian", 145: "anvil_base",
}

pairs = sorted(ID_MAP.items(), key=lambda kv: kv[0])
tile = 16
cols = 8
rows = (len(pairs) + cols - 1) // cols
atlas = Image.new("RGBA", (cols * tile, rows * tile), (0, 0, 0, 0))
entries = []

for idx, (item_id, name) in enumerate(pairs):
    path = os.path.join(items_dir, name + ".png")
    if not os.path.isfile(path):
        print("missing", name)
        continue
    im = Image.open(path).convert("RGBA")
    if im.size != (tile, tile):
        im = im.resize((tile, tile), Image.NEAREST)
    x = (idx % cols) * tile
    y = (idx // cols) * tile
    atlas.paste(im, (x, y))
    entries.append((item_id, idx, x, y))

os.makedirs(os.path.dirname(out_png), exist_ok=True)
atlas.save(out_png, format="PNG")
with open(out_png, "rb") as f:
    data = f.read()

lines = [
    "#pragma once",
    "// Auto-generated item icon atlas. Do not edit.",
    "#include <cstddef>",
    "",
    f"static constexpr int ITEM_ICON_ATLAS_W = {cols * tile};",
    f"static constexpr int ITEM_ICON_ATLAS_H = {rows * tile};",
    f"static constexpr int ITEM_ICON_TILE = {tile};",
    f"static constexpr int ITEM_ICON_COLS = {cols};",
    f"static constexpr int ITEM_ICON_COUNT = {len(entries)};",
    "",
    "struct ItemIconEntry { int itemId; int index; int x; int y; };",
    "static constexpr ItemIconEntry ITEM_ICON_ENTRIES[] = {",
]
for item_id, idx, x, y in entries:
    lines.append(f"    {{ {item_id}, {idx}, {x}, {y} }},")
lines += [
    "};",
    "",
    f"static constexpr size_t ITEM_ICON_ATLAS_PNG_SIZE = {len(data)};",
    "static constexpr unsigned char ITEM_ICON_ATLAS_PNG[] = {",
]
for i in range(0, len(data), 16):
    chunk = data[i:i + 16]
    lines.append("    " + ", ".join(f"0x{b:02X}" for b in chunk) + ",")
lines.append("};")

os.makedirs(os.path.dirname(out_hdr), exist_ok=True)
with open(out_hdr, "w", newline="\n") as f:
    f.write("\n".join(lines) + "\n")

print(f"wrote {len(entries)} icons, atlas {len(data)} bytes -> {out_hdr}")
